package up5.mi.pary.jc.jdbc.compte;

public class Main {

	public static void main(String[ ] args) throws Exception {
		BD.init();
		// creation des tables à la première exécution
		if (CompteBD.isTablesACreer()){
			CompteBD.creerLesTables( );
			System.out.println("Tables créées");
			}
		// on récupère les comptes de Dupond et Durand
		CompteBD c1=CompteBD.getCompte("Dupond",true);
		CompteBD c2=CompteBD.getCompte("Durand",true);
		// on effectue des opérations et on affiche des infos
		// (il faudrait un menu à la place …)‏
		c1.addOperation(120);
		c2.addOperation(210);
		System.out.println(c1.getNomTitulaire( )+" "+c1.getSolde( )+
				" "+c1.getDecouvertAutorise( ));
		System.out.println(c2.getNomTitulaire( )+" "+c2.getSolde( )+
				" "+c2.getDecouvertAutorise( ));
	}


}
