import React, {useState} from "react";
import './AjoutFacture.css'
import Associate from "../Contrats/Associate";
import img from "../../Images/contract.png";
import minusLogo from "../../Images/minus.png";
import plusLogo from "../../Images/plus.png";
import FactureService from "../../Services/FactureService";

/**
 * Fonction qui retourne le popup afin de créer une facture
 * @param affichage prend la valeur vrai ou faux afin de gèrer l'affichage de popup
 * @param handleShowPopupFacture la fonction qui gere l'affichage de popup
 * @returns {JSX.Element|null} popup pour la creation d'une facture
 */
export const AjoutFacture = ({affichage, handleShowPopupFacture}) => {

    let [client, setClient] = useState()
    let [produits, setProduit] = useState([])
    let [visibleClient, setVisibleClient] = useState(false)
    let [visibleProduit, setVisibleProduit] = useState(false)
    let [prixSousTotal, setPrixSousTotal] = useState(0)
    let [avoir, setAvoir] = useState(0)
    let [avoirActuel, setAvoirActuel] = useState(0)
    let [totalTtc, setTotalTtc] = useState(0)
    let [payee, setPayee] = useState(false)

    /**
     * Fonction qui attribue un client à une facture
     * @param data le client à ajouter à la facture
     */
    function changeClientFacture(data) {
        setClient(data)
    }

    /**
     * Fonction qui gère l'affichage de bon fonctionnement 'ajouter ou supprimer' client
     */
    function showAddClient() {
        if (client != null)
            setClient(null)
        setVisibleClient(!visibleClient)
    }

    /**
     * Fonction qui gère l'affichage de bon fonctionnement 'ajouter ou supprimer' produit
     */
    function showAddProduit() {
        setVisibleProduit(!visibleProduit)
    }

    /**
     * Fonction qui ajoute les produits séléctionner et qui calcul le sous-total et le total TTC
     * @param produit a ajouter à la liste des produits
     */
    function changeProduitFacture(produit) {
        setProduit([...produits, produit]
        )
        let tmpPrix = prixSousTotal + produit.prixTtc
        setPrixSousTotal(tmpPrix)
        setTotalTtc(tmpPrix - avoirActuel)
    }

    /**
     * Fonction qui remplace la valeur de l'avoir par une nouvelle valeur
     * @param e la nouvelle valeur de l'avoir
     */
    function calculAvoirPrix(e) {
        setAvoir(parseFloat(e.target.value))
    }

    /**
     * Fonction qui confirme l'avoir a saisir et qui calcul le prix total après la sasisie de l'avoir et elle mis a jour l'avoir
     */
    function confirmerAvoir() {
        let tmpTotalAvoir = prixSousTotal - avoir
        setTotalTtc(tmpTotalAvoir)
        setAvoirActuel(avoir)
    }

    /**
     *Fonction qui creer la facture et l'ajoute à la base de donnée
     */
    function addFactureListe() {
        let factureInfo = ""
        produits.map((produit) => {
            factureInfo += "" + produit.nom + "\t" + produit.prixTtc + "\n";
        })

        let idClient = client.id
        let facture = {
            totalTTC: totalTtc,
            avoir: avoir,
            facturePayee: payee,
            informations: factureInfo
        }

        FactureService.createFacture(facture, idClient).then(() => {
            handleShowPopupFacture()
        })
    }

    /**
     *Fonction qui gère le statut de la facture (payee ou non payee)
     * @param event l'etat de paiement de la facture
     */
    function changerStatutPayee(event) {
        setPayee(event.target.value === 'payee')
    }

    return affichage ? (
        <div className='popup'>
            <div className='popup-inner'>

                <h2 className='titre-creer-facture'><i className="fas fa-receipt"></i>Créer une facture</h2>

                <form>

                    <h3 className='titre-client-creer-facture'><i className="fas fa-address-card"></i>Client</h3>

                    <div onClick={showAddClient} style={{cursor: "pointer"}}>
                        <img className="plus-logo" src={(visibleClient) ? minusLogo : plusLogo} alt="ajouter"/>
                        {(client == null) ? "Ajouter un Client" : "Supprimer le Client (" + client.clientActuel.nom + ")"}
                    </div>

                    {(visibleClient && client == null) && <Associate addClient={changeClientFacture} type="client"/>}

                    <h3 className='titre-client-creer-facture'><i className="fas fa-shopping-basket"></i>Produits</h3>

                    <div onClick={showAddProduit} style={{cursor: "pointer"}}>
                        <img className="plus-logo" src={(visibleProduit) ? minusLogo : plusLogo}
                             alt="ajouter"/>
                        {"Ajouter un produit"}
                    </div>

                    {(visibleProduit) && <Associate addProduit={changeProduitFacture} type="produit"/>}
                    <hr className='separation'/>

                    <table className='tableau-style-creation-facture'>
                        <thead className='tableau-tete-creation-facture'>
                        <tr>
                            <th>Article</th>
                            <th>Prix</th>
                        </tr>
                        </thead>
                        <tbody className='corps-tableau-creation-facture'>
                        {
                            produits.map(
                                (produit) => (
                                    <tr key={produit.id}>
                                        <td>{produit.nom}</td>
                                        <td>{produit.prixTtc} €</td>
                                    </tr>
                                )
                            )
                        }
                        </tbody>
                    </table>

                    <hr className='separation'/>
                    <div className='information'>
                        <p className="sous-total">Sous total : <span
                            className="sous-total-prix">{prixSousTotal} €</span></p>
                        <p className='avoir'>Saisir avoir :<span className='separ'> - </span>
                            <input className='avoir-saisi' type="text" value={avoir} onChange={calculAvoirPrix}/>
                            <span style={{color: '#44c3cb'}}>€</span>
                        </p>
                        <button className='confirmer-Avoir' onClick={confirmerAvoir} type="button">Confirmer l'avoir
                        </button>
                        <p className='avoir'> Avoir <span className='separ'>: - </span> {avoirActuel}
                            <span style={{color: '#44c3cb', margin: '0 15px'}}> €</span>
                        </p>
                        <p className="sous-total">Total : <span
                            className="sous-total-prix">{totalTtc} €</span></p>
                    </div>

                    <div>
                        <h3 className='titre-client-creer-facture'><i className="fas fa-credit-card"></i>Paiement</h3>
                        <div className='choix-paiement'>
                            <input type="radio" name="type" value="payee" checked={payee} onClick={changerStatutPayee}/>
                            <label> Débiter automatiquement après l'envoie de la facture</label>
                        </div>
                        <div className='choix-paiement'>
                            <input type="radio" name="type" value="nonPayee" checked={!payee}
                                   onClick={changerStatutPayee}/>
                            <label> Débiter manuellement après l'envoie de la facture </label>
                        </div>
                    </div>

                    <div className='footer-popup'>
                        <button className='confirmer-btn' type='submit' onClick={addFactureListe}><i
                            className="fas fa-paper-plane"></i>Envoyer la facture
                        </button>
                        <button className='close-btn' onClick={handleShowPopupFacture}>Annuler</button>
                    </div>
                </form>
            </div>
        </div>
    ) : null;
}