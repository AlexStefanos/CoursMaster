package com.l3ax1.factoration.app.controllers.clients;

import com.l3ax1.factoration.app.Models.clients.*;
import com.l3ax1.factoration.app.Models.contrat.Contrat;
import com.l3ax1.factoration.app.services.clients.ClientService;
import com.l3ax1.factoration.app.services.contrat.ContratService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <h1>ClientController : class</h1>
 * <hr/>
 * Client Controller permet de communiquer avec front end react. Pour accéder
 * à notre API on utilise des endpoints associé à une URL,  Lorsqu'on appelle
 * cette URL, on reçoit une réponse, et cet échange se fait en HTTP. et grâce
 * à Spring-Boot-starter-web nous  fournit  tout  le nécessaire pour créer un
 * endpoint.
 * <br/><br/>
 * <p>
 * {@link RestController} : Comme @Component, elle permet d’indiquer à Spring
 * que cette classe est un bean, et aussi   indiqué  à  Spring  d’insérer  le
 * retour  de  la méthode  au  format  JSON  dans le corps de la réponse HTTP.
 * Grâce à  ça , les applications qui  vont communiquer avec l’API accéderont
 * au résultat de leur requête en parsant la réponse HTTP. <br/>
 * <p>
 * {@link CrossOrigin} : Annotation  pour  autoriser  les  requêtes d'origine
 * croisée  sur  des  classes  de  gestionnaire  et  /  ou  des  méthodes  de
 * gestionnaire spécifiques. Traité si un HandlerMapping approprié est configuré.
 * <p>
 * <hr/>
 *
 * @author Lounis BOULDJA
 * @version 1.0
 * @see ClientService
 * @see RestController
 * @see CrossOrigin
 */
@RestController
@CrossOrigin(origins = "*")     // localhost:3000
public class ClientController {

    /**
     * Cela permettra d’appeler les méthodes pour communiquer avec la base de données.
     *
     * @see ClientService
     **/
    @Autowired
    ClientService clientService;

    @Autowired
    ContratService contratService;


    /**
     * {@link GetMapping} Cela signifie que les requêtes  HTTP de  type  GET à l’URL /clients
     * exécuteront le code de cette méthode. Et ce code est tout simple : il s’agit d’appeler
     * la méthode  getClients()  du  {@link ClientService},  ce  dernier appellera la méthode
     * findAll()  du  {@link com.l3ax1.factoration.app.repository.clients.ClientRepository}
     * et nous obtiendrons ainsi tous les clients enregistrés  en  base de données.
     * recuperer la list de client de la base de données.
     *
     * @return <strong>la liste des clients enregistrés  en  base de données.<strong/>
     * @see GetMapping
     */
    @GetMapping("/clients")
    public Iterable<Client> getClients() {
        return clientService.getClients();
    }

    /**
     * {@link PostMapping } Pour l’envoi de données. Cela sera utilisé crée un client
     * <strong>Morale</strong> et le stocker dans la base de données. <br/>
     * <p>
     * {@link RequestBody} L'annotation indiquant qu'un paramètre de méthode doit être
     * lié au corps de la requête Web
     *
     * @param morale le client morale a ajouté
     * @return client Morale stocké dans la base de données.
     * @see ClientService
     */
    @PostMapping("/clients/ajouter_morale")
    public Morale createMoraleClient(@RequestBody Morale morale) {
        return clientService.creatMoraleClient(morale);
    }

    /**
     * {@link PostMapping }Pour l’envoi de données. Cela sera utilisé crée un client
     * <strong>Physique</strong> et le stocker dans la base de données.
     *
     * @param physique client physique  a ajouté
     * @return client Physique stocké dans la base de données.
     * @see ClientService
     */
    @PostMapping("/clients/ajouter_physique")
    public Physique creatPhysiqueClient(@RequestBody Physique physique) {
        return clientService.createPhysiqueClient(physique);
    }


    /**
     * <h2>Recuprer le client de labase de données par son ID</h2>
     * <p>
     * {@link GetMapping} Cela signifie que les requêtes  HTTP de  type  GET à l’URL /clients/{id}
     * exécuteront le code de cette méthode. Et ce code est tout simple : il s’agit d’appeler
     * la méthode  getClientById()  du  {@link ClientService},  ce  dernier appellera la méthode
     * findById()  du  {@link com.l3ax1.factoration.app.repository.clients.ClientRepository}
     * et nous obtiendrons ainsi le client enregistrés  en  base de données avec id {id}.
     * <p>
     * {@link ResponseEntity} Extension de HttpEntity qui ajoute un code d'état HttpStatus.
     *
     * @param id id de client
     * @return client si il existe
     */
    @GetMapping("/clients/{id}")
    public ResponseEntity<Client> getClientById(@PathVariable Long id) {
        Client client = this.clientService.getClientById(id).orElseThrow(
                () -> new ResourceNotFoundException("il n'existe pas un client avec un id : " + id));
        return ResponseEntity.ok(client);
    }

    /**
     * <h2>Modifier les details d'un clients physique</h2>
     *
     * @param id            id de client.
     * @param clientDetails le client apres la modificaction.
     * @return client si la requette est bien executer.
     */
    @PutMapping("/clients/update_physique/{id}")
    public ResponseEntity<Client> updatePhysiqueClient(@PathVariable Long id, @RequestBody Physique clientDetails) {

        Client client = this.clientService.getClientById(id).orElseThrow(
                () -> new ResourceNotFoundException("il n'existe pas un client avec un id : " + id));

        client.copy(clientDetails);
        Client updatedClient = this.clientService.saveClient(client);
        return ResponseEntity.ok(updatedClient);
    }

    /**
     * <h2>modifier les details d'un client</h2>
     *
     * @param id            id de client a modifié
     * @param clientDetails le client à jour
     * @return client apres la modifiacation.
     */
    @PutMapping("/clients/update_morale/{id}")
    public ResponseEntity<Client> updateMoraleClient(@PathVariable Long id, @RequestBody Morale clientDetails) {
        Client client = this.clientService.getClientById(id).orElseThrow(
                () -> new ResourceNotFoundException("il n'existe pas un client avec un id : " + id));

        client.copy(clientDetails);
        Client updatedClient = this.clientService.saveClient(client);
        return ResponseEntity.ok(updatedClient);
    }

    /**
     * <h2>Recuprer les contrats d'un clients.</h2>
     *
     * @param id id de client
     * @return la liste des contrats
     */
    @GetMapping("/clients/contrats/{id}")
    public List<Contrat> getClientContratsById(@PathVariable Long id) {
        System.out.println("Je Suis La ::: " + id);
        return this.clientService.getClientContratsById(id);
    }


    /**
     * <h2>Creer un client morale avec un contrat</h2>
     * <p>
     * {@link PostMapping } Pour l’envoi de données. Cela sera utilisé crée un client
     * <strong>Morale</strong> et le stocker dans la base de données. <br/>
     * <p>
     * {@link RequestBody} L'annotation indiquant qu'un paramètre de méthode doit être
     * lié au corps de la requête Web
     *
     * @param morale le client morale a ajouté
     * @return client Morale stocké dans la base de données.
     * @see ClientService
     */
    @PostMapping("/clients/ajouter_morale/contrat={id}")
    public Morale createMoraleClientWithContrat(@PathVariable Long id, @RequestBody Morale morale) {

        Contrat contrat = this.contratService.findContratById(id).orElseThrow(
                () -> new ResourceNotFoundException("il n'existe pas un contrat avec un id : " + id));
        return this.clientService.creatMoraleClientWithContrat(morale, contrat);
    }

    /**
     * <h2>Creer un client physique avec un contrat</h2>
     * <p>
     * {@link PostMapping }Pour l’envoi de données. Cela sera utilisé crée un client
     * <strong>Physique</strong> et le stocker dans la base de données.
     *
     * @param physique client physique  a ajouté
     * @return client Physique stocké dans la base de données.
     * @see ClientService
     */
    @PostMapping("/clients/ajouter_physique/contrat={id}")
    public Physique creatPhysiqueClientWithContrat(@PathVariable Long id, @RequestBody Physique physique) {

        Contrat contrat = this.contratService.findContratById(id).orElseThrow(
                () -> new ResourceNotFoundException("il n'existe pas un contrat avec un id : " + id));

        return clientService.createPhysiqueClientWithContrat(physique, contrat);
    }
}