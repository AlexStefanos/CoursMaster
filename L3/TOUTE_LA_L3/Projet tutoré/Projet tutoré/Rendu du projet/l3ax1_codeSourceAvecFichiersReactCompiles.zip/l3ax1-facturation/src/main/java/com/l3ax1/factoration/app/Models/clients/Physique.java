package com.l3ax1.factoration.app.Models.clients;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

/**
 * <h1>Physique : Class</h1>
 *<hr/>
 * Entity jpa hérité de la classe abstraite {@link Client}. indique que le client est Physique.
 * <br/>
 * {@link DiscriminatorValue} pour indiquer la valuer de type (MOR => morale).
 * <br/>
 * {@link EqualsAndHashCode} Génère des implémentations pour les méthodes equals et hashCode
 * héritées par tous les objets.
 *
 * <br/><br/>
 * see : {@link Client} Pour la docs des autres annotations (@Entity, Data)
 * <hr/>
 * @version 1.0
 * @author lounis BOULDJA
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@DiscriminatorValue(value="PHY")
public class Physique extends Client {

    @Column(name = "client_email")
    private String email;


    @Column(name = "client_description")
    private String description;

    @Override
    public void copy(Client client) {
        super.copy(client);
        Physique physique = (Physique) client;
        this.email = physique.email;
        this.description = physique.description;
    }

}
