package up5.mi.pary.jc.tri;

public class TriInsertion {

	
	/* les éléments de 't' sont réorganisés de telle sorte qu'ils soient rangés par ordre croissant*/
	public static void triInsertion(int [] t){ 
		for (int i = 1;i<t.length;i++) 
			insererElementDansTableau(t,i);
	}

	/** 'tab' est un tableau d'entiers dont les éléments d'indice 0 à 'i'-1
	 * sont rangés par ordre croissant
	 * les éléments d'indice 0 à 'i' de 'tab' sont réorganisés de telle sorte
	 * qu'ils soient rangés par ordre croissant */
	public static void insererElementDansTableau(int [] tab,int i){
		int elementAPlacer = tab[i];
		int placeProposee= i ;
		boolean placeTrouve=false;
		while (! placeTrouve) {
			if (placeProposee==0 || tab[placeProposee-1]< elementAPlacer ) placeTrouve=true;
			else {tab[placeProposee] = tab[placeProposee-1]; placeProposee--; }
		}
		tab[placeProposee]= elementAPlacer ;
	}
}
