package up5.mi.pary.term.convertor;

@SuppressWarnings("serial")
public class ConvertException extends Exception {

	public ConvertException(String message) {
		super(message);
	}

}
