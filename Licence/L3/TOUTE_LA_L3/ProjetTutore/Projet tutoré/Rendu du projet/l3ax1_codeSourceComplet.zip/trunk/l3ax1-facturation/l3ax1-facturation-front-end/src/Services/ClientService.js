import axios from "axios";

const URL_API_CLIENTS="http://localhost:8080/clients"
const URL_API_CLIENTS_ADD_MOR="http://localhost:8080/clients/ajouter_morale"
const URL_API_CLIENTS_ADD_PHY="http://localhost:8080/clients/ajouter_physique"

class ClientService {

    /**
     * recuperer la liste des client
     */
    getCleints() {
        return axios.get(URL_API_CLIENTS)
    }

    /**
     * créer un client morale.
     *
     * @param morale  client morale à ajouter
     */
    createMoraleClient(morale) {
        return axios.post(URL_API_CLIENTS_ADD_MOR, morale)
    }

    /**
     * créer un client physique.
     *
     * @param physique client physique
     */
    createPhysiqueClient(physique) {
        return axios.post(URL_API_CLIENTS_ADD_PHY, physique)
    }


    /**
     * @param morale  client à ajouter
     * @param clientId
     */
    createMoraleClientWithContrat(morale, contratId) {
        return axios.post(URL_API_CLIENTS_ADD_MOR+"/contrat="+contratId, morale)
    }

    /**
     * creer un client avec un contrat.
     *
     * @param physique client physique
     * @param contratID id de client.
     * @return {Promise<AxiosResponse<any>>}
     */
    createPhysiqueClientWithContrat(physique, contratID) {
        return axios.post(URL_API_CLIENTS_ADD_PHY+"/contrat="+contratID, physique)
    }

    /**
     * recuperer les contrat d'un client.
     * @param clientId id de client.
     * @return {Promise<AxiosResponse<any>>} promise.
     */
    getClientContrats(clientId) {
        return axios.get(URL_API_CLIENTS+"/contrats/"+clientId);
    }


    /**
     * recuperer le client saisi par user.
     */
    createClientFromData (data) {
        let isPhysique = data.email != null;
        let client = {
            clientActuel : {
                nom : (isPhysique) ? data.nom : data.raisonSociale
            },
            adresse : (""+data.pays+", "+data.adresse+", "+data.codePostal+", "+data.ville),
            prefixeFacture : data.prefixeFacture,
            numeroTva: data.numeroTva
        }
        //
        if (data.statut === "physique" || isPhysique) {
            client.email = data.email
            client.description = data.description
        } else {
            client.formeJuridique = data.formeJuridique
            client.siret = data.siret
        }
        return client;
    }
}

let ClientsService = new ClientService();

export default ClientsService;