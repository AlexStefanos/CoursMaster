package com.l3ax1.factoration.app.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.l3ax1.factoration.app.Models.factures.Facture;

/**
 * classe qui gènere le pdf
 */
public class Pdf {

    /**
     * Méthode qui va créeer un nouveau pdf
     * @param facture la facture concernée
     * @return un pdf sous forme d'une facture
     */
    public File remplir(Facture facture) throws DocumentException, MalformedURLException, IOException {

        //Création d'un nouveau document
        Document doc1 = new Document(PageSize.A4);
        File temp = File.createTempFile("monfichier", ".pdf");
        PdfWriter pdfWriter = PdfWriter.getInstance(doc1, new FileOutputStream(temp));
        //ouverture de document
        doc1.open();
        Image img = Image.getInstance("src/main/resources/Images/logo.png");
        img.scaleAbsoluteWidth(70);
        img.scaleAbsoluteHeight(70);
        img.setAlignment(Image.ALIGN_LEFT);
        doc1.add(img);

        doc1.add(new Paragraph("Facturer à \n ", FontFactory.getFont("Cambria", 16, BaseColor.DARK_GRAY)));
        doc1.add(new Paragraph (" "));
        doc1.add(new Phrase(facture.getClient().getClientActuel().getNom()+"\n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        doc1.add(new Phrase(facture.getClient().getAdresse(), FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        doc1.add(new Paragraph("Facture ", FontFactory.getFont("Cambria", 16, BaseColor.DARK_GRAY)));
        doc1.add(new Paragraph (" "));
        doc1.add(new Phrase("Numéro de facture :" +facture.getNumeroFacture()+"\n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        doc1.add(new Phrase("Date d'émission :"+facture.getDateEmission()+"\n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        if(facture.isFacturePayee()){
            doc1.add(new Phrase("Etat facture : Payée \n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
            doc1.add(new Paragraph(""));
            doc1.add(new Phrase(facture.getTotalTTC() + " € dû le "+ facture.getDateEmission()+"\n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        }else{
            doc1.add(new Phrase("Etat facture : Impayée \n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        }

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        PdfPCell colone;

        colone = new PdfPCell(new Phrase("\n Articles \n ", FontFactory.getFont("Arial", 14)));
        colone.setHorizontalAlignment(Element.ALIGN_CENTER);
        colone.setBackgroundColor(BaseColor.LIGHT_GRAY);
        table.addCell(colone);

        colone = new PdfPCell(new Phrase("\n Prix \n ", FontFactory.getFont("Arial", 14)));
        colone.setHorizontalAlignment(Element.ALIGN_CENTER);
        colone.setBackgroundColor(BaseColor.LIGHT_GRAY);
        table.addCell(colone);

        String[] produits = facture.getInformations().split("\n");

        for (int j = 0; j < produits.length; j++) {

            colone = new PdfPCell(new Phrase("\n "+produits[j].split("\t")[0]+"\n ", FontFactory.getFont("Times New Roman", 12)));
            colone.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(colone);

            colone = new PdfPCell(new Phrase("\n"+produits[j].split("\t")[1]+"\n", FontFactory.getFont("Times New Roman", 12)));
            colone.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(colone);
        }
        doc1.add(table);
        doc1.add(new Paragraph(""));
        doc1.add(new Phrase("\n"));
        doc1.add(new Phrase("Avoir : "+ facture.getAvoir() + " € \n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        doc1.add(new Paragraph(""));
        doc1.add(new Phrase("Total : "+ facture.getTotalTTC() + " € \n", FontFactory.getFont("Cambria", 14, BaseColor.LIGHT_GRAY)));
        doc1.close();
        pdfWriter.close();
        return temp;
    }
}