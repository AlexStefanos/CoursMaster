package up5.mi.pary.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import up5.mi.pary.term.Terminal;

public class Main {
	public static void main(String [] args){
	}
}
