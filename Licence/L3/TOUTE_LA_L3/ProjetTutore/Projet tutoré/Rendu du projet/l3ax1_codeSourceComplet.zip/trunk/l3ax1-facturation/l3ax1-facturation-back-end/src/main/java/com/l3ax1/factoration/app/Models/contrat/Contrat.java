package com.l3ax1.factoration.app.Models.contrat;


import com.l3ax1.factoration.app.Models.clients.Client;
import lombok.Data;
import javax.persistence.*;
import java.time.LocalDate;

/**
 * <h1>Contrat : class</h1>
 *
 * <hr/>
 * Entity (JPA) qui représente les contrats dans la base de données.
 * <br/><br/>
 * see : {@link Client} Pour la docs des autres annotations (@Entity, @Data, @Table)
 * <hr/>
 *
 * @see  Client
 *
 * @version 1.0
 * @author lounis BOULDJA
 *
 */
@Data
@Entity
@Table(name = "contrats")
public class Contrat {

    /**
     * L’attribut id correspond à la clé primaire de la table, et est donc annoté @Id.
     * D’autre part, comme l’id est auto-incrémenté, j’ai ajouté l’annotation
     * <strong>@GeneratedValue(strategy = GenerationType.IDENTITY).<strong/>
     * @see Id
     * @see GeneratedValue
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "contrat_nom")
    private String nom;

    @Column(name = "contrat_tarif")
    private double tarif;

    @Column(name = "contrat_type_facturation")
    private String typeFacturation;

    @Column(name = "contrat_date_debut")
    private LocalDate dateDebut;

    @Column(name = "contrat_duree")
    private long duree;

    /**
     * Clé étrangère - chaque client possède un contrat.
     *
     * @see Client
     */
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "contrat_client")
    private Client client;
}
