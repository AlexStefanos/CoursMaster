package up5.mi.pary.jc.javafx.click;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ConfirmStage extends Stage {	
	private enum Reponse {INCONNU,OUI,NON;}

	private Reponse reponse = Reponse.INCONNU;
	    
		public ConfirmStage(Stage mainStage,String title,String message){
			this.setTitle(title);
			Button bOui=new Button("Oui");
			Button bNon=new Button("Non");
			bOui.setOnAction((e)-> {close();reponse=Reponse.OUI;});
			bNon.setOnAction((e)-> {close();reponse=Reponse.NON;});
			BorderPane pane = new BorderPane();
			pane.setTop(new Label(message));
			pane.setLeft(bOui);pane.setRight(bNon);
			this.initModality(Modality.APPLICATION_MODAL);
			this.initOwner(mainStage);
			Scene scene = new Scene(pane, 200, 50);
			this.setScene(scene);
			this.showAndWait();
		}
			
		public boolean isReponsePositive(){
			return reponse==Reponse.OUI;
		}
		
		
		
}
