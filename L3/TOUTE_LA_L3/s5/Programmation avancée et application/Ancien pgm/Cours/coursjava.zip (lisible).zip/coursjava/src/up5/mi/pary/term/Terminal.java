package up5.mi.pary.term;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;

public class Terminal {
	private JFrame frame = new JFrame();
	private TerminalPanel tp = new TerminalPanel();

	private static Terminal premierTerminal=null;
	/**
	 * crée un terminal conniassant son titre ainsi que ses largeur et hauteur initiales en pixels
	 * @param title le titre de la fenêtre
	 * @param initialWidth la largeur initiale en pixel
	 * @param initialHeight la hauteur initiale en pixel
	 */
	public Terminal (String title,int initialWidth,int initialHeight){
		frame.setTitle(title);
		frame.setSize(new Dimension(initialWidth,initialHeight));
		frame.setContentPane(tp);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		if (premierTerminal==null) premierTerminal=this;
		tp.addTerminalListener(new TerminalListener(){

			@Override
			public void terminalClosing() {
				frame.dispose();

			}});
	}
	/**
	 * rend le premier terminal créé
	 * @return le premier terminal créé, nul si aucun terminal n'a été créé
	 */
	public static Terminal getDefault(){
		return premierTerminal;
	}
	/**
	 * rend un byte fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return le byte fourni par l'utilisateur
	 */
	public byte readByte(String message){
		return tp.readByte(message);
	}
	/**
	 * rend un entier court fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return l'entier court fourni par l'utilisateur
	 */
	public short readShort(String message){
		return tp.readShort(message);
	}
	/**
	 * rend un entier fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return l'entier fourni par l'utilisateur
	 */
	public int readInt(String message){
		return tp.readInt(message);
	}
	/**
	 * rend un entier long fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return l'entier long fourni par l'utilisateur
	 */
	public long readLong(String message){
		return tp.readLong(message);
	}
	/**
	 * rend un nombre flottant fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return le nombre flottant fourni par l'utilisateur
	 */
	public float readFloat(String message){
		return tp.readFloat(message);
	}
	/**
	 * rend un double fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return le double fourni par l'utilisateur
	 */
	public double readDouble(String message){
		return tp.readDouble(message);
	}
	/**
	 * rend un boolean fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return le boolean fourni par l'utilisateur
	 */
	public boolean readBoolean(String message){
		return tp.readBoolean(message);
	}
	/**
	 * rend un caractère fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return le caractère fourni par l'utilisateur
	 */
	public char readChar(String message){
		return tp.readChar(message);
	}
	/**
	 * rend une chaîne de caractères fourni par l'utilisateur à partir de ce terminal
	 * @param message le message à afficher à l'utilisateur
	 * @return la chaîne de caractères fourni par l'utilisateur
	 */
	public String readString(String message){
		return tp.readString(message);
	}
	/**
	 * affiche une chaîne de caractères dans ce terminal et passe à la ligne
	 * @param string la chaîne de caractères à afficher
	 */
	public void println(String string) {tp.println(string);}
	/**
	 * affiche une chaîne de caractères dans ce terminal sans passer à la ligne
	 * @param string la chaîne de caractères à afficher
	 */
	public void print  (String string) {tp.print(string);}
	/**
	 * affiche un objet dans ce terminal et passe à la ligne
	 * Utilise la méthode toString de l'objet
	 * @param object l'objet à afficher
	 */
	public void println(Object object) {tp.println(object);}
	/**
	 * affiche un objet dans ce terminal sans passer à la ligne
	 * Utilise la méthode toString de l'objet
	 * @param object l'objet à afficher
	 */
	public void print  (Object object) {tp.print(object);}
	/**
	 * signale la fin de l'utilisation de ce terminal
	 * Des affichage sont toujours possible après mais les lectures ne sont plus possibles
	 */
	public void end() {tp.end();}

	/**
	 * affiche un entier dans ce terminal sans passer à la ligne
	 * @param i l'entier à afficher
	 */
	public void println(int i)    {tp.println(i);}
	/**
	 * affiche un entier dans ce terminal sans passer à la ligne
	 * @param i l'entier à afficher
	 */
	public void print  (int i)    {tp.print(i)  ;}
	/**
	 * affiche un entier long dans ce terminal sans passer à la ligne
	 * @param l l'entier long à afficher
	 */
	public void println(long l)   {tp.println(l);}
	/**
	 * affiche un entier long dans ce terminal sans passer à la ligne
	 * @param l l'entier long à afficher
	 */
	public void print  (long l)   {tp.print(l)  ;}
	/**
	 * affiche un flottant dans ce terminal sans passer à la ligne
	 * @param f le flottant à afficher
	 */
	public void println(float f)  {tp.println(f);}
	/**
	 * affiche un flottant dans ce terminal sans passer à la ligne
	 * @param f le flottant à afficher
	 */
	public void print  (float f)  {tp.print(f)  ;}
	/**
	 * affiche un double dans ce terminal sans passer à la ligne
	 * @param d le double à afficher
	 */
	public void println(double d) {tp.println(d);}
	/**
	 * affiche un double dans ce terminal sans passer à la ligne
	 * @param d le double à afficher
	 */
	public void print  (double d) {tp.print(d)  ;}
	/**
	 * affiche un caractère dans ce terminal sans passer à la ligne
	 * @param c le caractère à afficher
	 */
	public void println(char c)   {tp.println(c);}
	/**
	 * affiche un caractère dans ce terminal sans passer à la ligne
	 * @param c le caractère à afficher
	 */
	public void print  (char c)   {tp.print(c)  ;}
	/**
	 * affiche un booléen dans ce terminal sans passer à la ligne
	 * @param b le booléen à afficher
	 */
	public void println(boolean b){tp.println(b);}
	/**
	 * affiche un booléen dans ce terminal sans passer à la ligne
	 * @param b le booléen à afficher
	 */
	public void print  (boolean b){tp.print(b)  ;}
	/**
	 * provoque un passage à la ligne dans ce terminal
	 */
	public void println(         ){tp.println( );}
	/**
	 * modifie la fonte utilisée dans la console
	 * @param fontFamilyName le nom de la fonte à utiliser
	 */
	public void setFontFamilyName(String fontFamilyName) {
		tp.setFontFamilyName(fontFamilyName);

	}

	/**
	 * modifie la couleur de fond de la console
	 * @param color la nouvelle couleur de fond de la console
	 */
	public void setTextAreaColor(Color color){
		tp.setTextAreaColor(color);
	}
	/**
	 * modifie la couleur de fond par défaut des consoles
	 * @param color la nouvelle couleur de fond des consoles
	 */
	public static void setDefaultTextAreaColor(Color color){
		TerminalPanel.setDefaultTextAreaColor(color);
	}
	/**
	 * supprime tout le texte de la console
	 */
	public void clear(){
		tp.clear();
	}
	
	/**
	 * modifie la couleur de fond du terminal
	 * @param color la nouvelle couleur
	 */
	public void setBackground(Color color) {
		tp.setBackground(color);

	}

	/**	
	 * 	modifie la couleur du text du bouton de validation
	 * @param color la nouvelle couleur
	 */
	public void setButtonTextColor(Color color) {		
		tp.setButtonTextColor(color);		
	}

	/**
	 * modifie le label du bouton de validation
	 * @param label le nouveau text du bouton
	 */
	public void setButtonLabel(String label) {
		tp.setButtonLabel(label);

	}
	/**
	 * modifie la taille de la fonte utilisé dans la console
	 * @param size la nouvelle taille
	 */
	public void setTextAreaFontSize(int size) {
		tp.setTextAreaFontSize(size);

	}

}
