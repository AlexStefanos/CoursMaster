import React, {Component} from 'react';
import './FactureComponent.css'
import Facture from "./Facture";
import FactureService from "../../Services/FactureService";
import BoutonFacture from '../Boutons/BoutonFacture'
import ClientsService from "../../Services/ClientService";
import BarreRecherche from "../BarreRecherche/BarreRecherche";
import NavbarFacture from "./NavbarFacture";
import PageIntrouvable from "../Erreurs/PageIntrouvable";
import {BrowserRouter as Router, Redirect, Route, Switch} from "react-router-dom";
import FacturePayImp from "./FacturePayImp";
import {AjoutFacture} from "./AjoutFacture";
import FactureImp from "./FactureImp";

/**
 * Class qui contient l'affichage de la page web Facture
 */
class FactureComponent extends Component {
    state = {
        /*state sous forme de tableau pour charger les factures*/
        factures: [],
        /*state sous forme de tableau pour charger les clientd*/
        clients: [],
        /* state pour gerer l'affichage de popup d'ajout de facture*/
        isShow: false,
    }
    /**
     * Charger les factures de l'api grace a axios.get
     * &
     * charger les clients de l'api grace a axios.get
     */
    componentWillMount() {
        FactureService.getFactures().then((res) => {
            this.setState({factures: res.data})

        })
        ClientsService.getCleints().then((res) => {
            this.setState({clients: res.data})
        })
    }
    /**
     * Fonction qui va gerer l'affichage de pop-up d'ajout facture
     */
    handleShowPopupFacture = () => {
        const isShow = !this.state.isShow
        this.setState({isShow})
    }

    render() {
        /**
         *  Fonction qui affiche toutes les factures
         */
        const listeFacturePayImp =
            //Component FacturePayImp qui affiche les factures sous un tableau
            <FacturePayImp factures={Object.keys(this.state.factures)}
                           stateFacture={this.state.factures}
            />
        /**
         * Fonction qui affiche les factures impayée
         */
        const listeFactureIm =
            //Component FactureImp qui affiche les factures impayées sous un tableau
            <FactureImp
                factures={Object.keys(this.state.factures)}
                stateFacture={this.state.factures}
            />
        /**
         * Fonction qui affiche les factures payées
         */
        const listeFacture =
            //Component Facture qui affiche les factures payées sous un tableau
            <Facture factures={Object.keys(this.state.factures)}
                     stateFacture={this.state.factures}
            />
        return (
            <div className='entete'>
                {/* Component pour la barre de recherche */}
                <BarreRecherche />
                <h1>Facture</h1>
                {/* Component pour le bouton d'ajout d'une facture */}
                <BoutonFacture handleShowPopupFacture={this.handleShowPopupFacture}/>
                {/* Componentqui gère la navbar pour la factures */}
                <NavbarFacture />
                <Router>
                    <Switch>
                        <Redirect exact from='/mes-factures' to='/mes-factures/toutFacture'/>
                        <Route path='/mes-factures/toutFacture'>
                            <AjoutFacture
                                affichage={this.state.isShow}
                                handleShowPopupFacture={this.handleShowPopupFacture}
                                clients={Object.keys(this.state.clients)}
                                stateClients={this.state.clients}
                            />
                            {listeFacturePayImp}
                        </Route>
                        <Route path='/mes-factures/impayees'>
                            <AjoutFacture
                                affichage={this.state.isShow}
                                handleShowPopupFacture={this.handleShowPopupFacture}
                                clients={Object.keys(this.state.clients)}
                                stateClients={this.state.clients}
                            />
                            {listeFactureIm}
                        </Route>
                        <Route path='/mes-factures/payees'>
                            <AjoutFacture
                                affichage={this.state.isShow}
                                handleShowPopupFacture={this.handleShowPopupFacture}
                                clients={Object.keys(this.state.clients)}
                                stateClients={this.state.clients}
                            />
                            {listeFacture}
                        </Route>
                        <Route component={PageIntrouvable}/>
                    </Switch>
                </Router>
            </div>
        );
    }
}
export default FactureComponent;