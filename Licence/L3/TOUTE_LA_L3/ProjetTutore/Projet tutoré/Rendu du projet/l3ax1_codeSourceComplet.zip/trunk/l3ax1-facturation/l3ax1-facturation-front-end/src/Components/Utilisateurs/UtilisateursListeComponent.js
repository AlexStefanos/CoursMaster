 /* UtilisateursListeComponent.js
 * La liste des utilisateurs qui se sont inscrits sur le site, 
 * y compris une option pour activer un utilisateur qui s'est inscrit sur le site mais dont le compte n'est pas encore actif.
 *
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.
 * Travail_effectué : Implémentation du code (source 1) dans le projet en l'adaptant aux besoins de notre projet + ajout d'explications, certaines des explications proviennent du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
import React, { Component } from 'react';
import { getAllUsers } from '../../Services/APIUtils';
import { USERS_LIST_SIZE } from '../../Services/constants';
import { withRouter } from 'react-router-dom';
import './UtilisateursListeComponent.css';
import Utilisateur from './Utilisateur';

class UtilisateursListeComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            users: [],
            page: 0,
            size: 10,
            totalElements: 0,
            totalPages: 0,
            last: true,
            isLoading: false
        };
        this.loadUsersList = this.loadUsersList.bind(this);
        this.handleLoadMore = this.handleLoadMore.bind(this);
    }

    loadUsersList(page = 0, size = USERS_LIST_SIZE) {
        let promise = getAllUsers(page, size);

        if(!promise) {
            return;
        }

        this.setState({
            isLoading: true
        });

        promise            
        .then(response => {
            const users = this.state.users.slice();

            this.setState({
                users: users.concat(response.content),
                page: response.page,
                size: response.size,
                totalElements: response.totalElements,
                totalPages: response.totalPages,
                last: response.last,
                isLoading: false
            })
        }).catch(error => {
            this.setState({
                isLoading: false
            })
        });  
        
    }

    componentDidMount() {
        this.loadUsersList();
    }

    componentDidUpdate(nextProps) {
        if(this.props.isAuthenticated !== nextProps.isAuthenticated) {
            // Reset State
            this.setState({
                users: [],
                page: 0,
                size: 10,
                totalElements: 0,
                totalPages: 0,
                last: true,
                isLoading: false
            });    
            this.loadPollList();
        }
    }

    handleLoadMore() {
        this.loadUsersList(this.state.page + 1);
    }


    render() {
        const usersViews = [];
        this.state.users.forEach((user, userIndex) => {
            usersViews.push(<Utilisateur key={user.id} user={user} />)   
		});
         
        return (
            <div className="polls-container">
                {usersViews}
                {
                    !this.state.isLoading && this.state.users.length === 0 ? (
                        <div className="no-polls-found">
                            <span>No Polls Found.</span>
                        </div>    
                    ): null
                }  
                {
                    !this.state.isLoading && !this.state.last ? (
                        <div className="load-more-polls"> 
                            <button type="dashed" onClick={this.handleLoadMore} disabled={this.state.isLoading}>
                                Utilisateurs précédents
                            </button>
                        </div>): null
                }              
                {
                    this.state.isLoading ? 
                    "Chargement en cours.." : null                     
                }
            </div>
        );
    }
}

export default withRouter(UtilisateursListeComponent);