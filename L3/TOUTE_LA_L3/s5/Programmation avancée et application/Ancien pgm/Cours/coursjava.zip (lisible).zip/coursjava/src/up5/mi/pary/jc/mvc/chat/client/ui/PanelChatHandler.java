package up5.mi.pary.jc.mvc.chat.client.ui;

public interface PanelChatHandler {
    void messageAEnvoyer(String text);
}
