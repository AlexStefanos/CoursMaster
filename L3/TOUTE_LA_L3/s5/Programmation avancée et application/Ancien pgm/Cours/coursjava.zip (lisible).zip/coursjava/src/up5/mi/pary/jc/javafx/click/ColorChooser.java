package up5.mi.pary.jc.javafx.click;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class ColorChooser extends Stage {
	
    public final static int UNDEFINED =-1;
    public final static int OUI =0;
    public final static int NON =1;
    
    private Color color = Color.AQUA;
	    
		public ColorChooser(Window mainWindow,String title){
			this.setTitle(title);
			
			ColorPicker cp = new ColorPicker();
			
			Button bOui=new Button("Oui");
			Button bNon=new Button("Non");
			bOui.setOnAction((e)-> {close();color=cp.getValue();});
			bNon.setOnAction((e)-> {close();});
			BorderPane pane = new BorderPane();
			pane.setTop(cp);
			pane.setLeft(bOui);pane.setRight(bNon);
			this.initModality(Modality.APPLICATION_MODAL);
			this.initOwner(mainWindow);
			Scene scene = new Scene(pane, 200, 50);
			this.setScene(scene);
			this.showAndWait();

		}
		
		
		public Color getColor(){
			return color;
		}
		
		
		
}
