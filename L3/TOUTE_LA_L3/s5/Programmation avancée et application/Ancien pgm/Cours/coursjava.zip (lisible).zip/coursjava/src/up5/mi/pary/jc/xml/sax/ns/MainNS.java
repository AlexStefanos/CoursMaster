package up5.mi.pary.jc.xml.sax.ns;

import java.io.OutputStreamWriter;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import up5.mi.pary.jc.xml.sax.Repertoire;

public class MainNS {


	public static void main(String[] args)throws Exception {
		
			
		String xmlFile="repertoireNS.xml";

		SAXParserFactory spfactory = SAXParserFactory.newInstance();

		spfactory.setNamespaceAware(true);
		
		SAXParser pf = spfactory.newSAXParser();

		RepHandlerNS handler = new RepHandlerNS();
	      
	   
		pf.parse(MainNS.class.getResourceAsStream(xmlFile),handler);
		
		Repertoire repertoire = handler.getRepertoire();

		repertoire.toXml(new OutputStreamWriter(System.out));
		}

}
