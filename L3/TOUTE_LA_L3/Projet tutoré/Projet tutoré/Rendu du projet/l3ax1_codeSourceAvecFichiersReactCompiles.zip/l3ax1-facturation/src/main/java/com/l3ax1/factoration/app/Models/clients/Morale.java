package com.l3ax1.factoration.app.Models.clients;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

/**
 * <h1>Morale : Class</h1>
 *<hr/>
 * Entity jpa hérité de la classe abstraite {@link Client}. indique que le client est morale.
 * <br/>
 * {@link DiscriminatorValue} pour indiquer la valuer de type (MOR => morale).
 * <br/>
 * {@link EqualsAndHashCode} Génère des implémentations pour les méthodes equals et hashCode
 * héritées par tous les objets.
 *
 * <br/><br/>
 * see : {@link Client} Pour la docs des autres annotations (@Entity, Data)
 * <hr/>
 * @version 1.0
 * @author lounis BOULDJA
 */
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@DiscriminatorValue(value="MOR")
public class Morale extends Client {
    @Column(name = "client_forme_juridique")
    private String formeJuridique;

    @Column(name = "client_siret")
    private String siret;

    @Override
    public void copy(Client client) {
        super.copy(client);
        Morale morale = (Morale) client;
        this.siret = morale.siret;
        this.formeJuridique = morale.formeJuridique;
    }
}
