package com.l3ax1.factoration.app.utils;

import com.itextpdf.text.DocumentException;
import com.l3ax1.factoration.app.Models.clients.Physique;
import com.l3ax1.factoration.app.Models.factures.Facture;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 * Class qui gère l'envoie de la facture par mail
 */
public class EnvoiMailPdf {
    private String from = "projetl2l1descartes@gmail.com"; //non obligatoire mais c'est mieux pour ne pas être pris pour un spam
    private String username = "projetl576@gmail.com"; //le mail depuis le quel on envoi les factures
    private String password = "ProjetL3@salah"; //le mot de passe de mail

    /**
     * Méthode qui envoie une facture par mail
     * @param facture les informations de la facture
     */
    public void envoyer(Facture facture) {
        String email;
        Pdf pdf = new Pdf();

        /**
         * Etape 1 : Creation de la session
         */
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true"); //TLS pour les envois sécurisés
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587"); // 587 car on utilise TLS
        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                }); //La plupart des boites mails imposent une authentification
        try {
            /**
             * Etape 2 : Création de l'objet Message
             */
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            if (facture.getClient() instanceof Physique) {
                email = ((Physique) facture.getClient()).getEmail();
                message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(email));
            }
            message.setSubject("Votre facture numéro_"+facture.getNumeroFacture());
            Multipart mp = new MimeMultipart();
            MimeBodyPart mbp1 = new MimeBodyPart();
            mbp1.setContent("Nous vous remercions de votre confiance.\n \n Veuillez trouvez ci-joint votre facture", "text/plain");
            mp.addBodyPart(mbp1);

            FileDataSource source = new FileDataSource( pdf.remplir(facture));
            MimeBodyPart mbp = new MimeBodyPart();
            mbp.setDataHandler(new DataHandler(source));
            mbp.setFileName("feuille émargement.pdf");
            mp.addBodyPart(mbp);
            message.setContent(mp);

// Etape 3 : Envoyer le message
            Transport.send(message);
            System.out.println("fgdfg");
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}