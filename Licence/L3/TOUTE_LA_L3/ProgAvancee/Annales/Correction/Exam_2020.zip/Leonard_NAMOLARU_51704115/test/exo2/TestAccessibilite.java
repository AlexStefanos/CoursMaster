package exo2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestAccessibilite {
	static CommunauteAgglomeration communaute;
	@BeforeAll
	static void createAgglo() {
		communaute = new CommunauteAgglomeration();
		String[] villes = { "Ville1", "Ville2", "Ville3", "Ville4",};
		for (String nomVille : villes)
			communaute.ajouteVille(nomVille);

		communaute.ajouteRoute("Ville1", "Ville2");
		communaute.ajouteRoute("Ville2", "Ville3");
		communaute.ajouteRoute("Ville3", "Ville4");
	}
		
	@Test
	void testAccessibilite_01() {
		communaute.ajouteEcole("Ville1");
		communaute.ajouteEcole("Ville2");
		communaute.ajouteEcole("Ville3");
		communaute.ajouteEcole("Ville4");
		assertTrue(communaute.accessibilite());
	}
	
	@Test
	void testAccessibilite_02() {
		communaute.ajouteEcole("Ville1");
		communaute.ajouteEcole("Ville2");
		communaute.ajouteEcole("Ville3");
		communaute.ajouteEcole("Ville4");
		assertTrue(communaute.accessibilite());
	}
	
	@Test
	void testAccessibilite_03() {
		communaute.retireEcole("Ville1");
		communaute.retireEcole("Ville4");
		assertTrue(communaute.accessibilite());
	}
	
	@Test
	void testAccessibilite_04() {
		communaute.ajouteEcole("Ville1");
		communaute.ajouteEcole("Ville4");
		communaute.retireEcole("Ville2");
		communaute.retireEcole("Ville3");
		assertTrue(communaute.accessibilite());
	}
	
	@Test
	void testAccessibilite_05() {
		communaute.retireEcole("Ville1");
		assertFalse(communaute.accessibilite());
	}

}
