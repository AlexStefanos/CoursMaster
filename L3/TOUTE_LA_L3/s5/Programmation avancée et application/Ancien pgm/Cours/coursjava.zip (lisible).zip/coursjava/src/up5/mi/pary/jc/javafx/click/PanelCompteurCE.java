package up5.mi.pary.jc.javafx.click;

import up5.mi.pary.jc.util.Compteur;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

public class PanelCompteurCE extends BorderPane{

	public PanelCompteurCE(Compteur compteur){

		Button btn = new Button("OK");

		Label label =new Label("--> 0");
		btn.setOnAction(new EcouteurClick(label,compteur));

		this.setBottom(btn);
		this.setCenter(label);

	}
}

class EcouteurClick implements EventHandler<ActionEvent> {
	private Label label;
	private Compteur compteur;

	public EcouteurClick(Label label,Compteur compteur){
		this.label=label;
		this.compteur=compteur;
	}
	@Override
	public void handle(ActionEvent event) {
		compteur.incrementer(1);
		label.setText("--> "+compteur.getValue());
	}
}
