package up5.mi.pary.jc.abstrait;

public class Cercle extends Figure{

	private double rayon;

	public Cercle(double rayon){
		this.rayon=rayon;
	}

	public double getPerimetre( ){
		return 2*Math.PI*(this.rayon);
	}

	public double getAire( ){
		return Math.PI* this.rayon*this.rayon;
	}
}
