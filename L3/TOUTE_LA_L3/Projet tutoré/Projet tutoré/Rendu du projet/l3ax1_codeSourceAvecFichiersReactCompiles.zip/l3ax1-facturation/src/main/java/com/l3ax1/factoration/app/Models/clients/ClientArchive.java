package com.l3ax1.factoration.app.Models.clients;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import java.util.Objects;

/**
 * <h1>ClientArchive : class</h1>
 * <hr/>
 * Entity (JPA)  qui  représente  les  clients  Archivés dans la base de données.
 * <br/><br/>
 *
 * see : {@link Client} Pour la docs des autres annotations (@Entity, Data)
 * <hr/>
 *
 * @version 1.0
 * @author lounis BOULDJA
 */
@Data
@Entity
@Table(name = "clients_archive")
public class ClientArchive {

    /**
     * L’attribut id correspond à la clé primaire de la table, et est donc annoté @Id.
     * D’autre part, comme l’id est auto-incrémenté, j’ai ajouté l’annotation
     * <strong>@GeneratedValue(strategy = GenerationType.IDENTITY).<strong/>
     * @see Id
     * @see GeneratedValue
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "client_nom")
    private String nom;

    /**
     * le {@link Client} sotcké.
     * représente la clé étrangère (client_id) dans la base données.
     * <br/>
     *
     * {@link JsonIgnore} Annotation de marqueur qui indique que la propriété logique
     * que l'accesseur (champ, méthode getter / setter ou paramètre Creator
     * (du constructeur annoté JsonCreator ou de la méthode d'usine) doit être ignorée
     * par la fonctionnalité de sérialisation et de désérialisation basée sur
     * l'introspection.
     *
     * @see OneToOne
     * @see JoinColumn
     *
     **/
    @OneToOne(cascade = CascadeType.ALL )
    @JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_clients"))
    @JsonIgnore
    private Client client;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientArchive that = (ClientArchive) o;
        return Objects.equals(nom, that.nom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nom);
    }
}
