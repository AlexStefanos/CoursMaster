package up5.mi.pary.jc.mvc.chat.client.controleur;




import javafx.stage.Stage;
import up5.mi.pary.jc.mvc.chat.client.ui.PanelChat;
import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.util.ui.Util;

public abstract class AbstractControleur {
	private final Chat chat ;
    private final String userName;
    private PanelChat panelChat;
	
	public AbstractControleur(String userName,Chat chat,Stage stage){
		this.userName=userName;
		this.chat=chat;
		this.panelChat= new PanelChat(chat);
		
		chat.addChatListener((c,  message) ->panelChat.messageAjoute(message));	

		panelChat.setHandler((text) ->AbstractControleur.this.messageAEnvoyer(text));

		Util.initStage(stage,"Chat :"+userName,this.panelChat);
	}
	
	protected Chat getChat(){ return this.chat;}
	
	public String getUserName() {
		return userName;
	}

	public abstract void messageAEnvoyer(String text);
	



}