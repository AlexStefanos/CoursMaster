package up5.mi.pary.jc.javafx.compte;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import up5.mi.pary.jc.compte.exception.CompteE;
import up5.mi.pary.jc.compte.exception.CompteException;
import up5.mi.pary.jc.compte.exception.DecouvertException;
import up5.mi.pary.jc.compte.exception.MontantNulException;

public class PanelCompte extends BorderPane {

	/** le compte affiché par ce panel*/
	private CompteE compte;
	/** la zone de texte contenant le montant des opérations*/
	private TextField textMontant = new TextField();
	/** la zone de texte contenant le solde du compte*/
	private TextField textSolde = new TextField();
	/** la zone de texte contenant l'historique des opérations*/
	private TextArea textareaHisto = new TextArea();
	/** la zone de texte contenant les messages d'erreurs*/
	private TextArea messageErreur = new TextArea();


	public PanelCompte(CompteE compte){
		this.compte=compte;

		this.textMontant.setPrefColumnCount(10);
		this.textSolde.setPrefColumnCount(10);
		this.textareaHisto.setPrefColumnCount(14);
		this.textareaHisto.setPrefRowCount(10);
		this.messageErreur.setPrefRowCount(1);
		this.messageErreur.setEditable(false);
		
		Button buttonCredit = new Button("CREDIT");
		Button buttonDebit  = new Button("DEBIT");

		Button buttonAnnuler = new Button("Annuler la dernière opération");
		Button buttonQuitter = new Button("Traitement du compte terminé");
		

		FlowPane panelHaut=new FlowPane();
		panelHaut.setAlignment(Pos.CENTER);
		BorderPane panelMontant = new BorderPane();
		panelMontant.setLeft(new Label("Montant "));
		panelMontant.setRight(this.textMontant);
		panelHaut.getChildren().add(panelMontant);
		

		GridPane panelOper = new GridPane();
		panelOper.add(buttonCredit,1,1);
		panelOper.add(buttonDebit,1,2);
		panelHaut.getChildren().add(panelOper);

		BorderPane panelHistoSolde = new BorderPane();
		BorderPane panelSolde = new BorderPane();
		panelSolde.setLeft(new Label("Solde : "));
		panelSolde.setRight(this.textSolde);
		panelHistoSolde.setLeft(new Label("Historique : ") );
		this.textareaHisto.setEditable(false);
		ScrollPane jsp=new ScrollPane(this.textareaHisto);
		panelHistoSolde.setRight(jsp);
		panelHistoSolde.setBottom(panelSolde);
		panelHaut.getChildren().add(panelHistoSolde);
		
		BorderPane panelBas = new BorderPane();
		panelBas.setTop(buttonAnnuler);
		panelBas.setCenter(new ScrollPane(this.messageErreur));
		panelBas.setBottom(buttonQuitter);

		this.setTop(panelHaut);
		this.setBottom(panelBas);
		
		buttonQuitter.setOnAction((event)->{
			try {
				compte.sauvegarder( );
				PanelCompte.this.getScene().getWindow().hide();
			}           
			catch (Exception exp){messageErreur.setText("Problème de sauvegarde :"+exp.getMessage());exp.printStackTrace();}});

		buttonCredit.setOnAction((e)->addOperation(true));
		buttonDebit.setOnAction((e)->addOperation(false));
		buttonAnnuler.setOnAction((e)->annulerDerniereOperation());

		miseAJourInfo( );
	}


	private void miseAJourInfo( ){

		this.textareaHisto.setText(this.compte.getHistorique( ));

		java.text.DecimalFormat df = new java.text.DecimalFormat("0.00");
		this.textSolde.setText(df.format(this.compte.getSolde( )));

		this.messageErreur.setText("");
	}

	private void addOperation(boolean credit){
		try {
			double m = Double.valueOf(this.textMontant.getText( )).doubleValue( );

			this.compte.addOperation(credit ? m : -m); 
			this.miseAJourInfo( );
		}
		catch (DecouvertException e) {
			this.messageErreur.setText("Operation ignoree "+e);}
		catch (MontantNulException e){this.messageErreur.setText(e.getMessage( ));}
		catch (CompteException e){this.messageErreur.setText(""+e);}

	}
	private void annulerDerniereOperation(){
		try {
			this.compte.annulerDerniereOperation( );
			this.miseAJourInfo( );
		}
		catch (CompteException e) {this.messageErreur.setText(""+e);}
	}
}




