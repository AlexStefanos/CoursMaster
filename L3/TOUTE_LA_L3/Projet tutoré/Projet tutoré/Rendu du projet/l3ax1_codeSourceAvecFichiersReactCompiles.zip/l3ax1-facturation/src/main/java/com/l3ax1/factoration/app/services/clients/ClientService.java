package com.l3ax1.factoration.app.services.clients;

import com.l3ax1.factoration.app.Models.clients.*;
import com.l3ax1.factoration.app.Models.contrat.Contrat;
import com.l3ax1.factoration.app.repository.clients.*;
import com.l3ax1.factoration.app.services.contrat.ContratService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <h1>ClientService: class</h1>
 * <hr/>
 *
 * La couche service est dédiée au métier. C’est-à-dire appliquer des traitements
 * dictés par les règles fonctionnelles de l’application. Et également un pont entre
 * {@link com.l3ax1.factoration.app.controllers.clients.ClientController}  et
 * {@link ClientRepository}.Intérêt que chaque méthode a pour unique objectif
 * d’appeler une méthode de {@link ClientRepository}
 * <br/>
 *
 * {@link Service}  tout comme l’annotation @Repository, c’est une spécialisation
 * de @Component. Son rôle est donc le même, mais son nom a une valeur sémantique
 * pour ceux qui lisent le code.
 *
 * <hr/>
 * @see ClientRepository
 * @see Physique
 * @see Service
 *
 * @version 1.0
 * @author lounis BOULDJA
 */
@Service
@Data
public class ClientService {

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    ContratService contratService;

    /**
     * recuprer la liste des clients de la base de donnée
     *
     * @return la list des client
     */
    public Iterable<Client> getClients() {
        /*findAll <=> a slect * from table*/
        return this.clientRepository.findAll();
    }

    /**
     * Créer un client Morale et l'ajouter dans la base de données <br/>
     * table <strong>clients</strong> le type doit etre "MOR".
     *
     * @param  moraleClient le client a ajouté
     * @return client morale
     */
    public Morale creatMoraleClient(Morale moraleClient){
        moraleClient.getClientActuel().setClient(moraleClient);
        return this.clientRepository.save(moraleClient);
    }

    /**
     * Créer un client Phusique et l'ajouter dans la base des données
     *
     * @param   physiqueClient le client a ajouté
     * @return  le client physique.
     */
    public Physique createPhysiqueClient(Physique physiqueClient){
        physiqueClient.getClientActuel().setClient(physiqueClient);
        return this.clientRepository.save(physiqueClient);
    }

    /**
     * <h2>Recuprer un client de la base de données par son id</h2>
     * see : table clients
     *
     * @param id id de client
     * @return client
     */
    public Optional<Client> getClientById(Long id) {
        return this.clientRepository.findById(id);
    }

    /**
     * <h2>Sauvgarder/maj le client dans la base de données</h2>
     *
     * see : table clients
     * @param  client client a sauvgardé
     * @return le client apres l'ajout.
     */
    public Client saveClient(Client client) {
        return this.clientRepository.save(client);
    }

    /**
     *
     * @param id
     * @return
     */
    public List<Contrat> getClientContratsById(Long id) {
        return this.clientRepository.getContratList(id);
    }

    public Morale creatMoraleClientWithContrat(Morale moraleClient, Contrat contrat){
        moraleClient.getClientActuel().setClient(moraleClient);
        contrat.setClient(moraleClient);
        this.contratService.saveContrat(contrat);
        return this.clientRepository.save(moraleClient);
    }

    /**
     * Créer un client Phusique et l'ajouter dans la base des données
     *
     * @param   physiqueClient le client a ajouté
     * @return  le client physique.
     */
    public Physique createPhysiqueClientWithContrat(Physique physiqueClient, Contrat contrat){
        physiqueClient.getClientActuel().setClient(physiqueClient);
        contrat.setClient(physiqueClient);
        return this.clientRepository.save(physiqueClient);
    }
}
