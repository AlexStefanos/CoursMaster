package up5.mi.pary.jc.xml.dom;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class Main {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		File dir = new File("src/up5/mi/pary/jc/xml/dom");
		Document document = Util.getDocumentFromXmlFile(new File(dir,"repertoire.xml"));
		
		Util.parcourir(document, "");
        Util.documentToXml(document, new StreamResult(new File(dir,"sortie.xml")));
        
        Repertoire rep = Repertoire.getRepertoire(document);
        
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(new File(dir,"sortie2.xml"))))
        {rep.toXml(writer);}
	}

}
