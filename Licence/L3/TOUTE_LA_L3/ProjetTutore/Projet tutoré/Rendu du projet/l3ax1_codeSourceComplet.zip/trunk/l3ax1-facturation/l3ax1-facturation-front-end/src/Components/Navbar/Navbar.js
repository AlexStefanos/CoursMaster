/*
 * Navbar.js - Component qui affiche la navbar
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.
 * Des parties du code (source 1) ont été intégrées dans notre projet et elles ont été adaptées aux besoins de notre projet. Ajout d'explications à partir du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
import React, { Component } from 'react';
import {withRouter} from 'react-router-dom';

import './Navbar.css';
import MenuItems from './MenuItems'
import BoutonNavbarQE from '../Boutons/BoutonNavbarQE'
import logo from '../../Images/logo.png'

class Navbar extends Component {
    constructor(props) {
        super(props);
        this.logout = this.logout.bind(this);
    }

    logout() {
        this.props.onLogout();
    }

    /**
     * cliquer : pour gérer le clique du bouton connexion
     */
    state = {
        cliquer: false
    }
    /**
     *  Fonction qui change la valeur de 'cliquer' par false ou true pour gérer le clique sur les navs
     *
     * @param  event la valeur à mettre
     */
    handleClick = (event) => {
        event.preventDefault()
        this.setState({cliquer: !this.state.cliquer})
    }

    render() {
        return (
            <nav className='NavbarItems'>
                <img className="iconNav" src={logo} alt="Projet L3AX1" title="Projet L3AX1"/>
                <div className='menu-icon' onClick={this.handleClick}>
                    <i className={this.state.cliquer ? 'fas fa-times' : 'fas fa-bars'}></i>
                </div>
                <ul className={this.state.cliquer ? 'nav-menu active' : 'nav-menu'}>
                    {MenuItems.map((item, index) => {
                        return (
                            <li key={index}>
                                <a className={item.cName} href={item.url}>
                                    {item.title}
                                </a>
                            </li>
                        )
                    })}
                </ul>
                {/*bouton pour se déconnecter dans la barre de nav */}
                <BoutonNavbarQE>
                    <a href="/logout" className="btn-deco" name="logout" id="logout" onClick={this.logout}> Déconnexion </a>
                </BoutonNavbarQE>
            </nav>
        );
    }
}

export default withRouter(Navbar);