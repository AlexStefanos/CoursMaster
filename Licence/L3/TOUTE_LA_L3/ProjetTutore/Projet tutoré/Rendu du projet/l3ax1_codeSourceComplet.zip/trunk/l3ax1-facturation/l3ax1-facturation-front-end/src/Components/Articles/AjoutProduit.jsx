import {InputRef} from "../utils/UtilsComponent";
import {useForm} from "react-hook-form";
import {Fragment} from "react";
import {useHistory} from "react-router-dom";

const TVAType = ({register}) => {
    return <Fragment>
        <label className="utils-label">TVA</label>
        <select name="tauxTva" className="utils-input" ref={register}>
            <option/>
            <option value="20 % - Normal">20 % - Normal</option>
            <option value="10 % - Réduit">10 % - Réduit</option>
            <option value="8.5 % - Réduit">8.5% - Réduit</option>
            <option value="7 % - Réduit">7 % - Réduit</option>
            <option value="5.5 % Réduit">5.5 % Réduit</option>
            <option value="0 % - Éxonéré">0% - Éxonéré</option>

        </select>
    </Fragment>
}


export default function AjoutProduit({addArticle}) {

    let {register, handleSubmit, errors} = useForm()
    const history = useHistory()
    function onSubmit(data) {
        addArticle(data)
    }
    return <div className="popup-add">
        <form  onSubmit={handleSubmit(onSubmit)} className="form-edit-article">
            <h1>Ajouter Produit</h1>
            <h3>Type</h3>
            <div className="type-produit">
                <label>
                    <input type="radio" name="typeProduit" value="article" ref={register}/>
                    Article
                </label>

                <label>
                    <input type="radio" name="typeProduit" value="service" ref={register}/>
                    Service
                </label>
            </div>
            <InputRef labelValue="Nom" name="nom" register={register} err={errors}/>
            <InputRef labelValue="Prix HT" name="prixHt" register={register} err={errors}/>
            <TVAType register={register()}/>

            <div className="popup-btn-container">
                <button className="btn-cancel" type="button" onClick={() => history.push("/mes-produits")}>annuler
                </button>
                <button className="btn-add" type="submit">Ajouter</button>
            </div>
        </form>
    </div>
}