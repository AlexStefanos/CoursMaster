package up5.mi.pary.jc.mvc.util.ui;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class Util {

	public static Stage createStage (Stage stage, String title,Pane pane){
		Stage newStage = new Stage();
		newStage.initOwner(stage);
        initStage(newStage,title,pane);
		return stage;
	}


	public static void initStage(Stage stage,String title,Pane pane){
		stage.setTitle(title);

		Scene scene = new Scene(pane);
		stage.setScene(scene);
		
		stage.show();
		
	}
}
