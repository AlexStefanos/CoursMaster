package up5.mi.pary.jc.compte.exception;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class CompteE implements java.io.Serializable{
	
	private String nomTitulaire;
	private double solde=0;
	private List<Double> historique= new ArrayList<>();
	private double decouvertAutorise;
	
	/** construit un compte pour une personne
	 * nommée 'nomTitulaire' sans versementInitial */
	public CompteE(String nomTitulaire) throws CompteException{
	    this(nomTitulaire,0,0);
	}

	/** construit un compte pour une personne
	 * nommée 'nomTitulaire', avec un versement initial et un découvert autorisé spécifique */
	public CompteE(String nomTitulaire, double versementInitial, double decouvertAutorise) throws CompteException{ 
	   this.nomTitulaire=nomTitulaire;
	   this.setDecouvertAutorise(decouvertAutorise);
	   if (versementInitial!=0)
		   this.addOperation(versementInitial);
	}


	/** enregistre une opération de 'montant' Euros sur ce compte avec le 'moyenPaiement' indiqué
	   * @param montant le montant de l'opération
	   */
	public void addOperation(double montant) throws CompteException{
	  if (montant ==0)
		  throw new MontantNulException("Operation avec un montant nul !");
	  else if (montant+solde<-this.decouvertAutorise)
		  throw new DecouvertException(montant,this);
	    else{
	     this.historique.add(montant);
	     this.solde  = this.solde +  montant;
	     }
	}

	/** @return le nom du titulaire de ce compte */
	public String getNomTitulaire( ) {
	return this.nomTitulaire;
	}
	/** @return le solde de ce compte */
	public double getSolde( ) {
	return this.solde;
	}
	/** @return le découvert autorisé de ce compte */
	public double getDecouvertAutorise( ) {
	return this.decouvertAutorise;
	}
	/** modifie le découvert autorisé de ce compte */
	public void setDecouvertAutorise( double decouvertAutorise) {
	   this.decouvertAutorise=decouvertAutorise;
	}
	/** teste si le solde est insuffisant */
	public boolean isSoldeInsuffisant( ) {
	return this.solde < 0 ;
	}
	/** @return une chaîne illustrant l'historique des opérations sur ce compte */
	public String getHistorique( ) {
		StringBuilder sb = new StringBuilder();
		for (Double val:this.historique)
			sb.append(val+"\n");
		return sb.toString();
	}

	
	/**
	 * sauvegarde ce compte
	 * @return true si le compte a été sauvegardé, faux sinon
	 */
		public void sauvegarder() throws IOException{
				FileOutputStream fos = new FileOutputStream(this.getNomTitulaire());
				try (ObjectOutputStream oos = new ObjectOutputStream(fos)){
					oos.writeObject(this);
					}
		}
		
		/**
		 * 
		 * @param nomTitulaire le nom du titulaire du compte à récupérer
		 * @return le compte chargé 
		 * @throws ClassNotFoundException 
		 */
		public static CompteE recuperer(String nomTitulaire) throws IOException, ClassNotFoundException{
			FileInputStream fis = new FileInputStream(nomTitulaire);
			try (ObjectInputStream ois =new ObjectInputStream(fis)){
				return (CompteE)ois.readObject();
			}
		}

		public void annulerDerniereOperation() throws CompteVideException {
			if (this.historique.size()==0)
				throw new CompteVideException(this.getNomTitulaire());
			solde-=this.historique.get(this.historique.size()-1);
			this.historique.remove(this.historique.size()-1);
			
		}
		
		
}

