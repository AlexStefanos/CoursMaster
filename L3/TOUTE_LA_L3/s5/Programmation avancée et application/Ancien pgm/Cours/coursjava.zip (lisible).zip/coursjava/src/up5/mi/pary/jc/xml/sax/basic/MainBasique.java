package up5.mi.pary.jc.xml.sax.basic;

import java.io.File;
import java.io.OutputStreamWriter;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import up5.mi.pary.jc.xml.sax.Repertoire;

public class MainBasique {
	public static void main(String[] args)throws Exception {

		SAXParserFactory spf = SAXParserFactory.newInstance();
		SAXParser pf = spf.newSAXParser();

		RepHandler handler = new RepHandler();

		pf.parse(MainBasique.class.getResourceAsStream("repertoire.xml"),handler);
		
		Repertoire repertoire = handler.getRepertoire();

		repertoire.toXml(new OutputStreamWriter(System.out));
		}

}
