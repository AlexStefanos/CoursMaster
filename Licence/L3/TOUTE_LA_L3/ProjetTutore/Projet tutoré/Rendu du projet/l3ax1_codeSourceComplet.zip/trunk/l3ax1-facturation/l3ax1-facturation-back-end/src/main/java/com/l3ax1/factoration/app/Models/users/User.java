/*
 * User.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1 et 2.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 */
package com.l3ax1.factoration.app.Models.users;

import org.hibernate.annotations.NaturalId; // Cela spécifie qu'une propriété fait partie de l'identifiant naturel de l'entité.

import lombok.Builder.Default;

import javax.persistence.*;
import javax.validation.constraints.Email; // La chaîne doit être une adresse e-mail bien formée.
import javax.validation.constraints.NotBlank; // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size; // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
import java.util.HashSet; // Cette classe implémente l'interface Set
import java.util.Set; // Une collection qui ne contient aucun élément en double


/**
 *  Une Entité (JPA) qui représente les utilisateurs dans la base de données.
 *  Chaque utilisateur aura un ou plusieurs rôles (ROLE_ADMIN, ROLE_USER..) 
 *  Les rôles associés à un utilisateur seront utilisés à l'avenir pour décider 
 *  si l'utilisateur est autorisé à accéder à une ressource particulière 
 *  sur notre serveur ou non.
 *  
 * {@link Entity} : la classe correspond à une table de la BDD.
 * {@link Table} : le nom de la table.
  
 * @version 1.0
 * @author Leonard NAMOLARU
 */
@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
            "username"
        }),
        @UniqueConstraint(columnNames = {
            "email"
        })
})
public class User {
    @Id // Spécifie la clé primaire d'une entité.
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Fournit la spécification de stratégies de génération pour les valeurs des clés primaires.
    private Long id;

    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(max = 40) // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    private String name;

    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(max = 15) // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    private String username;

    @NaturalId // Cela spécifie qu'une propriété fait partie de l'identifiant naturel de l'entité.
    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(max = 40) // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    @Email // La chaîne doit être une adresse e-mail bien formée.
    private String email;

    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(max = 100)  // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    private String password;
    
    private int userApproved; // Un nouvel utilisateur qui s'inscrit ne peut se connecter à son compte qu'après avoir été approuvé par un administrateur.

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new HashSet<>();
    
    /**
     * Constructeur vide (Constructeur par défaut).
     */
    public User() {

    }
    
    /**
     * Constructeur - Créer une nouvelle instance de l'objet User
     * @param name Nom et prénom de l'utilisateur.
     * @param username	Nom d'utilisateur (pour une future connexion au site)
     * @param email Adresse électronique
     * @param password Mot de passe pour une future connexion au site
     */
    public User(String name, String username, String email, String password) {
        this.name = name;
        this.username = username;
        this.email = email;
        this.password = password;
        this.userApproved = 0; // Un nouvel utilisateur qui s'inscrit ne peut se connecter à son compte qu'après avoir été approuvé par un administrateur.
    }
    
    /**
     * La fonction renvoie la valeur actuelle du champ userApproved.
     * @return La valeur actuelle du champ userApproved.
     */
    public int getUserApproved() {
        return userApproved;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du champ userApproved.
     * @param userApproved La valeur pour le champ userApproved.
     */
    public void setUserApproved(int userApproved) {
        this.userApproved = userApproved;
    }
    
    /**
     * La fonction renvoie la valeur actuelle de l'identifiant unique de l'utilisateur
     * @return L'identifiant unique de l'utilisateur
     */
    public Long getId() {
        return id;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle de l'identifiant unique de l'utilisateur.
     * @param id L'identifiant unique de l'utilisateur
     */
    public void setId(Long id) {
        this.id = id;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du nom d'utilisateur
     * @return Nom d'utilisateur (pour une future connexion au site)
     */
    public String getUsername() {
        return username;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du nom d'utilisateur (pour une future connexion au site).
     * @param username Nom d'utilisateur (pour une future connexion au site)
     */
    public void setUsername(String username) {
        this.username = username;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du nom et prénom de l'utilisateur.
     * @return Nom et prénom de l'utilisateur.
     */
    public String getName() {
        return name;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du nom et prénom de l'utilisateur.
     * @param name Nom et prénom de l'utilisateur.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * La fonction renvoie la valeur actuelle de l'adresse électronique de l'utilisateur.
     * @return Adresse électronique
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle de l'adresse électronique de l'utilisateur.
     * @param email Adresse électronique
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du mot de passe de l'utilisateur.
     * @return Mot de passe pour une future connexion au site
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du mot de passe de l'utilisateur.
     * @param password Mot de passe pour une future connexion au site
     */
    public void setPassword(String password) {
        this.password = password;
    }
   
    /**
     * La fonction renvoie les rôles associés à l'utilisateur.
     * @return Les rôles associés à l'utilisateur
     */
    public Set<Role> getRoles() {
        return roles;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour les rôles associés à l'utilisateur.
     * @param roles Les rôles associés à l'utilisateur
     */
    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}