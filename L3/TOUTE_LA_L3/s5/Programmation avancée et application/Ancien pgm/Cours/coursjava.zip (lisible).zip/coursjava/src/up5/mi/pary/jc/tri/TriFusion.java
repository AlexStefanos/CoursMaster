package up5.mi.pary.jc.tri;

import up5.mi.pary.jc.util.UtilTab;
import up5.mi.pary.term.Terminal;

public class TriFusion {
	
	
	/** le tableau 't' etant trie d'une part entre les indice 'imin' et 'milieu'-1 et d'autre part entre les indices 'milieu' et 'imax',

	 *   le tableau 't' est rendu trié entre les indices 'imin' et 'imax'

	 */

	public static void fusion(int[]t,int imin,int milieu,int imax){

	int i1=imin,i2=milieu;

	int [] tab = new int[imax-imin+1];

	for (int i=0;i<tab.length;i++)

	   if ((i2>imax)||((i1<milieu)&&(t[i1]<=t[i2])))

	         {tab[i]=t[i1];i1=i1+1;}

	    else {tab[i]=t[i2];i2=i2+1;}

	for (int i=0;i<tab.length;i++)t[imin+i]=tab[i];

	}



	/** tri par fusion du tableau 't' entre les indices 'imin' et 'imax'*/

	public static void triFusion(int[]t,int imin,int imax){

	if (imin!=imax)

	  {int milieu=(imin+imax)/2+1;

	   triFusion(t,imin,milieu-1);

	   triFusion(t,milieu,imax);

	   fusion(t,imin,milieu,imax);

	   }

	}

	/** tri par fusion du tableau 't' entre les indices 'imin' et 'imax'*/

	public static void triFusion(int[]t){
		triFusion(t,0,t.length-1);
	}
	

public static void main(String[] args) {
	Terminal term = new Terminal("Tri par fusion",400,400);
	int [] tab = {6,2,9,1,4,0,10,8};
	triFusion(tab);
	UtilTab.afficher(term, tab);
}
}
