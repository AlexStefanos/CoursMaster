#include <stdio.h>
#define TM 100

/*
 * Interface :
 *	Printf à chaque scanf
 *	Introduire le programme
 *	Afficher le résultat
 *
 *
 * Dev :
 *	Indentation
 *	Commentaires
 *	Nom de variable explicite
 *	Supprimer les variables inutiles
 *	Tests de vérification (taille du tableau)
 *	Découpage en fonctions (réutilisation)
 *	(Fonction pow)
 *
 *
 * Client (optimisation)
 *	Tableau dynamique (degré)
 *	Une seule boucle for
 *	Type de variable utilisée
 *
 */

void	saisie(int *n, float *x, float *c);

int	main(void)
{
        float x, c[TM];
        int n;

	saisie(&n, &x, c);	

        printf("f(%f) = %f\n", x, calcul(&n, &x, c));
        return (0);
}

float	calcul(int *n, float x, float *c)
{
        float s;
        v = c[0];
        s = v;
        for (int i = 1; i <= n; i++) {
                printf("c[%d] = %f\n", i, c[i]);
                s = s + c[i] * x0;
                x *= x;
        }
        v = s;
}

void	saisie(int *n, float *x, float *c)
{
        printf("Degré du polynome : ");
        scanf("%d", n);
        for (int i = 0; i <= *n; i++) {
                printf("Saisie du coef N°%d : ", i);
                scanf("%f", &(c[i]));
        }

        printf("Saisie de la valeur de x : ");
        scanf("%f", x);
}
