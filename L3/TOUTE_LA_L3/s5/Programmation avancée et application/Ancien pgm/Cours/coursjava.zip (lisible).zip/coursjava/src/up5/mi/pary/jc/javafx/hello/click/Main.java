package up5.mi.pary.jc.javafx.hello.click;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import up5.mi.pary.jc.util.Compteur;

public class Main extends Application {

	@Override
	public void start(Stage stage) {
		
		stage.setTitle("Cliquer !");
		Compteur compteur = new Compteur();
		
		Button btn = new Button("OK");
		 
		Label label =new Label("--> 0");
		btn.setOnAction(new EcouteurClick(label,compteur));

		BorderPane root = new BorderPane();
		root.setBottom(btn);
		root.setCenter(label);

		Scene scene = new Scene(root, 200, 50);
		stage.setScene(scene);
		stage.show();


	}
	public static void main(String[] args) {
		launch(args);
	}
}