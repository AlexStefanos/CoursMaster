
# L3AX Facturation
***
### ¤ Back-end
* Spring-boot
* postgreSQL

### ¤ front-end
* HTML
* CSS
* ReactJs