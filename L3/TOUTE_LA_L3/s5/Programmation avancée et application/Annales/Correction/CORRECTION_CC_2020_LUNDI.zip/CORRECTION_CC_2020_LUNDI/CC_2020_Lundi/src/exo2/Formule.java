package exo2;

public enum Formule {
	DEMI_PENSION, PENSION;
}
