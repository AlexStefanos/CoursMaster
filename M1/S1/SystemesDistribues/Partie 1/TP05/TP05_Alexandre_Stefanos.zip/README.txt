Ordre d'exécution :
    1) java -jar Server.jar port
    2) java -jar Client.jar host port filePath
    3) java -jar PopServer.jar port fileName
    4) java -jar Gossiper.jar user baseDirectory portUDP portTCP host