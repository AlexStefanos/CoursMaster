package exo1;

public class NombreBinaire extends Number implements Comparable<NombreBinaire> {

	/**
	 * Ne pas tenir compte de cet attribut, qui est present pour assurer la
	 * compatibilite avec l'interface Serializable.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Les bits du nombre binaire. bits[0] represente le bit de poids faible, tandis
	 * que bits[bits.length - 1] represente le bit de poids fort.
	 */
	private boolean[] bits;

	/**
	 * Cree un nombre binaire de 32 bits, dont la valeur est le nombre entier 0.
	 */
	public NombreBinaire() {
		bits = new boolean[32];
		
		for(int i = 0 ; i < bits.length ; i++)
			bits[i] = false;
	}

	/**
	 * Cree un nombre binaire avec un nombre de bits donne, dont la valeur est le
	 * nombre entier 0.
	 * 
	 * @param nbBits le nombre de bits du nombre binaire
	 */
	public NombreBinaire(int nbBits) {
		bits = new boolean[nbBits];
		
		for(int i = 0 ; i < bits.length ; i++)
			bits[i] = false;

	}

	/**
	 * Cree un nombre binaire a partir d'un tableau de booleens qui representent les
	 * bits.
	 * 
	 * @param bits les bits du nombre binaire
	 */
	public NombreBinaire(boolean[] bits) {
		this.bits = bits;
	}

	/**
	 * Cree un nombre binaire avec un nombre de bits donne, dont la valeur est
	 * donnee en parametre. Attention : si la valeur est trop grande pour etre
	 * representee sur le nombre de bits voulus, vous devez prevoir cela et creer un
	 * tableau plus grand.
	 * 
	 * @param nbBits le nombre de bits du nombre binaire
	 * @param val    la valeur entiere a representer
	 */
	public NombreBinaire(int nbBits, int val) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int intValue() {
		throw new UnsupportedOperationException();
	}

	@Override
	public long longValue() {
		return this.intValue();
	}

	@Override
	public float floatValue() {
		return this.intValue();
	}

	@Override
	public double doubleValue() {
		return this.intValue();
	}

	/**
	 * Modifie le nombre entier pour representer l'entier suivant. Attention : si la
	 * nouvelle valeur est trop grande pour etre representee avec le nombre de bits
	 * actuel, vous devez prevoir cela et creer un tableau plus grand.
	 */
	public void incrementer() {
		NombreBinaire num2 = new NombreBinaire(bits.length, (this.intValue() + 1));
		bits = num2.bits;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder("");
		for(int i = bits.length - 1 ; i <= 0 ; i++)
			result.append( (bits[i]) ? 1 : 0);
		
		return result.toString();
	}

	@Override
	public int compareTo(NombreBinaire n) {
		int num1 = this.intValue();
		int num2 = n.intValue();
		
		if( num1 < num2 )
			return -1;
		
		if( num1 > num2 )
			return 1;

		return 0;
	}

}
