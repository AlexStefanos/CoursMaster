package up5.mi.pary.jc.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import up5.mi.pary.jc.jdbc.compte.CompteBD;
import up5.mi.pary.jc.jdbc.compte.BD;
import up5.mi.pary.jc.jdbc.compte.CompteInconnuException;

@SuppressWarnings("serial")
public class CompteServlet extends HttpServlet  {
	// méthode appelée une fois dès après la création de la servlet
	public void init(ServletConfig config)throws ServletException{
		try {
			// pour déterminer l'emplacement de bd.properties
			String path = config.getServletContext().getRealPath("/WEB-INF/bd.properties");
			BD.init(path);
		} 
		catch (Exception e) {throw new ServletException(e);}
	}

	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException {
		// type mime du résultat retourné
		res.setContentType("text/html");
		// récupère le flux de sortie  vers le client
		res.setCharacterEncoding("UTF-8");
		PrintWriter out = res.getWriter( );
		out.println("<html>");
		out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");
		out.println("<head><title>Votre solde</title></ head >");
		out.println("<body>");
		out.println("<font size=\"+3\">Application Comptes Bancaires<br/></font>");
		out.println(getTexte(req.getParameter("nom")));
		out.println("</ body >");
		out.println("</ html >");
	}
	
	public String getTexte(String nomTitulaire){
	if (nomTitulaire==null){
		return("Aucun compte fourni");
	}
	else {
		try {
			CompteBD compte= CompteBD.getCompte(nomTitulaire, false);
			return(nomTitulaire+", votre solde est de "+compte.getSolde()+" \u20AC");
		}
		catch (CompteInconnuException exp){	return("Compte inexistant : "+nomTitulaire);}
		catch (Exception exp){
			StringWriter sw = new StringWriter();
			exp.printStackTrace(new PrintWriter(sw));
			return("Erreur interne"+sw.toString());}
		}
	}


}
