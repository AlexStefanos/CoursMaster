package up5.mi.pary.jc.swing.hello;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import up5.mi.pary.jc.util.Compteur;
public class TestFenetreCompteurMouseOver {

	public static void main(String [ ] args){
		Compteur compteur = new Compteur( );
		JFrame frame = new JFrame("Cliquez !");
		Container pane = frame.getContentPane( );
		JLabel label = new JLabel("Compteur : 0"); pane .add(label,BorderLayout.NORTH);
		JButton bOk = new JButton("OK");pane.add(bOk,BorderLayout.SOUTH);
		// cr�er un �couteur d'�v�nements
		MouseListener ecouteur =new EcouteurMouseClick (compteur,label);
		// 'ecouteur' devient un �couteur d'�v�nements pour
		// les passage sur le bouton bOK
		bOk.addMouseListener(ecouteur);
		frame.pack( );
		frame.setVisible(true);
	}}

class EcouteurMouseClick extends MouseAdapter{
	private Compteur compteur ;// le compteur du nombre de clicks
	private JLabel label ; // le label dont on veut modifier le texte

	public EcouteurMouseClick (Compteur compteur, JLabel label){
		this.compteur = compteur ;
		this.label = label ;
	}
	public void mouseEntered(MouseEvent e){
		this.compteur .incrementer(1) ;
		this.label.setText("Compteur : "+this.compteur.getValue( )+"  ") ;
	}
}
