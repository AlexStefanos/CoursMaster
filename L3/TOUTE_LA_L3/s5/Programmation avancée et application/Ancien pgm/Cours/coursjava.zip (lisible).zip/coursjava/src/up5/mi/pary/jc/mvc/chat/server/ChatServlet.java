package up5.mi.pary.jc.mvc.chat.server;

import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.chat.common.Message;


@SuppressWarnings("serial")
public class ChatServlet extends HttpServlet {

	private ChatCommunicationServeur comm;
	@Override
	public void init(){
		this.comm = new ChatCommunicationServeur(new Chat());
	}
		@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/octet-stream");
		Object res=null;
		String type = request.getParameter("type");
		if ("getMessages".equals(type))
			res=comm.getMessages(Integer.parseInt(request.getParameter("indexFrom")));
		else if ("addMessage".equals(type))
			comm.addMessage(new Message(request.getParameter("user"),request.getParameter("text")));
		ObjectOutputStream os = new ObjectOutputStream(response.getOutputStream());
		os.writeObject(res);
	}

}
