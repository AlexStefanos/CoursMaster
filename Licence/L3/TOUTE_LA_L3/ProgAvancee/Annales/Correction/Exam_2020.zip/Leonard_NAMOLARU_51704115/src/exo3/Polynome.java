package exo3;

import java.util.HashMap;
import java.util.Map;

public class Polynome implements IPolynome {
	private Map<Integer, Integer> polynome;
	
	public Polynome(Map<Integer, Integer> polynome) throws IllegalArgumentException {
		for(Integer degre : polynome.keySet()) {
			if(degre < 0)
				throw new IllegalArgumentException("Un des degr�s pass�s en param�tre est n�gatif");
		}
		
		this.polynome = polynome;
	}

	@Override
	public int coefficient(int degre) {
		return (polynome.containsKey(degre) && polynome.get(degre) != null) ? polynome.get(degre) : 0;
	}

	@Override
	public IPolynome addition(IPolynome p) throws IllegalArgumentException{
		Map<Integer, Integer> result = new HashMap<Integer, Integer>();
		
		for(Integer degre : polynome.keySet())
			result.put(degre, polynome.get(degre) + p.coefficient(degre) );
		
		return ( new Polynome(result) );		
	}

	@Override
	public double evaluer(double x) {
		double result = 0;
		
		for(Integer degre : polynome.keySet()) {
			int coeff = polynome.get(degre);
			result += ( Math.pow(x, degre) * coeff );		
		}
		
		return result;
	}
	
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder("");
		for(Integer degre : polynome.keySet()) {
			int coeff = polynome.get(degre);
			result.append(coeff + "x^" + degre + " ");
		}
		
		return result.toString();
	}
}