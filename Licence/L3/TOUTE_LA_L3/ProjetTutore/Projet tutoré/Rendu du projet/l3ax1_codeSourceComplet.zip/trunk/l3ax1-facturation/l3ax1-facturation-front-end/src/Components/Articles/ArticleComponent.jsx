import React, { Component } from 'react';
import ProduitService from "../../Services/ProduitService";
import "./produit.css"
import ProduitList from "./ProduitList";
import BarreRecherche from "../BarreRecherche/BarreRecherche";
import {Link, Switch, Route} from "react-router-dom";
import AjoutProduit from "./AjoutProduit";


class ArticleComponent extends Component {

	constructor(props) {
		super(props);
		this.state = {
			produits : [],
			filter : ''
		}

		this.addArticle = this.addArticle.bind(this)
		this.loadProduits = this.loadProduits.bind(this)
		this.changeFilter = this.changeFilter.bind(this)
	}

	loadProduits () {
		ProduitService.getProduit().then((res) => {
			this.setState({
				produits : res.data
			})
		})
	}
	componentDidMount() {
		this.loadProduits()
	}

	addArticle (data) {

		data.tauxTva = parseFloat(data.tauxTva.split(" ")[0])
		data.prixTtc = parseFloat(data.prixHt) + parseFloat(data.prixHt) * (data.tauxTva / 100)
		data.typeProduit = (data.typeProduit === "article");
		ProduitService.createProduit(data).then(()=> {
			this.loadProduits()
			this.props.history.push("/mes-produits")
		})
	}

	changeFilter (e) {
		this.setState({
			filter : e.target.value
		})
	}

	render() {
    	return (
			<div className="produit-container">
				<BarreRecherche value={this.state.filter} onChangeValue={this.changeFilter}/>
				<h1>Produits</h1>

				<Link to="/mes-produits/add">
					<button className="btn-add">Ajouter</button>
				</Link>
				<ProduitList produits={this.state.produits} filter={this.state.filter}/>

				<Switch>
					<Route path="/mes-produits/add">
						<AjoutProduit addArticle={this.addArticle}/>
					</Route>
				</Switch>
			</div>
    	)
	}
}

export default ArticleComponent