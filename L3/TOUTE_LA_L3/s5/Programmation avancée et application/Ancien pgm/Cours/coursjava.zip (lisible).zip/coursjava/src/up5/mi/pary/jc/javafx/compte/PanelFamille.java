package up5.mi.pary.jc.javafx.compte;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import up5.mi.pary.jc.compte.exception.CompteE;
import up5.mi.pary.jc.compte.exception.CompteException;

public class PanelFamille  extends GridPane {

	public PanelFamille(String nomFamille){
		TextField textPrenom = new TextField();
		textPrenom.setPrefColumnCount(20);
		
		Button buttonCompte = new Button("Editer le compte");

		Button buttonQuitter = new Button("Quitter");
		
		BorderPane panelPrenom = new BorderPane( );
		panelPrenom.setLeft(new Label("Pr\u00E9nom "));
		panelPrenom.setRight(textPrenom);

		this.add(new Label("LES COMPTES DE LA FAMILLE "+nomFamille+"  "),1,1);
		this.add(panelPrenom,1,2);
		this.add(buttonCompte,1,3);
		this.add(buttonQuitter,1,4);

		buttonQuitter.setOnAction(new GestionnaireExit( ));

		EventHandler<ActionEvent> editListener=(e)->{
				try{
					String nomTitulaire=textPrenom.getText( )+" "+ nomFamille;
					CompteE compte= getCompte(nomTitulaire);

					final Stage stage = new Stage();
					stage.setTitle("COMPTE DE "+compte.getNomTitulaire( ));
					Scene scene = new Scene(new PanelCompte(compte));
					stage.setScene(scene);
					stage.show();
				}
				catch (CompteException exp){exp.printStackTrace();}
		};
		
		buttonCompte.setOnAction(editListener);
		textPrenom.setOnAction(editListener); 
	}
/**
 * rend le compte stocké sur fichier connaissant le nom de son titulaire
 * @param nomTitulaire
 * @return le compte correspondant à ce nom
 * @throws CompteException si une erreur empeche la creation du compte
 */
	private CompteE getCompte(String nomTitulaire) throws CompteException{
		CompteE compte;
		try {compte= CompteE.recuperer(nomTitulaire);}
		catch (Exception exp){
			compte=new CompteE(nomTitulaire);
		}
		return compte;

	}
}

