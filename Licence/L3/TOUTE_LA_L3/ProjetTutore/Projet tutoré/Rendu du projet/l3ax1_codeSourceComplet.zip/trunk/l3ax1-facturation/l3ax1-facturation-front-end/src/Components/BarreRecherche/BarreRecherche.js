/**
 * Componeent qui retourne une barre de recherche
 */
import React from 'react'
import './BarreRecherche.css'

/**
 *  fonction flechi pour retourner une barre de recherche avec un bouton
 *
 *  @param value  la valeur.
 *  @param onChangeValue fonction pour changer la valeur.
 *
 *  @returns une barre de recherche avec un bouton
 */
const BarreRecherche = ({value, onChangeValue}) => {
    return (
        <div className='rechercher'>
            <input type='text' value={value} onChange={onChangeValue} placeholder='Rechercher...' />
            <button>Rechercher</button>
        </div>
    )
}
export default BarreRecherche