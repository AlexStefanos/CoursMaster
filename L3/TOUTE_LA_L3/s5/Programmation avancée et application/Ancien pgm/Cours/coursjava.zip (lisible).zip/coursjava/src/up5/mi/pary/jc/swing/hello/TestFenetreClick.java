package up5.mi.pary.jc.swing.hello;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import up5.mi.pary.jc.util.Compteur;


public class TestFenetreClick {
	
public static void main(String [ ] args){
	
  Compteur compteur = new Compteur( );
  JFrame frame = new JFrame("Cliquez !");
  Container pane = frame.getContentPane( );
  JLabel label = new JLabel("Compteur : 0"); pane .add(label,BorderLayout.NORTH);
  JButton bOk = new JButton("OK");pane.add(bOk,BorderLayout.SOUTH);
  // cr�er un �couteur d'�v�nements
 ActionListener ecouteur =new EcouteurClick (compteur,label);
  // 'ecouteur' devient un �couteur d'�v�nements pour
  // les clicks sur le bouton bOK
  bOk.addActionListener(ecouteur);
  frame.pack( );
  frame.setVisible(true);
  }
}
