package up5.mi.pary.term.convertor;

public class DoubleConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Double.parseDouble(ch);
	}

	@Override
	public String getMessage() {
		return "double attendu";
	}

}
