package up5.mi.pary.jc.mvc.chat.common;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Message implements Serializable{

private String user , text;

public Message(String user, String text) {
  this.user = user;
  this.text = text;
   }

public String getUser( ) {
    return user;
   }
public String getText() {
    return text;
   }
@Override
public String toString( ) {
    return user+" --> "+text;
   }
}
