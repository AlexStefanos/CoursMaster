package up5.mi.pary.jc.exenum;

public enum MOIS {
	JANVIER(1),FEVRIER(2),MARS(3),AVRIL(4),MAI(5),JUIN(6),JUILLET(7),AOUT(8),SEPTEMBER(9),OCTOBRE(10),NOVEMBRE(11),DECEMBRE(12);

	private int num;
	
	private MOIS(int num){
		this.num=num;
	}
	
	public int getNum() {MOIS mois=MOIS.valueOf("er");MOIS [] tab = MOIS.values();
		return num;
	}

}



