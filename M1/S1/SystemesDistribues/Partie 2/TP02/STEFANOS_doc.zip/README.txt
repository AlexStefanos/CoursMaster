A l'exécution de mes jar, j'avais une erreur ClassNotFoundException par rapport à javax.naming.
Je n'ai pas réussi à corriger ce problème. De plus, mes departements ne sont pas finis.
Cependant, mon Gérant et mon Client étaient fonctionnels à la compilation/exécution.