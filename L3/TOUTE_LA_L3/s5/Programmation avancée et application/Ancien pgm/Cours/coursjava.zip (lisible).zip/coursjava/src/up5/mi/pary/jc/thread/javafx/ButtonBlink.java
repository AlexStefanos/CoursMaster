package up5.mi.pary.jc.thread.javafx;

import javafx.application.Platform;
import javafx.scene.control.Button;

public class ButtonBlink extends Button implements Runnable{

	private boolean continuer=true;
	public ButtonBlink() {
		this.setOnAction((e)->arreter());
	}

	public void run( ) {
		while (continuer){
			sleep(500);
			Platform.runLater(()->ButtonBlink.this.setStyle("-fx-background-color:red;"));
			sleep(500);
			Platform.runLater(()->ButtonBlink.this.setStyle("-fx-background-color:green;"));
		}
	}
	public void arreter( ){this.continuer=false;}


	private void sleep(int milliseconds){
		try {Thread.sleep(milliseconds);} 
		catch (InterruptedException e) {e.printStackTrace();}
	}

}
