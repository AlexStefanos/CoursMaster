package up5.mi.pary.jc.compte.exception;

@SuppressWarnings("serial")
public class CompteException extends Exception {
	public CompteException(String s){super(s);}

}
