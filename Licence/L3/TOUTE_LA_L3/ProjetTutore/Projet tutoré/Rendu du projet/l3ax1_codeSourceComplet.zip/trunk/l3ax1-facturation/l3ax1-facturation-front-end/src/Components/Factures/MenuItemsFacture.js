/**
 * Constante sous forme d'un tableau qui contient les information de chaque nav
 * @type {[{cName: string, title: string, url: string}, {cName: string, title: string, url: string}, {cName: string, title: string, url: string}]}
 */
const MenuItemsFacture = [
    {
        title: 'Toutes les factures',
        url: '/mes-factures/toutFacture',
        cName: 'nav-links-facture',
    },
    {
        title: 'Impayées',
        url: '/mes-factures/impayees',
        cName: 'nav-links-facture'
    },
    {
        title: 'Payées',
        url: '/mes-factures/payees',
        cName: 'nav-links-facture'
    }
    ]
export default MenuItemsFacture