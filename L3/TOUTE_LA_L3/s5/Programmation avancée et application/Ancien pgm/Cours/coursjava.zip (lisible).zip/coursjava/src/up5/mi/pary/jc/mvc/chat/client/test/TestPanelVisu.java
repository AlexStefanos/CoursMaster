package up5.mi.pary.jc.mvc.chat.client.test;

import javafx.application.Application;
import javafx.stage.Stage;
import up5.mi.pary.jc.mvc.chat.client.ui.PanelVisuChat;
import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.chat.common.ChatListener;
import up5.mi.pary.jc.mvc.chat.common.Message;
import up5.mi.pary.jc.mvc.util.ui.Util;

public class TestPanelVisu extends Application{
	
	@Override
	public void start(Stage stage) {

		
		// creation d'un chat
		Chat chat = new Chat( );
		// une fenetre de visualisation du chat
		final PanelVisuChat panel = new PanelVisuChat(chat);
		chat.addChatListener(new ChatListener(){
			public void messageAjoute(Chat chat, Message message) {
				panel.messageAjoute(message);	}
			});
		Util.initStage(stage,"PanelVisu",panel);	
		
		// programme utilisant le chat (tr�s rudimentaire pour cet exemple)
		chat.addMessage("toto","Hello !");



	}
	public static void main(String[] args) {
		launch(args);
	}

}
