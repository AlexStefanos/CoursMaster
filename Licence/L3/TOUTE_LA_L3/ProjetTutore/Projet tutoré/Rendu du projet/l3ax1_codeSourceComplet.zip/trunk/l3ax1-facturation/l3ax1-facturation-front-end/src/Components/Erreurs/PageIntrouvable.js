/*
 * PageIntrouvable.js
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
import React, { Component } from 'react';
import './Erreurs.css';
import { Link } from 'react-router-dom';

class NotFound extends Component {
    render() {
        return (
            <div className="page-not-found">
                <h1 className="title">
                    404
                </h1>
                <div className="desc">
                    La page que vous recherchez n'a pas été trouvé.
                </div>
                <Link to="/"><button class="go-back-btn">Retour à la page d'accueil</button></Link>
            </div>
        );
    }
}

export default NotFound;