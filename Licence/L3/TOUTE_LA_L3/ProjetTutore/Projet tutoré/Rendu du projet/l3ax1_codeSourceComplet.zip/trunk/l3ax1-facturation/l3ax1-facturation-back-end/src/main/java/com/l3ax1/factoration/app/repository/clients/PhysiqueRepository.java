package com.l3ax1.factoration.app.repository.clients;

import com.l3ax1.factoration.app.Models.clients.ClientArchive;
import org.springframework.stereotype.Repository;

/**
 * <h1>PhysiqueRepository: interface</h1>
 * <hr/>
 *
 * L’interface {@link PhysiqueRepository} permet d’implémenter le code qui
 * déclenche les actions pour communiquer avec  la base de données (table clients).
 * <br/>
 *
 * hérité de la class {@link ClientRepository} permet de manipuler toutes les méthodes de
 * la class mere pour la communication avec la base de données
 * <hr/>
 *
 * @see ClientRepository
 *
 * @version 1.0
 * @author lounis BOULDJA
 */
@Repository
public interface PhysiqueRepository extends ClientRepository {
}
