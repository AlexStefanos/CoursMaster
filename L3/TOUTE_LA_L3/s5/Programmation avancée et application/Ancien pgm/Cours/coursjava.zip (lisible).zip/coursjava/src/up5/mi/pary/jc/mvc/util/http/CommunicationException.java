package up5.mi.pary.jc.mvc.util.http;

@SuppressWarnings("serial")
public class CommunicationException extends Exception {

	public CommunicationException(String message) {
		super(message);	
	}
	public CommunicationException(Throwable cause) {
		super(cause);
	}
	public CommunicationException(String message, Throwable cause) {
		super(message, cause);
	}

}
