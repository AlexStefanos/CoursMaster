import React, { Component, Fragment } from 'react'
import './produit.css'


function Ligne (){
    return(
    <ul >
        <li>Produit&emsp;&emsp;&emsp;</li>
        <li>&emsp;&emsp;&emsp;Prix&emsp;&emsp;&emsp;</li>
        <li>&emsp;&emsp;&emsp;•••</li>
    </ul>
    )
}

function ListeTab(){//tuple produit
    return(
        <table>
            <thead>
                <tr>
                    <th colspan="3"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Produit</td>
                    <td>Prix</td>
                    <td>•••</td>
                </tr>
            </tbody>
        </table>
    )
}

class Produit extends Component {
    render () {
        return (
           <Fragment>
               <h1>Liste des Produits</h1>
               <button>Ajouter Produit</button>   
                <table>
                    <thead>
                        <tr>
                            <th colspan="3">&emsp;&emsp;&emsp;</th>
                        </tr>
                    </thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prix</th>
                    </tr>
                </table>
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />
                <ListeTab />

            </Fragment>  
        )
        
    }
}

export default Produit