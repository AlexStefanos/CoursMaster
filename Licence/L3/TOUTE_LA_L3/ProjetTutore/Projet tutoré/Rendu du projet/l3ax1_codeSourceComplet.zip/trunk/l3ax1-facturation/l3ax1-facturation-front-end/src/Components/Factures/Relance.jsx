import React, {Fragment, useState} from "react";
import './Relance.css'
import BoutonRelance from "../Boutons/BoutonRelance";
import EtatPayement from "../Boutons/EtatPayement";

/**
 *  Fonction qui gère l'affichage de pop up pour la relance d'une facture et qui utilise Emailjs pour l'envoi de mail de relance
 */
const Relance = ({afficher, showPopUp, facture}) => {
    let [client, setClient] = useState(false)
    const sendFeedback = (serviceID, templateId, variables) => {
        window.emailjs.send(
            serviceID, templateId,
            variables
        ).then(res => {
            setClient(true)
            console.log('le mail est envoyé avec succés !')
        })
            .catch(err => console.error('erreur :', err))
    }

    const onSubmit = () => {
        const templateId = 'template_0bz949e';
        const serviceID = 'service_projetL3';
        sendFeedback(serviceID, templateId, {
            to_name: facture.client.clientActuel.nom,
            from_name_num_fact: facture.numeroFacture,
            reply_to: facture.client.email
        })

    }
    return (
        <Fragment>
            <BoutonRelance handleShowPopupFacture={showPopUp}/>
            {afficher ?
                <div className='popup-relance'>
                    <div className='popup-inner-relance'>
                        <h3>Facture</h3>
                        <p className='infos-relance'>
                            <i className="fas fa-file-invoice"></i>
                            <span className='infos-num'>{facture.numeroFacture}</span>
                            pour
                            <span className='infos-prix'>{facture.totalTTC}</span>
                            €
                        </p>
                        <p className='infos-relance-etat'>Etat de la facture : <EtatPayement
                            etat={facture.facturePayee}/></p>
                        <div className='titre-client-afficher-relance-details'>
                                <p>
                                    <span className='info-details-relance'>Facturé à</span>
                                    <span className='info-donnee-relance'>{facture.client.clientActuel.nom}</span>
                                </p>
                                <p>
                                    <span className='info-details-relance'>Adresse</span>
                                    <span className='info-donnee-relance'>{facture.client.adresse}</span>
                                </p>
                                <p>
                                    <span className='info-details-relance'>Numéro de facture</span>
                                    <span className='info-donnee-relance'>{facture.numeroFacture}</span>
                                </p>
                                <p>
                                    <span className='info-details-relance'>Date d'émission</span>
                                    <span className='info-donnee-relance'>{facture.dateEmission}</span>
                                </p>
                        </div>
                        <h2 className='titre-relance'>Voulez-vous envoyer une relance ?</h2>
                        <button className='confirmer-btn-relance' type='submit' onClick={onSubmit}><i
                            className="fas fa-paper-plane"></i>Envoyer
                        </button>
                        <button className='close-btn-relance' onClick={showPopUp}>Retour</button>
                        {client ?
                            <div className='msg-envoie'>
                                <p className='msg-envoie-contenu'>
                                    Votre email a bien été envoyé !
                                </p>
                            </div>
                            : <Fragment />
                        }
                    </div>
                </div>
                :
                ""
            }
        </Fragment>
    )
}
export default Relance