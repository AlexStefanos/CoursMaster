import React, {useState} from 'react'
import {useForm} from "react-hook-form";
import ClientService from "../../Services/ClientService";



/**
 * Fonction (hooks) qui'ajouter un produit
 *
 * @param exitToClient   fonction pour fermer le popup
 * @return {JSX.Element} popup pour ajouter l'article'
 */
export default function AddArticleComponent({exitToClient}) {

    const [statut, setStatut] = useState('physique')
    const {register, handleSubmit, errors} = useForm({
        defaultValues: {
            statut: 'physique'
        }
    });


    /**
     * ajouter le produit dans la liste et fermé le popup
     * @param data les données saisies
     */
    const onSubmit = (data) => {

        if (data.statut === 'physique') {
            const clt = ClientService.createClientFromData(data)
            ClientService.createPhysiqueClient(clt).then(
                exitToClient()
            )
        } else {
            const clt = ClientService.createClientFromData(data)
            ClientService.createMoraleClient(clt).then(
                exitToClient()
            )
        }
    }

    /**
     * recuperer la valeur de statut
     * @param e event
     */
    const changeStatut = (e) => setStatut(e.target.value)

    /**
     * composante
     * @return {JSX.Element} Client Morale si statut=morale.
     */
    const getStatut = () => (statut === 'morale')
        ? null
        : null

    return (
        <div className="popup-add">
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="popup-container">
                    <h1>Ajouter un client</h1>
                    <div className="popup-info">
                        <h3>Statut</h3>
                        <div className="statut">
                            <label>
                                <input type="radio" name="statut" value="Article" onClick={changeStatut}
                                       ref={register}/>
                                Article
                            </label>
                            <label>
                                <input type="radio" name="statut" value="Service" onClick={changeStatut} ref={register}/>
                                Service
                            </label>
                        </div>
                        {
                            getStatut()
                        }


                        <div className='info'>
                            <label>Informations Produit</label>
                            <input type='text' name="nom" placeholder="Nom" ref={register({required: true})}/>
                            <input type='text' name="pht" placeholder="Prix HT" ref={register({required: true})}/>
                        </div>

					<select id="tva" name="pickup_place">
                        <option value="zero" selected="selected">0 % - Éxonérée </option>
                        <option value="cinq" >5.5 % - Réduite </option>
						<option value="sept" >7.5 % - Réduite </option>
                        <option value="dix" >10 % - Réduite </option>
                        <option value="vingt" >20 % - Normale </option>
                        <option value="perso" >Personnalisé </option>  
                    </select>
                        <div className="info info-tva">
                            <div>
                                <label>Prix TTC</label>
                                <input type='text' name="localisation" ref={register({required: true})}/>
                            </div>
                        </div>

                    </div>
                    <div className="popup-foot">
                        <button className="btn-cancel" type="button" onClick={exitToClient}>Annuler</button>
                        <button className="btn-add" type="submit">Ajouter le client</button>
                    </div>
                </div>
            </form>
        </div>

    )
}