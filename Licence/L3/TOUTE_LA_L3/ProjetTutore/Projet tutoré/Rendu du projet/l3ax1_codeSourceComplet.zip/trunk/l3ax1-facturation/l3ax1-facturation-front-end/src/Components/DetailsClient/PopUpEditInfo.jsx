import {useForm} from "react-hook-form";
import {useHistory, useLocation, useRouteMatch} from "react-router-dom";
import React from "react";
import {InputRef} from "../utils/UtilsComponent";

/**
 * <h1>Edit Client </h1>
 * --------------------------------------------------------------
 * Popup pour modifier les details d'un client.
 *
 * @return {JSX.Element} afficher le popup pour modifier le client.
 * ---------------------------------------------------------------
 * @see useLocation, useForm
 *
 * @version 1.0
 * @author Lounis BOULDJA
 */
export default function PopUpEditInfo() {

    const idClient = useRouteMatch().params.id;
    const location = useLocation()
    const history = useHistory()

    const getDefalutValue = () => {
        let defaultValue = {}
        location.data.map((info) => {
            if (info[1] === "solde")
                return null;
            defaultValue[info[1]] = info[2]
        })
        return defaultValue
    }
    /**
     * Retourner à la page de detailsClient.
     */
    const exitHandler = () => {
        history.push("/DetailsClient/" + idClient)
    }
    const {register, handleSubmit, errors} = useForm({
        defaultValues: getDefalutValue(location.data)
    });

    return (
        <div className="popup-add">
            <form className="form-edit-client" onSubmit={handleSubmit(location.setData)}>
                {
                    location.data.map((info) => {
                        let [label, name] = info
                        if (label === 'solde')
                            return null;
                        return (
                            <div key={info.toString()}>

                                <InputRef name={name} labelValue={label} register={register} err={errors}
                                          messageErr="champ ivalide"/>
                            </div>
                        )
                    })
                }
                <button type={"submit"} className="btn-add">sauvgarder</button>
                <button type="button" onClick={exitHandler} className="btn-cancel">annuler</button>
            </form>
        </div>
    )
}

