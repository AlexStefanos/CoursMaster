package up5.mi.pary.jc.jdbc.compte;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class BD {

	private static Properties load(String fileName) throws IOException, FileNotFoundException{
		System.out.println("Filename="+fileName+"\n"+new File(fileName).getAbsolutePath());
		
		try (FileInputStream fis =new FileInputStream(fileName) ){
			Properties properties = new Properties();
			properties.load(fis);
			return properties;
		}
		catch (IOException e) {System.out.println(new File(fileName).getAbsolutePath());
		throw e;}
	}

	private static Properties properties;

	public static  void init( ) throws Exception {
		properties=load("bd.properties");
		Class.forName(properties.getProperty("driver"));
	}
	public static  void init(String fileName) throws Exception {
		properties=load(fileName);
		Class.forName(properties.getProperty("driver"));
	}

	/** rend une connection à la base de données*/
	public  static Connection getConnection( ) throws SQLException{
		return DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("login"),properties.getProperty("password"));
	}

}
