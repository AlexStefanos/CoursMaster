import React from 'react'
import './BoutonNavbarQE.css'

/**
 * Fonction qui nous retourne un bouton correspondant à une relance d'une facture
 * @param handleShowPopupFacture le paramètre à passer pour gèrer onClick
 * @returns {JSX.Element} bouton
 */
const BoutonRelance = ({handleShowPopupFacture}) => {
    return (
        <button className='btn-relance' onClick={handleShowPopupFacture}><i className="fas fa-money-check-alt"></i> Relancer</button>
    )
}
export default BoutonRelance