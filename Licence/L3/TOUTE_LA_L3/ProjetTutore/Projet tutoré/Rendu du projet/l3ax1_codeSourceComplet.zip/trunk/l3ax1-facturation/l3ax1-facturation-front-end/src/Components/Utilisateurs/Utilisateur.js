 /* Utilisateur.js
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.
 *
 * Travail_effectué : Implémentation du code (source 1) dans le projet en l'adaptant aux besoins de notre projet + ajout d'explications, certaines des explications proviennent du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
import React, { Component } from 'react';
import { activateUser } from '../../Services/APIUtils';
import './Utilisateur.css';

class Utilisateur extends Component {
	    constructor(props) {
        super(props);
        this.state = {
            id: {
                value: ''
            }
        }
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(event) {
        event.preventDefault();
        activateUser(this.props.user.id)
        .then(response => {
			alert("OK !");
			document.write("<script>location.replace('/mes-utilisateurs')</script>");
        }).catch(error => {
			alert('Pardon! Un probleme est survenu. Veuillez reessayer!');
        });
    }
	
    render() {
        return (
            <div className="utilisateur-content">
                <div className="utilisateur-header">
                    <div className="utilisateur-info">
                            <span className="utilisateur-id">
                                {this.props.user.id}
                            </span>
                            <span className="utilisateur-username">
                                @{this.props.user.username}
                            </span>
                    </div>
                    <div className="utilisateur-name">
                    	{this.props.user.name}
                    </div>
                </div>
                <div className="utilisateur-email">
                    {this.props.user.email}
                </div> 
                <div className="utilisateur-approbation" onClick={this.handleSubmit}>
                    {this.props.user.userApproved === 0 ? "Cliquez ici pour activer l'utilisateur !" : ""} 
                </div>
            </div>
        );
    }
}

export default Utilisateur;
