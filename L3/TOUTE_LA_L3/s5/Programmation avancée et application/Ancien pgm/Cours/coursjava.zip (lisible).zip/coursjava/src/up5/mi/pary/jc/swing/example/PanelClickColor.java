package up5.mi.pary.jc.swing.example;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import up5.mi.pary.jc.util.Compteur;

@SuppressWarnings("serial")
public class PanelClickColor extends JPanel{

	public PanelClickColor (Compteur compteur){
		super(new BorderLayout( ));
		JLabel label = new JLabel("Compteur : "+0); 
		this.add(label,BorderLayout.NORTH);
		JButton bOk = new JButton("OK");
		this.add(bOk,BorderLayout.SOUTH);

		JButton bChoixCouleur = new JButton("Changer de couleur");
		this.add(bChoixCouleur ,BorderLayout.EAST);

		// cr�er un �couteur d'�v�nements et le mettre � l'�coute des deux boutons
		GestionnaireClickColor ecouteur=new GestionnaireClickColor(this,compteur,label);
		bOk.addActionListener(ecouteur);
		bChoixCouleur.addActionListener(ecouteur);
	}
}


class GestionnaireClickColor implements ActionListener{
	private JComponent component;private JLabel label;private Compteur compteur;

	public GestionnaireClickColor(JComponent component,
			Compteur compteur,JLabel label){
		this.component=component;
		this.compteur=compteur;
		this.label=label;}
	public void actionPerformed(java.awt.event.ActionEvent event){
		JButton button = (JButton) event.getSource( );
		if (button.getText( ).equals("OK")){
			this.compteur.incrementer(1);
			this.label.setText("Compteur : "+this.compteur.getValue( )+"  ");
		}
		else {	
			Color c=JColorChooser.showDialog(this.component,"Choisir une couleur",Color.blue);
			this.label.setForeground(c);
		}}
}
