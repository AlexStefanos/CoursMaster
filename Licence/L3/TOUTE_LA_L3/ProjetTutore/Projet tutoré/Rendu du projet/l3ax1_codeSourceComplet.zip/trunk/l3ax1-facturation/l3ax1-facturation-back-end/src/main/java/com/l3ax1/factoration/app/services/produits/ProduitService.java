package com.l3ax1.factoration.app.services.produits;

import com.l3ax1.factoration.app.Models.produits.*;
import com.l3ax1.factoration.app.repository.produits.ProduitRepository;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * <h1>ClientService: class</h1>
 * <hr/>
 *
 * La couche service est dédiée au métier. C’est-à-dire appliquer des traitements
 * dictés par les règles fonctionnelles de l’application. Et également un pont entre
 * {@link com.l3ax1.factoration.app.controllers.clients.ClientController}  et
 * {@link ClientRepository}.Intérêt que chaque méthode a pour unique objectif
 * d’appeler une méthode de {@link ClientRepository}
 * <br/>
 *
 * {@link Service}  tout comme l’annotation @Repository, c’est une spécialisation
 * de @Component. Son rôle est donc le même, mais son nom a une valeur sémantique
 * pour ceux qui lisent le code.
 *
 * <hr/>
 * @see ClientRepository
 * @see Physique
 * @see Service
 *
 * @version 1.0
 * @author SAGHROUN Amos
 */
@Service
@Data
public class ProduitService {

    @Autowired
    ProduitRepository produitRepository;

    /**
     *
     * @return
     */
    public Iterable<Produit> getProduit() {//retourne tous les produits enregistrés de la BDD
    	return this.produitRepository.findAll();
    }

    /**
     * créer un produit.
     * @param produit produit
     * @return produit
     */
    public Produit createProduit(Produit produit) {
        return this.produitRepository.save(produit);
    }


}
