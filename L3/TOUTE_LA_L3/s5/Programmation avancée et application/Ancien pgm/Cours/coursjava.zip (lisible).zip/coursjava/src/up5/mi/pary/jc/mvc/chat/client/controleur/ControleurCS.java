package up5.mi.pary.jc.mvc.chat.client.controleur;

import java.net.URLEncoder;
import java.util.List;

import javafx.application.Platform;
import javafx.stage.Stage;
import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.chat.common.ChatCommunication;
import up5.mi.pary.jc.mvc.chat.common.Message;
import up5.mi.pary.jc.mvc.util.http.CommunicationException;
import up5.mi.pary.jc.mvc.util.http.HttpCommunication;

public class ControleurCS extends AbstractControleur {

	private final ChatCommunication comm;

	public ControleurCS(Stage stage,String userName,String urlServeur){
		super(userName,new Chat(),stage);
		comm = new ChatCommunicationClient(urlServeur);
		new ThreadMessage().start();
	}

	@Override
	public void messageAEnvoyer(String text)  {
		try {
			comm.addMessage(new Message(getUserName(),text));
		} catch (CommunicationException e) {
			afficheMessageAdmin("Problème réseau : message non transmis");
		}

	}

	private void afficheMessageAdmin(String text){
		Platform.runLater( ()->getChat().addMessage(new Message("admin",text)));
	}
	private class ThreadMessage extends Thread{
		public ThreadMessage(){
			this.setDaemon(true);
		}
		public void run(){
			while (true){
				try {Thread.sleep(1000);} catch (InterruptedException exp){exp.printStackTrace();}
				List<Message> messages;
				try {
					messages = comm.getMessages(getChat().getMessagesCount());
					for (final Message message : messages)
						Platform.runLater( ()->getChat().addMessage(message));;
				} 
				catch (CommunicationException e) {
					afficheMessageAdmin("Problème réseau : nouveaux messages non récupérés");
				}
			}
		}
	}

	private static class ChatCommunicationClient extends HttpCommunication implements ChatCommunication {

		public ChatCommunicationClient(String urlServlet) {
			super(urlServlet);
		}


		@SuppressWarnings("unchecked")
		@Override
		public List<Message> getMessages(int indexFrom) throws CommunicationException {
			return (List<Message>)getObjectFromServlet("?type=getMessages&indexFrom="+indexFrom);
		}

		@Override
		public void addMessage(Message message) throws CommunicationException {
			getObjectFromServlet("?type=addMessage&user="+URLEncoder.encode(message.getUser())+"&text="+URLEncoder.encode(message.getText()));
		}
	}



}
