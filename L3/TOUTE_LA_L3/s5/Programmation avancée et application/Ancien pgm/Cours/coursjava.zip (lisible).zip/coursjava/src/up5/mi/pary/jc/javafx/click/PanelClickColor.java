package up5.mi.pary.jc.javafx.click;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import up5.mi.pary.jc.util.Compteur;

public class PanelClickColor extends BorderPane{

	private Label label=new Label("--> 0");;
	private CheckBox checkBox=new CheckBox("dix par dix");

	public PanelClickColor(Compteur compteur){
		Button button = new Button("OK");
		Button buttonColor= new Button("changer");
		EventHandler<ActionEvent> handler = 			(event) -> {
			if (event.getSource()==button){
			compteur.incrementer(checkBox.isSelected()?10:1);
			label.setText("--> "+compteur.getValue());
			}
			else {
				ColorChooser colorChooser= new ColorChooser(getScene().getWindow(),"Choisir une couleur");
				label.setTextFill(colorChooser.getColor());
			}

		};

		button.setOnAction(handler);
		buttonColor.setOnAction(handler);

		this.setTop(buttonColor);
		this.setBottom(button);
		this.setCenter(this.label);
		this.setRight(this.checkBox);

	}
}
