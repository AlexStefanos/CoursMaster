const MenuItems = [
{
    title: 'Factures',
    url: '/mes-factures',
    cName: 'nav-links'
},
{
    title: 'Clients',
    url: '/mes-clients',
    cName: 'nav-links'
},
{
    title: 'Produits',
    url: '/mes-produits',
    cName: 'nav-links'
},
{
    title: 'Contrats',
    url: '/mes-contrats',
    cName: 'nav-links'
},
{
    title: 'Utilisateurs',
    url: '/mes-utilisateurs',
    cName: 'nav-links'
},
{
    title: 'Se déconnecter',
    url: '#',
    cName: 'nav-links-mobile'
}
]
export default MenuItems