package up5.mi.pary.jc.javafx.click;

import up5.mi.pary.jc.util.Compteur;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

public class PanelClickPlusMoins extends BorderPane{

	public PanelClickPlusMoins(Compteur compteur){
		Button buttonPlus = new Button("+1");
		Button buttonMoins = new Button("-1");

		Label label =new Label("--> 0");
		

		EventHandler<ActionEvent> handler = (event) -> {
			compteur.incrementer(event.getSource()==buttonPlus?1:-1);
			label.setText("--> "+compteur.getValue());
		};
		
		buttonPlus.setOnAction(handler);
		buttonMoins.setOnAction(handler);
		
		this.setTop(buttonPlus);
		this.setBottom(buttonMoins);
		this.setCenter(label);

	}
}