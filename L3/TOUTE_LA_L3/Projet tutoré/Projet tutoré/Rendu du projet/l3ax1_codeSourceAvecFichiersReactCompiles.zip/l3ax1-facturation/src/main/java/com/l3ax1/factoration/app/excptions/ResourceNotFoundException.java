package com.l3ax1.factoration.app.excptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * <h1>ResourceNotFoundException : class d'exception</h1>
 * <hr/>
 *
 * Lever une exception si la ressource demandée n’existe pas.
 * <br/>
 * <ul>
 *     <li>
 *         {@link ResponseStatus}
 *         <p>
 *             Marque une méthode  ou une classe  d'exception avec le  code d'état
 *             à renvoyer. Le code d'état  est appliqué à la réponse  HTTP lorsque
 *             la méthode du gestionnaire est appelée et remplace les informations
 *             d'état définies par d'autres moyens, comme ResponseEntity
 *         </p>
 *     </li>
 *     <li>
 *         {@link HttpStatus}
 *         <p>
 *             Énumération des codes d'état HTTP.
 *         </p>
 *     </li>
 *     <li>
 *         {@link RuntimeException}
 *         <p>
 *             RuntimeException est la  superclasse  des exceptions qui peuvent  être
 *             levées pendant le fonctionnement normal de  la machine virtuelle  Java.
 *             RuntimeException et ses sous-classes sont des exceptions non vérifiées.
 *             Les exceptions non vérifiées n'ont pas besoin d'être déclarées dans la
 *             clause throws d'une méthode ou d'un constructeur si elles peuvent être
 *             levées par l'exécution de la méthode ou du constructeur et se propager
 *             en dehors de la limite de la méthode ou du constructeur.
 *         </p>
 *     </li>
 * </ul>
 * <hr/>
 *
 * @see ResponseStatus
 * @see com.l3ax1.factoration.app.controllers.clients.ClientController;
 * @see RuntimeException
 *
 * @author Lounis BOULDJA
 * @version 1.0
 */
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

    /**
     * <h2>Constructeur pour lever l'exception</h2>
     *
     * @param message   message à afficher
     */
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
