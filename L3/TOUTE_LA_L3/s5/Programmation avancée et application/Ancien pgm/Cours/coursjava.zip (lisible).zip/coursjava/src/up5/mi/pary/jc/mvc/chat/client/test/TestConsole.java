package up5.mi.pary.jc.mvc.chat.client.test;

import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.chat.common.ChatListener;
import up5.mi.pary.jc.mvc.chat.common.Message;

public class TestConsole {
	
	public static void main(String[] args) {
		// cr�ation d'un chat
		Chat chat = new Chat( );

		// un �couteur des �v�nements en provenance de ce chat
		chat.addChatListener(
				new ChatListener( ){
			@Override
			public void messageAjoute(Chat chat, Message message) {
				System.out.println("Un nouveau message pour le chat ! "+message);
			}
		});
		
		// programme utilisant le chat (tr�s rudimentaire pour cet exemple)
		chat.addMessage("toto","Hello !");
		
		
		
	}
}
