package com.l3ax1.factoration.app.services.clients;

import com.l3ax1.factoration.app.Models.clients.ClientArchive;
import com.l3ax1.factoration.app.repository.clients.ClientArchiveRepositpry;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <h1>ClientArchiveService : class</h1>
 * <hr/>
 *
 * La couche service est dédiée au métier. C’est-à-dire appliquer des traitements
 * dictés par les règles fonctionnelles de l’application. Et également un pont entre
 * {@link com.l3ax1.factoration.app.controllers.clients.ClientController}  et
 * {@link ClientArchiveRepositpry}.Intérêt que chaque méthode a pour unique objectif
 * d’appeler une méthode de {@link ClientArchiveRepositpry}
 * <br/>
 *
 * {@link Service}  tout comme l’annotation @Repository, c’est une spécialisation
 * de @Component. Son rôle est donc le même, mais son nom a une valeur sémantique
 * pour ceux qui lisent le code.
 *
 * <hr/>
 * @see ClientArchiveRepositpry
 * @see Service
 *
 * @version 1.0
 * @author lounis BOULDJA
 */
@Service
@Data
public class ClientArchiveService {


    @Autowired
    ClientArchiveRepositpry clientArchiveRepositpry;

    /**
     * la liste des clients archivés dans la base de données.
     * table <srtong>archives_clients</srtong> equi a select *
     *
     * @return la liste des clients archivés
     */
    public Iterable<ClientArchive> getArchivedClients() {
        return clientArchiveRepositpry.findAll();
    }
}
