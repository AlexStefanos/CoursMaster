package exo2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestAccessibilite {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
