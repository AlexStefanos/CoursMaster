# TD 3 : Seuillage

Pendant ce TD les étudiants doivent créer deux plugins:
1. Un plugin qui permet de seuiller une image en niveaux de gris ayant comme entrée l'intensité du seuil.
2. Un plugin qui prend l'image seuillée (une masque) et applique la masque à l'image d'origine, ce qui permettra de présenter uniquement les objet d'interet sur l'image.

Finalement l'étudiant est demandé d'explorer la méthode de seuillage Otsu pour la comprendre et évaluer l'application de cette méthode à une image.