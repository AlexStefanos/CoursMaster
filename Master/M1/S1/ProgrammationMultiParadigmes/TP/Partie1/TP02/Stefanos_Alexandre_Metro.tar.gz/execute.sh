#!/bin/sh

java -jar Metro.jar
