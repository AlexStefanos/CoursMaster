package up5.mi.pary.term.convertor;

public class CharConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return ch.charAt(0);
	}

	@Override
	public String getMessage() {
		return "caractère attendu";
	}

}
