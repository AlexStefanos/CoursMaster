package up5.mi.pary.term.convertor;

public class FloatConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Float.parseFloat(ch);
	}

	@Override
	public String getMessage() {
		return "nombre de type float attendu";
	}

}
