package up5.mi.pary.jc.swing.example;


import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import up5.mi.pary.jc.swing.hello.EcouteurClick;
import up5.mi.pary.jc.util.Compteur;


@SuppressWarnings("serial")
public class PanelCompteur  extends JPanel{

public PanelCompteur(Compteur compteur){
  super(new BorderLayout( ));
  JLabel label = new JLabel("Compteur : "+0); 
  this.add(label,BorderLayout.NORTH);
  JButton bOk = new JButton("OK");
  this.add(bOk,BorderLayout.SOUTH);

  // cr�er un �couteur d'�v�nements
 ActionListener ecouteur =new EcouteurClick (compteur,label);
  // 'ecouteur' devient un �couteur d'�v�nements pour
  // les clicks sur le bouton bOK
  bOk.addActionListener(ecouteur);
  }
}
