package up5.mi.pary.jc.mvc.chat.client.controleur;

import javafx.stage.Stage;
import up5.mi.pary.jc.mvc.chat.common.Chat;

public class ControleurBasique extends AbstractControleur{

	public ControleurBasique(String userName,Chat chat,Stage stage){
		super(userName,chat,stage);
		
	}

	public  void messageAEnvoyer(String text){
		getChat().addMessage(getUserName(),text);
	}


}