package up5.mi.pary.jt.hello;
// un premier programme
/* la version JAVA du classique
Hello World
 */

public class HelloWorld { 

	public static void main(String [] args) { 

		System.out.println("Hello World !"); 

	}
}