import React from "react";
import {ListeFacture} from "./ListeFacture";
import './Facture.css'

/**
 * Fonction flechi qui nous retourne la mis en page des factures sous forme d'un tableau
 * @param stateFacture les factures sous forme d'un tableau
 * @returns {JSX.Element} un tableau qui contient les facture
 */
const FactureImp = ({stateFacture}) => {

    return (
        <table className='tableau-style'>
            <thead className='tableau-tete'>
            <tr>
                <th>NOM</th>
                <th>Montant</th>
                <th>ETAT</th>
                <th>N° DE FACTURE</th>
                <th>DATE D'EMISSION</th>
                <th></th>
            </tr>
            </thead>
            <tbody className='corps-tableau'>
            {stateFacture.map(facture => (
                //Component qui rempli le corp de tableau avec les facture dans la base de donnée
                <ListeFacture facture={facture} />
            ))}
            </tbody>
        </table>
    )
}
export default FactureImp