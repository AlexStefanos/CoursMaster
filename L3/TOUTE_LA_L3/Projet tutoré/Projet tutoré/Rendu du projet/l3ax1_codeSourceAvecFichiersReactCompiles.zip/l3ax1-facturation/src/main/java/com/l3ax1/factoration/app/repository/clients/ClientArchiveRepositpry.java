package com.l3ax1.factoration.app.repository.clients;

import com.l3ax1.factoration.app.Models.clients.ClientArchive;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * <h1>ClientArchiveRepositpry: interface</h1>
 * <hr/>
 * <p>
 * L’interface {@link ClientArchiveRepositpry} permet d’implémenter le code qui
 * déclenche les actions pour communiquer avec  la base de données. Bien évidemment,
 * ce code se servira de notre classe {@link ClientArchive}.
 * Et faire des  requêtes à la base de données, et le résultat nous est retourné
 * sous forme d’instances de l’objet Client.
 * <br/>
 * Spring Data JPA ! Il nous permet d’exécuter des requêtes SQL.
 * <br/><br/>
 * <p>
 * {@link CrudRepository} est une interface fournie par Spring. Elle fournit des
 * méthodes pour manipuler votre entité. Elle utilise la généricité pour que son
 * code soit applicable à n’importe quelle entité.
 * <p>
 * {@link Repository} est une annotation Spring pour indiquer que la  classe est
 * un bean, et que son rôle est  de  communiquer  avec  une  source  de  données
 * (en l'occurrence la base de données).
 * </p>
 * <p>
 * <hr/>
 *
 * @see ClientArchive
 * @see CrudRepository
 * @see Repository
 *
 * @author lounis BOULDJA
 * @version 1.0
 *
 */

@Repository
public interface ClientArchiveRepositpry extends CrudRepository<ClientArchive, Long> {
}
