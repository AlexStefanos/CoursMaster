package up5.mi.pary.jc.abstrait;

import java.util.ArrayList;
import java.util.List;

public class TestFigure {

	public static void main(String[ ] args) {

		List<Figure> list = new ArrayList<Figure>( );
		list.add(new Rectangle(56,20));
		list.add(new Cercle(30));
		list.add(new Carre(30));
		for (int i=0;i<list.size( );i++)
			list.get(i).afficher();
	}

}
