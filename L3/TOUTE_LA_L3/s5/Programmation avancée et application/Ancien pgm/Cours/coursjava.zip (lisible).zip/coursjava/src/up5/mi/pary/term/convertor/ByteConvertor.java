package up5.mi.pary.term.convertor;

public class ByteConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Byte.parseByte(ch);
	}

	@Override
	public String getMessage() {
		return "entier compris entre -128 et 127 attendu";
	}

}
