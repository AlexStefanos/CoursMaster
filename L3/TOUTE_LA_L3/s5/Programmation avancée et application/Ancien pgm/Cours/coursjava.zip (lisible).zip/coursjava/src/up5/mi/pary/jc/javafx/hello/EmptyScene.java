package up5.mi.pary.jc.javafx.hello;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class EmptyScene extends Application {

	@Override
	public void start(Stage stage) {

		stage.setTitle("Hello World");

		Pane root = new StackPane();
		Scene scene = new Scene(root, 300, 300);

		stage.setScene(scene);
		stage.show();
	}


	public static void main(String[] args) {
		launch(args);
	}

}
