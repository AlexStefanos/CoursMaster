package up5.mi.pary.jc.javafx.click;

import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import up5.mi.pary.jc.util.Compteur;

public class PanelClickCB extends BorderPane{


	public PanelClickCB(Compteur compteur){
		
		Label label=new Label("--> 0");;
		CheckBox checkBox=new CheckBox("dix par dix");
		Button button = new Button("OK");
		
		button.setOnAction(
			(event) -> {
				compteur.incrementer(checkBox.isSelected()?10:1);
				label.setText("--> "+compteur.getValue());
			}
		);

		this.setBottom(button);
		this.setCenter(label);
		this.setRight(checkBox);

	}
}
