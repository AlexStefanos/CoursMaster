package up5.mi.pary.jc.xml.dom;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Util{

	/** rend le document DOM correspondant à un fichier xml 
	 * @throws IOException */
	public static Document getDocumentFromXmlFile(File xmlFile)
			throws ParserConfigurationException, SAXException, IOException{

		// recuperation d'une fabrique de constructeur de document
		DocumentBuilderFactory fabrique = DocumentBuilderFactory.newInstance();

		// recuperation d'un constructeur de document
		DocumentBuilder builder = fabrique.newDocumentBuilder();

		// parsing du fichier avec le documentBuilder
		Document document = builder.parse(xmlFile);

		return document;
	}


	/** met dans streamResult le contenu xml correspondant au document */
	public static void documentToXml(Document document,StreamResult sortie) throws TransformerException{
		// Récupération d'une fabrique de transformeur
		TransformerFactory tfabrique = TransformerFactory.newInstance();
		// Récuperation d'un transformeur
		Transformer transformeur = tfabrique.newTransformer();

		// paramétrage du transformeur
		Properties proprietes = new Properties();
		proprietes.put("encoding", "UTF-8"); 
		proprietes.put("indent", "yes");
		transformeur.setOutputProperties(proprietes);

		// création de la source
		Source entree = new DOMSource(document);
		// utilisation du transformeur pour mettre le document sous forme xml dans sortie
		transformeur.transform(entree,sortie);
	}
	private static void afficherAttributs(Node node,String marge) {
		NamedNodeMap nnm=node.getAttributes();
		for (int i=0;i<nnm.getLength();i++) 
			System.out.print(nnm.item(i));
		System.out.println();
	}

	public static void parcourir(Node node,String marge) {
		afficherElement(node,marge);
		afficherFils(node,marge);
	}

	private static void afficherFils(Node node,String marge) {
		NodeList child=node.getChildNodes();
		for (int i=0;i<child.getLength();i++)
			parcourir(child.item(i),marge+"   ");
	}

	private static void afficherElement(Node node,String marge) {
		if (node.getNodeType()==Element.TEXT_NODE){
			if (node.getNodeValue().trim().length()>0)
				System.out.println("Texte="+node.getNodeValue());
		}
		else if (node.getNodeType()==Element.ELEMENT_NODE){
			System.out.print("Element="+node.getNodeName());
			afficherAttributs(node,marge);
		}}


}
