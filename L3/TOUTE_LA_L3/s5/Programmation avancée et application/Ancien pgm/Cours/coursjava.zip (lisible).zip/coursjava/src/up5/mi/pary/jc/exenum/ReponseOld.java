package up5.mi.pary.jc.exenum;

public class ReponseOld {

	public static ReponseOld OUI=new ReponseOld();
	public static ReponseOld NON=new ReponseOld();
	public static ReponseOld ANNULER = new ReponseOld();
	
	private ReponseOld(){}
}

