package up5.mi.pary.jc.mvc.chat.common;

import java.util.List;

import up5.mi.pary.jc.mvc.util.http.CommunicationException;



public interface ChatCommunication {
	
    public List<Message> getMessages(int indexFrom) throws CommunicationException;
    
    public void addMessage(Message message) throws CommunicationException;

	
}
