package up5.mi.pary.jc.mvc.chat.client.test;

import javafx.application.Application;
import javafx.stage.Stage;
import up5.mi.pary.jc.mvc.chat.client.controleur.ControleurBasique;
import up5.mi.pary.jc.mvc.chat.common.Chat;

public class TestControleurBasique extends Application{
	
	@Override
	public void start(Stage mainStage) {

		Chat chat=new Chat();
		int nbUIChat=3;
		for (int i=1;i<=nbUIChat;i++){
			String name = "etu"+"_"+i;
			Stage stage=new Stage();
			stage.initOwner(mainStage);
			new ControleurBasique(name,chat,stage);
		}

	}
	public static void main(String[] args) {
		launch(args);
	}

}
