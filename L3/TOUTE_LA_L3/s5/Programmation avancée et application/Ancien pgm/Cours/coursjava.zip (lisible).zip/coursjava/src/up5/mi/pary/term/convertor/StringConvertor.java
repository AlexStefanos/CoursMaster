package up5.mi.pary.term.convertor;

public class StringConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return ch;
	}

	@Override
	public String getMessage() {
		return "Erreur non documentée";
	}

}
