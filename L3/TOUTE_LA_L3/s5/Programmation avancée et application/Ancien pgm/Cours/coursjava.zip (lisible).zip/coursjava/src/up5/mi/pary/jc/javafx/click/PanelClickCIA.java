package up5.mi.pary.jc.javafx.click;

import up5.mi.pary.jc.util.Compteur;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

public class PanelClickCIA extends BorderPane{

	private Label label;

	public PanelClickCIA(Compteur compteur){
		Button button = new Button("OK");

		this.label =new Label("--> 0");
		
		button.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				compteur.incrementer(1);
				label.setText("--> "+compteur.getValue());
			}
		});

		this.setBottom(button);
		this.setCenter(label);

	}
}
