package com.l3ax1.factoration.app.services.contrat;

import com.l3ax1.factoration.app.Models.clients.Client;
import com.l3ax1.factoration.app.Models.contrat.Contrat;
import com.l3ax1.factoration.app.controllers.contrat.ContratController;
import com.l3ax1.factoration.app.repository.clients.ClientRepository;
import com.l3ax1.factoration.app.repository.contrat.ContratRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * <h1>ContratServices: class</h1>
 * <hr/>
 * <p>
 * La couche service est dédiée au métier. C’est-à-dire appliquer des traitements
 * dictés par les règles fonctionnelles de l’application. Et également un pont entre
 * {@link ContratController}  et {@link ContratRepository}.
 * Intérêt que chaque méthode a pour unique objectif d’appeler une méthode de
 * {@link ContratRepository}
 * <br/>
 * <p>
 * {@link Service}  tout comme l’annotation @Repository, c’est une spécialisation
 * de @Component. Son rôle est donc le même, mais son nom a une valeur sémantique
 * pour ceux qui lisent le code.
 * <p>
 * <hr/>
 *
 * @see ContratRepository
 * @see Service
 * <p>
 * * @author lounis BOULDJA
 * * @version 1.0
 */
@Service
public class ContratService {

    @Autowired
    ContratRepository contratRepository;

    @Autowired
    ClientRepository clientRepository;

    /**
     * <h2>Récupérer la liste des contrats de la base de données.</h2>
     *
     * @return la liste des contrats.
     */
    public Iterable<Contrat> getContrats() {
        return this.contratRepository.findAll();
    }

    /**
     * <h2>Ajouter un contrat à la base de données</h2>
     *
     * @param contrat contrat a ajouté
     * @return le contrat ajouté.
     */
    public Contrat createContrat(Contrat contrat, Long idClient) {
        if (idClient != -1) {
            Client client = this.clientRepository.findById(idClient)
                    .orElseThrow(() -> new ResourceNotFoundException("Client n'existe pas avec id :" + idClient));
            contrat.setClient(client);
            System.out.println(contrat);
        }
        return this.contratRepository.save(contrat);
    }

    /**
     * <h2>Récupérer un contrat de la base de données avec son Id</h2>
     * <p>
     * see : table contrats
     *
     * @param id id de contrat.
     * @return contrat.
     */
    public Optional<Contrat> findContratById(Long id) {
        return this.contratRepository.findById(id);
    }

    /**
     * <h2>Supprimer un contrat de la base de données.</h2>
     * <p>
     * see : table contrats.
     *
     * @param contrat contrat a supprimé.
     */
    public void deleteContrat(Contrat contrat) {
        this.contratRepository.delete(contrat);
    }

    /**
     * <h1>sauvegarder un contrat.</h1>
     *
     * @param contrat le contrat.
     * @return contrat apres la sauvgarde.
     */
    public Contrat saveContrat(Contrat contrat) {
        return this.contratRepository.save(contrat);
    }

}
