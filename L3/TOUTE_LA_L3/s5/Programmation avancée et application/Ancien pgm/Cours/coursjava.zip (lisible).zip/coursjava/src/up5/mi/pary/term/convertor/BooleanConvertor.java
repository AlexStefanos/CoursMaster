package up5.mi.pary.term.convertor;

public class BooleanConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Boolean.parseBoolean(ch);
	}

	@Override
	public String getMessage() {
		return "true ou false attendu";
	}

}
