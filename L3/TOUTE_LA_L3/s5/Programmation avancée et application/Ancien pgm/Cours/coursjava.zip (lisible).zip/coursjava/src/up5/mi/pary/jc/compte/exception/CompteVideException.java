package up5.mi.pary.jc.compte.exception;

public class CompteVideException extends CompteException {

	public CompteVideException(String nom){
		super("Aucune opération enregistrée sur le compte: "+nom);
	}
}



