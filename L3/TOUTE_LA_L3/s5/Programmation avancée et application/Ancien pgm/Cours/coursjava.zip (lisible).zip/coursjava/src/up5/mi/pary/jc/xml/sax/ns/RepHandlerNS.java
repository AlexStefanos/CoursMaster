package up5.mi.pary.jc.xml.sax.ns;

import org.xml.sax.Attributes;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import up5.mi.pary.jc.xml.sax.Repertoire;


public class RepHandlerNS extends DefaultHandler {
	private Repertoire rep;
	boolean inProprio,inNom,inTelephone;
	private String nom,tel;

	public void startElement(String uri, String localName, String rawName, Attributes atts) {
		System.out.println("uri="+uri+" localName="+localName+" rawName="+rawName);
		if (localName.equals("repertoire")){
			String creationDate = atts.getValue("creation");
			rep=new Repertoire(creationDate);
		}
		else if (localName.equals("proprietaire"))    inProprio=true;
		else if (localName.equals("telephone"))       inTelephone=true;
		else if (localName.equals("nom"))                inNom=true;
	}

	public void characters(char[ ] ch, int start, int length){

		String value=String.copyValueOf(ch, start, length).trim();
		if (inProprio)       rep.setProprietaire(value);
		else if (inNom)      nom=value;
		else if (inTelephone)tel=value;

	}
	public void endElement(String uri, String localName, String rawName) {
		if (localName.equals("proprietaire"))        inProprio=false;
		else if (localName.equals("telephone"))     inTelephone=false;
		else if (localName.equals("nom"))              inNom=false;
		else if (localName.equals("entree"))     
			rep.ajouterEntree(nom, tel);
	}


	public Repertoire getRepertoire() {
		return this.rep;
	}
	
	public void error(SAXParseException e) throws SAXParseException {
		throw e;}
	public void warning(SAXParseException e)throws SAXParseException{
		throw e;}

}

