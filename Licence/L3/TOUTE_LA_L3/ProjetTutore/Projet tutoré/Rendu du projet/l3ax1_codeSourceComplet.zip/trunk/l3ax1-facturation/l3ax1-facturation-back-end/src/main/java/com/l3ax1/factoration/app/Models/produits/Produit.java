package com.l3ax1.factoration.app.Models.produits;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data//pour générer Getters et Setters
@Entity//crée les entités de la table ds la BDD
@Table(name = "produits")
public class Produit {

    /**
     * L’attribut id correspond à la clé primaire de la table, et est donc annoté @Id.
     * D’autre part, comme l’id est auto-incrémenté, j’ai ajouté l’annotation
     * <strong>@GeneratedValue(strategy = GenerationType.IDENTITY).<strong/>
     * @see Id
     * @see GeneratedValue
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nom_produit")
    private String nom;

    @Column(name = "type_produit")
    private boolean typeProduit;

    @Column(name = "prix_ht")
    private Integer prixHt;

    @Column(name = "prix_ttc")
    private Integer prixTtc;

    @Column(name = "taux_tva")
    private Integer tauxTva;
}
