package up5.mi.pary.jc.exenum;

public enum Reponse {
	
   OUI(),NON(),ANNULER();
   
}



