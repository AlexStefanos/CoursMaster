package up5.mi.pary.jc.util;

public class UtilMath {
	
	/**@return le carré de la somme de 'a' et de 'b'*/
	public static int carreDeLaSomme(int a,int b){
		int somme=a+b;
		int carre = somme * somme;
		return carre;
	}
	
	/** @return la factorielle de 'n' */
	public static int fact(int n){
		int res;
		if (n == 0)
			res = 1;
		else res = n* fact(n-1);
		return res;
	}
	
	/** @return le pgcd de 'a' et de 'b'
	   * 'a' et 'b' sont des entiers strictement positifs */
	public static long pgcd(long a, long b){
	 while (a!=b) 
	       if (a<b) 
	             b=b-a; 
	      else a=a-b; 	
	  return(a);
	}

}
