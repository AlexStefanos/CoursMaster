package up5.mi.pary.jc.swing.hello;

import javax.swing.JFrame;

public class TestJFrame {

	public static void main(String[ ]args) {
		// cr�er une fen�tre de titre Ma premi�re Fen�tre
		JFrame frame = new JFrame("Ma premi�re fen�tre");
		// lui donner une taille de 400x300
		frame.setSize(400,300);
		// afficher la fen�tre
		frame.setVisible(true);
	}
}
