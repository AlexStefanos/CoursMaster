export default function ProduitList({produits, filter}) {

    return <table className="table-produits">
        <thead>
        <tr>
            <th>NOM</th>
            <th>TYPE</th>
            <th>PRIX HT</th>
            <th>PRIX TTC</th>
            <th>TVA</th>
        </tr>
        </thead>
        <tbody>
        {
            produits.map((produit) => (
                produit.nom.toUpperCase().indexOf(filter.toUpperCase()) === -1 ? null
                    : <tr key={produit.id}>

                        <td>{produit.nom}</td>
                        <td>{produit.typeProduit ? "Article" : "Service"}</td>
                        <td>{produit.prixHt}</td>
                        <td>{produit.prixTtc}</td>
                        <td>{produit.tauxTva}</td>
                    </tr>
            ))
        }
        </tbody>
    </table>
}