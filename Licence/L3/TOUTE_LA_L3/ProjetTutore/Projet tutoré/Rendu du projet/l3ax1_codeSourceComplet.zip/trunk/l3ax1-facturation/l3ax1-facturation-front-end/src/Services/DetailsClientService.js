    import axios from "axios";

const URL_API_CLIENTS="http://localhost:8080/clients"

/**
 * service pour les details d'un client
 * @author Lounis BOULDJA
 * @version 1.0
 */
class DetailsClientService {
    /**
     * recuprer un client de l'API par son ID
     * @param clientID id de client
     */
    getClientByID(clientID) {
        return axios.get(URL_API_CLIENTS + '/' + clientID);
    }

    /**
     * modifier un client
     * @param client  client a modifié
     * @param clientId
     */
    updatePhysiqueClient(client, clientId) {
        return axios.put(URL_API_CLIENTS + '/update_physique/' + clientId, client);
    }

    /**
     * modifier un client
     * @param client  client a modifié
     * @param clientId
     */
    updateMoraleClient(client, clientId) {
        return axios.put(URL_API_CLIENTS + '/update_morale/' + clientId, client);
    }
}

export default new DetailsClientService();