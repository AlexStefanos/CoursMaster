import React, {Fragment, useState} from "react";
import EtatPayement from "../Boutons/EtatPayement";
import DetailsFacture from "./DetailsFacture";
import Relance from "./Relance";

/**
 * fonction qui gère l'affichage de tout les factures
 */
export const ListeFacture = ({facture}) => {

    let [showDetails, setShow] = useState(false)
    let [showRelance, setShowRelance] = useState(false)
    /**
     * Fonction qui va gerer l'affichage de pop-up d'ajout facture
     */
    function handleShowPopupFacture() {
        setShowRelance(!showRelance)
    }
    /**
     * Fonction qui va gerer l'affichage de pop-up d'affichage de détails de la facture
     */
    function show() {
        setShow(!showDetails);
    }

    return (showDetails) ?
        (
            //compoent qui affiche le pop up de détails d'une facture
            <DetailsFacture facture={facture} showPopUp={show}/>
        )
        : (
            <tr key={facture.id}>
                <td onClick={show}>{facture.client.clientActuel.nom}</td>
                <td onClick={show}>{facture.totalTTC} €</td>
                <td onClick={show}>{facture.facturePayee ?
                    // compoent qui gère l'affichage de l'état de la facture
                    <EtatPayement etat={true}/>
                    :
                    // compoent qui gère l'affichage de l'état de la facture
                    <EtatPayement etat={false}/>
                }
                </td>
                <td onClick={show}>{facture.numeroFacture}</td>
                <td onClick={show}>{facture.dateEmission}</td>
                <td >{facture.facturePayee ?
                    null
                    :
                    //Component qui gère la relance d'une facture impayée
                    <Relance afficher={showRelance} showPopUp={handleShowPopupFacture} facture={facture}/>
                }
                </td>
            </tr>
        )
}
/**
 * fonction qui gère l'affichage les factures payées
 */
export const ListeFacturePayee = ({facture}) => {

    let [showDetails, setShow] = useState(false)
    /**
     * Fonction qui va gerer l'affichage de pop-up d'affichage de détails de la facture
     */
    function show() {
        setShow(!showDetails);
    }

    return (showDetails) ?
        (
            //compoent qui affiche le pop up de détails d'une facture
            <DetailsFacture facture={facture} showPopUp={show}/>
        )
        : (
            <tr key={facture.id} onClick={show}>
                {facture.facturePayee ? <Fragment>
                        <td>{facture.client.clientActuel.nom}</td>
                        <td>{facture.totalTTC} €</td>
                        <td>
                            {/* compoent qui gère l'affichage de l'état de la facture */}
                            <EtatPayement etat={true}/>
                        </td>
                        <td>{facture.numeroFacture}</td>
                        <td>{facture.dateEmission}</td>
                    </Fragment>
                    :
                    <Fragment></Fragment>
                }
            </tr>
        )
}
/**
 * fonction qui gère l'affichage les factures impayées
 */
export const ListeFactureImpayee = ({facture}) => {

    let [showDetails, setShow] = useState(false)
    let [showRelance, setShowRelance] = useState(false)
    /**
     * Fonction qui va gerer l'affichage de pop-up d'affichage de détails de la facture
     */
    function show() {
        setShow(!showDetails);
    }

    /**
     * Fonction qui va gerer l'affichage de pop-up d'ajout facture
     */
    function handleShowPopupFacture() {
        setShowRelance(!showRelance)
    }

    return (showDetails) ?
        (
            //compoent qui affiche le pop up de détails d'une facture
            <DetailsFacture facture={facture} showPopUp={show}/>
        )
        : (
            <tr key={facture.id}>
                {facture.facturePayee ?
                    <Fragment>
                    </Fragment>
                    :
                    <Fragment>
                        <td onClick={show}>{facture.client.clientActuel.nom}</td>
                        <td onClick={show}>{facture.totalTTC} €</td>
                        <td onClick={show}>
                            {/*compoent qui gère l'affichage de l'état de la facture*/}
                            <EtatPayement etat={false}/>
                        </td>
                        <td onClick={show}>{facture.numeroFacture}</td>
                        <td onClick={show}>{facture.dateEmission}</td>
                        <td>
                            {/*Component qui gère la relance d'une facture impayée*/}
                            <Relance afficher={showRelance} showPopUp={handleShowPopupFacture} facture={facture}/>
                        </td>
                    </Fragment>
                }
            </tr>
        )
}