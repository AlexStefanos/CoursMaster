import {useHistory, useRouteMatch} from "react-router-dom";

/**
 * Afficher la confirmation d'une suppression d’un contrat.
 *
 * @param deleteContrat  fonction pour  supprimer  un  contrat
 * @return {JSX.Element} pupup oui : pour supprimer le contrat
 *                             non : sinon.
 */
export default function DeleteContratConponent({deleteContrat}) {

    /*recuprer le id de contrat a supprimer.*/
    let id = useRouteMatch().params.id;
    let hist = useHistory()

    /**
     * Supprimer le contrat
     */
    function sup() {
        deleteContrat(id);
    }

    return (
        <div className="popup-add">
            <div className="popup-container">
                <h1>confirmez-vous votre choix ?</h1>
                <div className="choix-container">
                    <button onClick={sup}>OUI</button>
                    <button onClick={()=>hist.push("/Contrats")}>NON</button>
                </div>
            </div>

        </div>
    )
}