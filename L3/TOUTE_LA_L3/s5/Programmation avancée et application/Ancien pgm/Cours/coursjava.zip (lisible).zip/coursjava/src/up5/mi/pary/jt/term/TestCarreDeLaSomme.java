package up5.mi.pary.jt.term;

import up5.mi.pary.term.Terminal;

public class TestCarreDeLaSomme {
	
	public static void main(String [] tArg) {
		Terminal term = new Terminal("calcul du carr\u00E9 de la somme",300,300);
		int a = term.readInt("donner un entier:") ;
		int b= term.readInt("donner un autre entier:") ;
		term.println("le carr\u00E9 de la somme de "+a+
				" et de "+b+" vaut "+(a+b)*(a+b));
		term.end();
	}
}

