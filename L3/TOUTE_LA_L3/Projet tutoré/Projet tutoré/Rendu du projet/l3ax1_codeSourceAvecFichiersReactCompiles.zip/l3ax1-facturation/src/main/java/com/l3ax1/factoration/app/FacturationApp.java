/*
 * FacturationApp.java - La classe principale du projet
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir du tutoriels (source 1, source2)
 * Source1 : openclassrooms.com - Créez une application Java avec Spring Boot - Auteur : Romain Sessa - License CC BY-SA 4.0
 * Source2 : developer.okta.com - Add User Authentication to Your Spring Boot App in 15 Minutes - Auteur : Andrew Hughes - Copyright © 2021 Okta.
 
 * Le point d'entrée de l'ensemble de l'application.
 * Charge le framework Spring Boot.
= */
package com.l3ax1.factoration.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/* SpringBootApplication est un composé de 3 autres annotations :
 * SpringBootConfiguration : la classe sera utilisée comme une classe de configuration.
 * EnableAutoConfiguration : active la fonctionnalité d’autoconfiguration de Spring Boot.
 * ComponentScan : active le scanning de classes dans le package de la classe et dans ses sous-packages. 
 * 
 * En résumé, cette classe, c’est ce qui déclenche toute la mécanique interne de Spring Boot et des composants Spring associés. 
 */

@SpringBootApplication // L’annotation @SpringBootApplication est critique , une annotation qui indique à Spring de charger la structure de prise en charge de l'application Spring Boot
public class FacturationApp {

	public static void main(String[] args) {
		SpringApplication.run(FacturationApp.class, args); // Cette instruction permet de démarrer notre application, le nom de la classe est l'argument.
		
		//  Ce n’est pas une bonne pratique d’ajouter autre chose dans la méthode main
	}
}