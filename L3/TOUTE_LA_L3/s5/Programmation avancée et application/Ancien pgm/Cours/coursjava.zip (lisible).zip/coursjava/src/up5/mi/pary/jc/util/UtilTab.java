package up5.mi.pary.jc.util;

import up5.mi.pary.term.Terminal;

public class UtilTab {


	/** affiche les éléments du tableau 'tab' sur la sortie standard*/
	public static void afficher(int [] tab){
		for (int i = 0; i < tab.length ; i++){ 
			System.out.print(tab[i]); 
			if (i!=tab.length-1) 
				System.out.print(" ");
		}
		System.out.println();
	}

	/** affiche les éléments du tableau 'tab' sur le terminal 'term'*/
	public static void afficher(Terminal term,int [] tab){
		for (int i = 0; i < tab.length ; i++){ term.print(tab[i]); if (i!=tab.length-1) term.print(" ");
		}
		term.println();
	}


	/* rend un tableau de 'n' entiers demandés à l'utilisateur à l'aide du terminal 'term'*/
	public static int [] saisieTabInt(Terminal term,int n){
		int[] t =new int[n];/* le résultat est un tableau de n éléments*/
		for (int i = 0; i < n ; i++)
			t [i] = term.readInt("");/* saisie de l'élément d'indice i*/
		return t;
	}

	/** affiche les éléments du tableau 'tab' sur le terminal 'term'*/
	public static void afficher(Terminal term,String [] tab){
		for (int i = 0; i < tab.length ; i++){ term.print(tab[i]); if (i!=tab.length-1) term.print(" ");
		}
		term.println();
	}

	/* rend un tableau de 'n' entiers demandés à l'utilisateur à l'aide du terminal 'term'*/
	public static String [] saisieTabString(Terminal term,int n){
		String[] t =new String[n];/* le résultat est un tableau de n éléments*/
		for (int i = 0; i < n ; i++)
			t [i] = term.readString("");/* saisie de l'élément d'indice i*/
		return t;
	}

	/* rend la somme des éléments du tableau 'tab' */
	public static int somme (int [] tab){
		int res=0;
		for (int i = 0; i < tab.length ; i++){
			res += tab[i]; /* équivalent à res=res+tab[i]*/
		}
		return(res);
	}

	/* teste si 'e' est un élément du tableau 't'*/
	public static boolean appartient(int [] tab , int elt){
		boolean trouve=false;
		int i=0;
		while ((i<tab.length)&&(!trouve)){
			if (tab [i] == elt) 
				trouve=true;
			else i++;
		}
		return(trouve);
	}

	/** recherche l'indice du plus petit élément
	 * du tableau 'tab' entre les indices 'imin' et 'imax' */
	public static int indiceDuPlusPetit(int [] tab,int imin,int imax){
		int res = imin;
		for (int i=imin+1;i<=imax;i++)
			if (tab[i] < tab [res]) res=i;
		return(res);
	}

	/* échange les éléments 'tab'['i'] et 'tab'['j'] */
	public static void echanger(int [] tab, int i, int j){ 
		int tabj=tab [j]; 
		tab [j]=tab [i]; 
		tab [i]=tabj;
	}
}
