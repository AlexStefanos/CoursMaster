########################################## compact

### On ne prend pas en compte la 3eme colonne car elle contient les labels des classes

plot(compact[,-3])

# Matrice des distances (euclidiennes)
D <- dist(compact[,-3], method = "euclidean")

# CAH - lien minimum
H1 <- hclust(D^2, method="single")
plot(H1)
classes1 <- cutree(H1, k=3)
rect.hclust(H1,k=3)
table(classes1,compact[,3])
plot(compact[,-3],col=classes1)

# CAH - lien maximum
H2 <- hclust(D^2, method="complete")
plot(H2)
classes2 <- cutree(H2, k=3)
rect.hclust(H2,k=3)
table(classes2,compact[,3])
plot(compact[,-3],col=classes2)


# CAH - lien moyen
H3 <- hclust(D^2, method="average")
plot(H3)
rect.hclust(H3,k=3)
classes3 <- cutree(H3, k=3)
table(classes3,compact[,3])
plot(compact[,-3],col=classes3)


# CAH - lien ward
H4 <- hclust(D^2, method="ward.D")
classes4 <- cutree(H4, k=3)
table(classes4,compact[,3])
plot(compact[,-3],col=classes3)



########################################################
########################################################

########################################## irreg

plot(irreg[,-3],col=irreg[,3])

# Matrice des distances (euclidiennes)
D <- dist(irreg[,-3], method = "euclidean")

# CAH - lien minimum
H1 <- hclust(D^2, method="single")
plot(H1)
classes1 <- cutree(H1, k=2)
rect.hclust(H1,k=2)
table(classes1,irreg[,3])
plot(irreg[,-3],col=classes1)

# CAH - lien maximum
H2 <- hclust(D^2, method="complete")
plot(H2)
classes2 <- cutree(H2, k=3)
rect.hclust(H2,k=3)
table(classes2,irreg[,3])
plot(irreg[,-3],col=classes2)


# CAH - lien moyen
H3 <- hclust(D^2, method="average")
plot(H3)
rect.hclust(H3,k=3)
classes3 <- cutree(H3, k=3)
table(classes3,irreg[,3])
plot(irreg[,-3],col=classes3)


# CAH - lien ward
H4 <- hclust(D^2, method="ward.D")
classes4 <- cutree(H4, k=2)
table(classes4,irreg[,3])
plot(irreg[,-3],col=classes4)


#####################################################

########################################## closer

plot(closer[,-3],col=closer[,3])

# Matrice des distances (euclidiennes)
D <- dist(closer[,-3], method = "euclidean")

# CAH - lien minimum
H1 <- hclust(D^2, method="single")
plot(H1)
classes1 <- cutree(H1, k=3)
rect.hclust(H1,k=3)
table(classes1,closer[,3])
plot(closer[,-3],col=classes1)

###################################

# CAH - lien maximum
H2 <- hclust(D^2, method="complete")
plot(H2)
classes2 <- cutree(H2, k=3)
rect.hclust(H2,k=3)
table(classes2,closer[,3])
plot(closer[,-3],col=classes2)


# CAH - lien moyen
H3 <- hclust(D^2, method="average")
plot(H3)
rect.hclust(H3,k=3)
classes3 <- cutree(H3, k=3)
table(classes3,closer[,3])
plot(closer[,-3],col=classes3)


# CAH - lien ward
H4 <- hclust(D^2, method="ward.D")
classes4 <- cutree(H4, k=2)
table(classes4,closer[,3])
plot(closer[,-3],col=classes4)


