package up5.mi.pary.term.convertor;

public abstract class Convertor {

	private Object result;

	public Object getResult() {
		return result;
	}

	public abstract String getMessage();

	/**
	 * rend l'objet obtenu par la conversion d'une chaine
	 * 
	 * @param ch la chaîne à convertir
	 * @return l'objet obtenu par la conversion de la chaine
	 * @throws ConvertException
	 *             quand la conversion n'est pas possible
	 */
	protected abstract Object valider(String ch) throws ConvertException;

	public Object convert(String text) throws ConvertException {
		try {
			this.result = valider(text);
		} catch (Exception exp) {
			throw new ConvertException(this.getMessage());
		}
		return result;
	}
}
