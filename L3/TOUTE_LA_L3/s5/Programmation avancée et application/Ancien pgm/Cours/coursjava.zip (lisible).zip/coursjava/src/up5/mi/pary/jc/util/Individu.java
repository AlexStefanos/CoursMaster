package up5.mi.pary.jc.util;


import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Individu {
	/** le nom de cet individu */
	private String nom;
	/** le prénom de cet individu */
	private String prenom;
	/** la date de naissance de cet individu */
	private Date dateNaissance;

	/** crée un individu connaissant son 'nom', son 'prénom' et sa 'dateDeNaissance'*/
	public Individu(String nom,String prenom,Date dateDeNaissance) {
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateDeNaissance;
	}
	/** rend le nom de cet individu */
	public String getNom( ){
		return this.nom;
	}

	/** rend le prénom de cet individu */
	public String getPrenom( ){
		return this.prenom;
	}

	/** rend la date de naissance de cet individu */
	public Date getDateNaissance( ){
		return this.dateNaissance;
	}

	/** rend une chaîne de caractères composée du nom et du prénom de cet individu */ 
	public String toString( ){
		return this.nom + " "+this.prenom;
	}

	/** @return l'âge de cet individu */
	public int getAge( ){
		GregorianCalendar dActuelle = new GregorianCalendar( );

		GregorianCalendar dNaissance = new GregorianCalendar();
		dNaissance.setTime(this.dateNaissance);

		int nbAnnee = dActuelle.get(Calendar.YEAR)-dNaissance.get(Calendar.YEAR);

		// retire une unité si on n'est pas encore arrivé à l'anniversaire
		dActuelle.set(Calendar.YEAR,dNaissance.get(Calendar.YEAR));
		if (dNaissance.after(dActuelle)) nbAnnee--;

		return nbAnnee;
	}

	public static void main(String [] args){
		Date d1 = new GregorianCalendar(1989,Calendar.APRIL,6).getTime( );

		Individu i1 = new Individu("Dupond","Sylvie",d1);

		Date d2 = new GregorianCalendar(1989,Calendar.OCTOBER,6).getTime( );

		Individu i2 = new Individu("Durand","Claire",d2);

		System.out.println(new Date( ));

		System.out.println(i1+" "+i1.getAge());

		System.out.println(i2+" "+i2.getAge());
	}
}
