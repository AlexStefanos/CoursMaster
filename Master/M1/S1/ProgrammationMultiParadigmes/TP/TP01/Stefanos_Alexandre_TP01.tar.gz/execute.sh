#!/bin/sh

java -jar Recursivite.jar
