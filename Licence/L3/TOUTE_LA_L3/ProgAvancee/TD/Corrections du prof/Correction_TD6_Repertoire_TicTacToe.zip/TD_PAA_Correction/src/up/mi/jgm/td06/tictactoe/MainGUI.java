package up.mi.jgm.td06.tictactoe;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import up.mi.jgm.td06.tictactoe.gui.MainPane;

public class MainGUI extends Application {

	@Override
	public void start(Stage stage) throws Exception {
		stage.setTitle("Tic Tac Toe");
		Scene scene = new Scene(new MainPane(new TicTacToe()));
		stage.setScene(scene);
		stage.sizeToScene();
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
