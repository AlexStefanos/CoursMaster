package up5.mi.pary.jc.abstrait;

public abstract class Figure {

	public abstract double getPerimetre();

	public abstract double getAire();

	public void afficher( ){
		System.out.println("Je suis un "+getClass()
				+" de perimetre "+getPerimetre()+" et d'aire "+getAire());
	}

}
