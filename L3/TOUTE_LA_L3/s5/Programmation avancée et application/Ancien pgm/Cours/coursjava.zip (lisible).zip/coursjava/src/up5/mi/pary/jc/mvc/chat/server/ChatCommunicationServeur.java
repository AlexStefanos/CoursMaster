package up5.mi.pary.jc.mvc.chat.server;

import java.util.List;

import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.chat.common.ChatCommunication;
import up5.mi.pary.jc.mvc.chat.common.Message;

public class ChatCommunicationServeur implements ChatCommunication {

	private Chat chat;
	
	public ChatCommunicationServeur (Chat chat){
		this.chat=chat;
	}
	
	@Override
	public synchronized  List<Message> getMessages(int indexFrom) {
		return chat.getMessages(indexFrom);
	}

	@Override
	public synchronized void addMessage(Message message) {
		chat.addMessage(message);
	}

}
