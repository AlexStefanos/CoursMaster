package up5.mi.pary.term.convertor;

public class ShortConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Short.parseShort(ch);
	}

	@Override
	public String getMessage() {
		return "entier compris entre -2^15 et 2^15-1 attendu";
	}

}
