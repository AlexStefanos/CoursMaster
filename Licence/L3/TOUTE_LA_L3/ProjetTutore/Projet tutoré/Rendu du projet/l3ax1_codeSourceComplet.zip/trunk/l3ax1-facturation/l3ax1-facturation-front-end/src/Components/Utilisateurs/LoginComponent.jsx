/*
 * LoginComponent.js
 * Projet : Groupe L3AX1 - Projets Tutor�s 2020 - 2021, Licence informatique - Universit� de Paris.

 * Travail_effectu� : Impl�mentation du code (source 1) dans le projet et ajout d'explications � partir du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright � 2017-2019
 */
import React, { Component, Fragment } from 'react';
import { login, getCurrentUser } from '../../Services/APIUtils';
import './InscriptionLoginStyle.css';
import { ACCESS_TOKEN } from '../../Services/constants';
import logo from '../../Images/logo.png'
import { withRouter } from 'react-router-dom'

class LoginComponent extends Component {
    render() {
        return (
        	 <Fragment>
        	 	<img className="icon" src={logo} alt="Projet L3AX1" title="Projet L3AX1"/>
            	<div className="back-container">
               		<h3>Connectez-vous a votre compte</h3>
                	<div className="login-form">
                    <LoginForm />
                	</div>
            	</div>
            </Fragment>
        );
    }
}

class LoginForm extends Component {
    constructor(props) {
        super(props);
		this.state = {
      		currentUser: null,
      		isAuthenticated: false,
      		isLoading: false
    	}
    	this.loadCurrentUser = this.loadCurrentUser.bind(this);
   	 	this.handleLogin = this.handleLogin.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

  loadCurrentUser() {
    this.setState({
      isLoading: true
    });

    getCurrentUser()
    .then(response => {
      this.setState({
        currentUser: response,
        isAuthenticated: true,
        isLoading: false
      });
    }).catch(error => {
      this.setState({
        isLoading: false
      });  
    });
  }

  componentDidMount() {
    this.loadCurrentUser();
  }

  handleLogin() {
	alert("Vous etes connecte avec succes");
    this.loadCurrentUser();
	document.write("<script>location.replace('/mes-factures')</script>");
  }

    handleSubmit(event) {
        event.preventDefault();   
                const loginRequest = {'usernameOrEmail' : document.getElementById('usernameOrEmail').value , 'password' : document.getElementById('password').value};
                login(loginRequest)
                .then(response => {
                    localStorage.setItem(ACCESS_TOKEN, response.accessToken);
					this.handleLogin();
                }).catch(error => {
                    if(error.status === 401) {
						alert("Votre nom d'utilisateur ou votre mot de passe est incorrect ou que votre utilisateur n'a pas encore ete approuve par l'administrateur !");
                    } else {
						alert("Un probleme est survenu. Veuillez reessayer!");
                    }
                });
    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                    <input type="text" name="usernameOrEmail" id="usernameOrEmail" placeholder="Nom dutilisateur ou email" />
                    <input name="password" id="password" type="password" placeholder="Mot de passe" />
                    <button type="submit" class="btn-cont">Connexion</button>
					<br />
					<a href="/inscription" id="inscription-link">Inscription</a>
            </form>
        );
    }
}

export default withRouter(LoginComponent);