import React from 'react'
import './BoutonNavbarQE.css'

/**
 * Constante  qui retourne un tableau
 * @type {string[]} un tableau de String qui contient les classes correspondant à un style pour le css
 */
const STYLE = [
    'btn--primary',
    'btn--outline'
]
/**
 * Constante  qui retourne un tableau
 * @type {string[]} un tableau de String qui contient les classes correspondant à une taille d'un bouton pour le css
 */
const SIZE = [
    'btn--medium',
    'btn--large'
]
/**
 * Fonction qui retourne un bouton dans une Navbar
 * @param children le contenu qui correspond au nom de bouton
 * @param type le type de bouton
 * @param onClick le paramètre pour onClick
 * @param boutonStyle le style de bouton
 * @param boutonSize la taille de bouton
 * @returns {JSX.Element} un bouton
 */
const boutonNavbarQE = ({children, type, onClick, boutonStyle, boutonSize}) => {
    const checkBoutonStyle = STYLE.includes(boutonStyle) ? boutonStyle : STYLE[0]
    const checkBoutonSize = STYLE.includes(boutonSize) ? boutonSize : SIZE[0]
    return (
        <button className={`btn ${checkBoutonStyle} ${checkBoutonSize}`} onClick={onClick} type={type}>{children}</button>
    )
}
export default boutonNavbarQE