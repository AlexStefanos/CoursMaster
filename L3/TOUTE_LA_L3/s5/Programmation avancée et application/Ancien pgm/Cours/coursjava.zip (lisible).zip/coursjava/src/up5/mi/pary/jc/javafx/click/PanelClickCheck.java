package up5.mi.pary.jc.javafx.click;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import up5.mi.pary.jc.util.Compteur;

public class PanelClickCheck extends BorderPane{

	private Compteur compteur;
	private Label label;
	private CheckBox checkBox;

	public PanelClickCheck(Compteur compteur){
		this.compteur=compteur;
		
		BorderPane pane = new BorderPane();
		Pane pNorth = new FlowPane( );
		Label labN1 = new Label("label 1 ");
		Label labN2 = new Label("label 2 ");
		Label labN3 = new Label("label 3 ");
		pNorth.getChildren().add(labN1);
		pNorth.getChildren().add(labN2);
		pNorth.getChildren().add(labN3);
		pane.setTop(pNorth);

		GridPane pEast = new GridPane();
		Label labE4 = new Label("label 4 ");
		Label labE5 = new Label("label 5 ");
		pEast.add(labE4,1,1);pEast.add(labE5,1,2);
		pane.setRight(pEast);
		
		GridPane pWest = new GridPane();
		Label labW6 = new Label("label 6 ");
		Label labW7 = new Label("label 7 ");
		pWest.add(labW6,1,1);pWest.add(labW7,2,1);
		pane.setLeft(pWest); 

		Button bOK = new Button("OK");
		pane.setBottom(bOK);
		

		this.setCenter(pane);

		
		/*for (int col=1;col<=4;col++)
			for (int lig=1;lig<=3;lig++)
				this.add(new Label("("+col+","+lig+")"), col, lig);*/
		/*Button button = new Button("OK");

		this.label =new Label("Compteur : 0");
		
		this.checkBox=new CheckBox("dix par dix");
		
		this.add(button, 1, 1);
		this.add(label, 1,1);
		this.add(checkBox, 1,1);*/
		/*this.setBottom(button);
		this.setCenter(label);
		this.setRight(this.checkBox);*/
		/*this.getChildren().add(button);
		this.getChildren().add(label);
		this.getChildren().add(checkBox);*/
		
		//button.setOnAction(new EcouteurClickI());
		

	}

	class EcouteurClickI implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			PanelClickCheck.this.compteur.incrementer(checkBox.isSelected()?10:1);
			PanelClickCheck.this.label.setText("--> "+PanelClickCheck.this.compteur.getValue());
		}
	}
}
