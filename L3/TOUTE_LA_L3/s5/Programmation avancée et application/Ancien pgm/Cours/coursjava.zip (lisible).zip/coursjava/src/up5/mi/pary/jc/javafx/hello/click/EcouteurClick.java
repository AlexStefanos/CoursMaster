package up5.mi.pary.jc.javafx.hello.click;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import up5.mi.pary.jc.util.Compteur;

public class EcouteurClick implements EventHandler<ActionEvent> {
	private Label label;
	private Compteur compteur;

	public EcouteurClick(Label label,Compteur compteur){
		this.label=label;
		this.compteur=compteur;
	}
	@Override
	public void handle(ActionEvent event) {
		compteur.incrementer(1);
		label.setText("--> "+compteur.getValue());
	}
};

