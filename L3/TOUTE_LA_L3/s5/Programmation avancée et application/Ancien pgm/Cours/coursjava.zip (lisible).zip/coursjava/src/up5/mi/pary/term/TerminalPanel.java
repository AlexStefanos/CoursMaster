package up5.mi.pary.term;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;

import up5.mi.pary.term.convertor.BooleanConvertor;
import up5.mi.pary.term.convertor.ByteConvertor;
import up5.mi.pary.term.convertor.CharConvertor;
import up5.mi.pary.term.convertor.ConvertException;
import up5.mi.pary.term.convertor.Convertor;
import up5.mi.pary.term.convertor.DoubleConvertor;
import up5.mi.pary.term.convertor.FloatConvertor;
import up5.mi.pary.term.convertor.IntConvertor;
import up5.mi.pary.term.convertor.LongConvertor;
import up5.mi.pary.term.convertor.ShortConvertor;
import up5.mi.pary.term.convertor.StringConvertor;

@SuppressWarnings("serial")
public class TerminalPanel extends JPanel{
/**
 * la couleur par défaut des terminaux
 */
	private static Color defaultTextAreaColor=Color.GREEN;
/**
 * la sortie (println) du terminal
 */
	private JTextArea console=new JTextArea();
	private JTextField messagefield = new JTextField();
	private JTextField textfield = new JTextField();
	private JTextField errorfield = new JTextField();

	private JButton buttonValid=new JButton("OK");
	private JButton buttonEnd=new JButton("End");
/**
 * le panel contenant les boutons de validations et de sortie du terminal
 */
	private JPanel panelButtons=new JPanel	(new CardLayout());
	
	/**
	 * la validateur des données saisies
	 */
	private Convertor validator;

	public TerminalPanel(){
		super(new BorderLayout(20,20));
		JScrollPane jsp = new JScrollPane(console);
		jsp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		jsp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		setTextAreaColor(Color.GREEN);
		this.add(jsp,BorderLayout.CENTER);
		JPanel panelSouth = new JPanel(new GridLayout(0,1,5,5));

		this.add(panelSouth,BorderLayout.SOUTH);
		panelSouth.add(messagefield);
		
		JPanel panelResponse=new JPanel(new BorderLayout());
		panelResponse.add(textfield,BorderLayout.CENTER);
		this.textfield.setEnabled(false);
		this.buttonValid.setEnabled(false);
		
		
		this.panelButtons.add(buttonValid,"Valid");
		this.panelButtons.add(buttonEnd,"End");
		
		panelResponse.add(panelButtons,BorderLayout.EAST);
		
		panelSouth.add(panelResponse);

		panelSouth.add(errorfield);
		
		messagefield.setEditable(false);
		errorfield.setEditable(false);
		console.setEditable(false);
		console.setBackground(defaultTextAreaColor);
		
		ActionListener listenerRun=new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				errorfield.setText("");
				try {
					Object result = validator.convert(textfield.getText());
					lectureTerminee(result);
				}
				catch (ConvertException exp) {errorfield.setText(exp.getMessage());}
			}
		};
		this.buttonValid.addActionListener(listenerRun);
		this.textfield.addActionListener(listenerRun);
		
		ActionListener listenerEnd=new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				fireTerminalClosing();
			}
		};
		this.buttonEnd.addActionListener(listenerEnd);

	}
	
	
/**
 * méthode appelée après validation d'une donnée saisie
 * @param result le résultat correspondant à la donnée saisie
 */
	private void lectureTerminee(Object result){
		textfield.setText("");
		messagefield.setText("");
		this.textfield.setEnabled(false);
		this.buttonValid.setEnabled(false);

		print(result+"\n");
		
		synchronized(TerminalPanel.this){
			TerminalPanel.this.notify();
		}
	}


	private synchronized void read(final String message,Convertor validator){
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				messagefield.setText(message);
				print(message+' ');	
				textfield.setEnabled(true);
				buttonValid.setEnabled(true);
				textfield.requestFocusInWindow();
			}
		});
		this.validator=validator;
		try {
			this.wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw new RuntimeException("Error :",e);
		}
		
	}

	public void end() {
		textfield.setEditable(false);
		textfield.setEnabled(false);
		((CardLayout)panelButtons.getLayout()).show(panelButtons,"End");

	}






	public byte readByte(String message){
		read(message,new ByteConvertor());
		return ((Byte)validator.getResult()).byteValue();
	}
	public short readShort(String message){
		read(message,new ShortConvertor());
		return ((Short)validator.getResult()).shortValue();
	}
	public int readInt(String message){
		read(message,new IntConvertor());
		return ((Integer)validator.getResult()).intValue();
	}
	public long readLong(String message){
		read(message,new LongConvertor());
		return ((Long)validator.getResult()).longValue();
	}
	public float readFloat(String message){
		read(message,new FloatConvertor());
		return ((Float)validator.getResult()).floatValue();
	}
	public double readDouble(String message){
		read(message,new DoubleConvertor());
		return ((Double)validator.getResult()).doubleValue();
	}
	public char readChar(String message){
		read(message,new CharConvertor());
		return ((Character)validator.getResult()).charValue();
	}
	public boolean readBoolean(String message){
		read(message,new BooleanConvertor());
		return ((Boolean)validator.getResult()).booleanValue();
	}
	public String readString(String message){
		read(message,new StringConvertor());
		return ((String)validator.getResult());
	}

	public void print(String string) {
		console.append(string);
		console.setCaretPosition(console.getDocument().getLength());
	}

	public void println(String string) {
		print(string+'\n');
	}
	public void println(Object object) {
		println(object.toString());
	}
	public void print(Object object) {
		print(object.toString());
	}
	public void print(int i) {
		print(i+"");
	}
	public void println(int i) {
		println(i+"");
	}
	public void print(long i) {
		print(i+"");
	}
	public void println(long l) {
		println(l+"");
	}
	public void print(float f) {
		print(f+"");
	}
	public void println(float f) {
		println(f+"");
	}
	public void print(double d) {
		print(d+"");
	}
	public void println(double d) {
		println(d+"");
	}
	public void print(char c) {
		print(c+"");
	}
	public void println(char c) {
		println(c+"");
	}
	public void print(boolean b) {
		print(b+"");
	}
	public void println(boolean b) {
		println(b+"");
	}

	
	
	public void println() {
		println("");
	}

	
	public static void setDefaultTextAreaColor(Color color){
		defaultTextAreaColor=color;
	}

	public void setTextAreaColor(Color color){
		console.setBackground(color);
	}

	public void setFontFamilyName(String fontFamilyName) {
		Font font = console.getFont();
		Font newFont=new Font(fontFamilyName,font.getStyle(),font.getSize());
		console.setFont(newFont);
	}

	private void fireTerminalClosing(){
		for (TerminalListener listener:listeners)
			listener.terminalClosing();
	}
	private List<TerminalListener> listeners= new ArrayList<TerminalListener>();
	public void addTerminalListener(TerminalListener listener){
		listeners.add(listener);
	}

	public void clear() {
		console.setText("");		
	}


	public void setButtonTextColor(Color color) {
		this.buttonValid.setForeground(color);
		
	}


	public void setButtonLabel(String label) {
		this.buttonValid.setText(label);
		
	}


	public void setTextAreaFontSize(int size) {
		this.console.setFont(this.console.getFont().deriveFont((float)size));		
	}
}


