import {useForm} from "react-hook-form";
import {useHistory} from "react-router-dom";

import img from "../../Images/contract.png"
import {Fragment, useState} from "react";
import plusLogo from "../../Images/plus.png"
import minusLogo from "../../Images/minus.png"
import Associate from "./Associate";
import {InputRef} from "../utils/UtilsComponent";

/**
 * Fonction pour afficher la liste des types d'une facture.
 *
 * @param register  référence : pour récupérer le type choisi par l’utilisateur.
 * @return jsx : afficher la liste des types d'un facture.
 */
const FactureType = ({register}) => {
    return (
        <Fragment>
            <label className="utils-label">Type de facturation</label>
            <select name="typeFacturation" className="utils-input" ref={register}>
                <option/>
                <option value="facture d’acompte">facture d’acompte</option>
                <option value="facture d’avoir">facture d’avoir</option>
                <option value="facture de doit">facture de doit</option>
                <option value="facturation intermédiaire">facturation intermédiaire</option>
                <option value="facture de régularisation">facture de régularisation</option>
                <option value="facture de clôture">facture de clôture</option>
                <option value="facture proforma">facture proforma</option>
                <option value="facture véritable">facture véritable</option>
            </select>
        </Fragment>
    )
}

/**
 * Fonction pour créer un nouveau contrat.
 * Pour cela on utilise hooks-form pour récupérer la saisie de l’utilisateur.
 * @return afficher popup pour ajouter un client.
 */
export default function AddContratComponent({addContrat}) {

    let {register, handleSubmit, errors} = useForm()
    const history = useHistory()
    let [visible, setVisible] = useState(false);
    let [client, setClient] = useState(null)

    function showAddClient() {
        if (client != null)
            setClient(null)
        setVisible(!visible)
    }

    function addClientToContrat(data) {
        setVisible(!visible)
        setClient(data)
    }

    /**
     * Récupérer les informations du contrat saisi et
     * l’ajouter à la liste des contrats.
     *
     * @param data data saisi par user
     */
    function onSubmit(data) {
        let id = (client == null) ? -1 : client.id
        console.log(data)
        addContrat(data, id);
    }

    return (
        <div className="popup-add">

            <form onSubmit={handleSubmit(onSubmit)} className="form-edit-contrat">
                <div className="contrat-logo">
                    <img src={img} alt="contrat logo"/>
                    <h1>Nouveau contrat</h1>
                </div>

                <InputRef labelValue="Nom" name="nom" type="text" register={register} err={errors}
                          messageErr="Nom invalide"/>

                <InputRef labelValue="Traif" name="tarif" type="text" register={register} err={errors}
                          messageErr="Tarif Invalide"/>

                <FactureType register={register({required: true})}/>

                <div className="date-container">
                    <div>
                        <InputRef labelValue="Date de debut" err={errors} register={register} type="date"
                                  name="dateDebut" messageErr="date invalide"/>
                    </div>
                    <div>
                        <InputRef type="text" name="duree" register={register} err={errors} labelValue="Durée"
                                  messageErr="durée invalide"/>
                    </div>
                </div>

                <div onClick={showAddClient} style={{cursor: "pointer"}}>
                    <img className="plus-logo" src={(visible) ? minusLogo : plusLogo} alt="ajouter"/>
                    {(client == null) ? "Ajouter un Client" : "Supprimer le Client (" + client.clientActuel.nom + ")"}
                </div>
                {(visible) && <Associate addClient={addClientToContrat} type="client"/>}

                <div className="popup-btn-container">
                    <button className="btn-cancel" type="button" onClick={() => history.push("/mes-contrats")}>annuler
                    </button>
                    <button className="btn-add" type="submit">Ajouter</button>
                </div>

            </form>
        </div>
    )
}