package up5.mi.pary.jt.hello;

public class TestCarreDeLaSomme {

	public static void main(String [] args) {

		int a; // déclaration de la variable entière a
		a = 5 ; // initialisation de la variable a
		int b = 7 ; // déclaration et initialisation de b
		System.out.print("Le carr\u00E9 de la somme de " + a + " et de " + b);
		System.out.println( "est \u00E9gal \u00E0� " + (a+b) * (a+b) );
	}
}