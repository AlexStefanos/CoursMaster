import './utilsStyle.css'
import {useState} from "react";


/**
 * Function qui afficher une err en rouge si un champ n'est pas valide.
 *
 * @param message  message d'erreurs
 * @param onChangeStyle fonction pour changer le style
 * @return {JSX.Element} message.
 */
export const Wall = ({message, onChangeStyle}) => {
    return <div className="wall">
        {message}
    </div>
}

/**
 * Input Controller, composant utilisé  dans les formulaires.
 *
 * @param labelValue label
 * @param register ref
 * @param name name
 * @param err errors
 * @param type type
 * @param messageErr message
 * @return {JSX.Element} input
 */
export const InputRef = ({labelValue, register, name, err, type, messageErr}) => {

    let [className, setClassName] = useState("utils-input");

    const showErrors = () => {
        setClassName(className + "-wall")
    }
    return (
        <div className="input-ref-container">
            <label className="utils-label">{labelValue}</label>
            <input name={name} type={type} className={className}
                   ref={register({
                       required: true
                   })}
            />
            {err[name] && <Wall message={messageErr} onChangeStyle={showErrors}/>}
        </div>
    )
}