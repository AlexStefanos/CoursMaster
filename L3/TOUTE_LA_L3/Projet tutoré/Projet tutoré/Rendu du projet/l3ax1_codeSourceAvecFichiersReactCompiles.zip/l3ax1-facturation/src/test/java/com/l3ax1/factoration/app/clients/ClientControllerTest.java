package com.l3ax1.factoration.app.clients;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.l3ax1.factoration.app.Models.clients.ClientArchive;
import com.l3ax1.factoration.app.Models.clients.Morale;
import com.l3ax1.factoration.app.Models.clients.Physique;
import com.l3ax1.factoration.app.repository.clients.ClientRepository;
import com.l3ax1.factoration.app.services.clients.ClientService;
import com.l3ax1.factoration.app.repository.clients.PhysiqueRepository;
import org.junit.jupiter.api.Test;

import static org.hamcrest.CoreMatchers.is;

import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import com.l3ax1.factoration.app.controllers.clients.ClientController;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import java.time.LocalDate;
import java.util.Date;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;


/**
 * <h1>ClientControllerTest: class Test API </h1>
 * <hr/>
 * Objectif de cette class est de tester {@link ClientController}; or, ce derniers serai appelé à
 * travers des URL par les programmes qui communiqueront avec (API).
 * <br/><br/>
 * {@link SpringBootTest} @SpringBootTest est une annotation fournie par Spring Boot. Elle permet
 * lors de l’exécution des tests d’initialiser le contexte Spring. Les beans de notre application
 * peuvent alors être utilisés.
 * <br/>
 * {@link AutoConfigureMockMvc } Annotation qui peut être appliquée  à  une  classe  de test pour
 * activer et configurer la configuration automatique de MockMvc.
 * <p>
 * <hr/>
 *
 * @author lounis BOULDJA
 * @version 1.0
 * @see ClientController
 * @see Test
 */
@SpringBootTest
@AutoConfigureMockMvc
public class ClientControllerTest {

    static final GsonBuilder builder = new GsonBuilder();
    static final Gson gson = builder.create();

    /**
     * {@link MockMvc} est un élément important. Il permet d’appeler la méthode perform
     * qui déclenche la requête.
     */
    @Autowired
    private MockMvc mockMvc;

    /* controller pour faire des test avec*/
    @Autowired
    ClientController clientController;

    /**
     * <h2>Tester si le controler n'est pas null</h2>
     */
    @Test
    public void contextLoads() {
        assertThat(clientController).isNotNull();
    }

    /**
     * <h2>  getClients : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients). On exécute donc
     * une requête GET sur l’URL /clients. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitGetClients() throws Exception {
        mockMvc.perform(get("/clients"))
                .andExpect(status().isOk());
    }

    /**
     * <h2>Tester la methode getClients : Test D'integration</h2>
     * <p>
     * vérifier si le statut vaut 200 (Le code de statut de réponse HTTP 200 OK indique
     * la réussite d'une requête.) <br/>
     * <p>
     * vérifie le contenu retourné grâce à jsonPath("$[indice].attribut", is("value")).
     * <ul>
     *     <li>$ pointe : sur la racine de la structure JSON.</li>
     *     <li>[indice] : indique qu’on veut vérifier le premier élément de la liste.</li>
     *     <li>attribut : désigne l’attribut qu’on veut consulter.</li>
     * </ul>
     *
     * @throws Exception preform exception
     * @see ClientController
     */
    @Test
    public void testGetClients() throws Exception {
        mockMvc.perform(get("/clients"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].clientActuel.nom", is("TEST")))
                .andExpect(jsonPath("$[0].adresse", is("TEST, TEST, TEST, TEST")));
    }


    /**
     * <h2>Tester la methode getClientById : Test D'integration</h2>
     * <p>
     * vérifier si le statut vaut 200 (Le code de statut de réponse HTTP 200 OK indique
     * la réussite d'une requête.) <br/>
     * <p>
     * vérifie le contenu retourné grâce à jsonPath("$[indice].attribut", is("value")).
     * <ul>
     *     <li>$ pointe : sur la racine de la structure JSON.</li>
     *     <li>[indice] : indique qu’on veut vérifier le premier élément de la liste.</li>
     *     <li>attribut : désigne l’attribut qu’on veut consulter.</li>
     * </ul>
     *
     * @throws Exception preform exception
     * @see ClientController
     */
    @Test
    public void testGetClientById() throws Exception {
        mockMvc.perform(get("/clients/120"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clientActuel.nom", is("Levi ACKERMAN")))
                .andExpect(jsonPath("$.adresse", is("France, Paris, 7500, Paris")));
    }

    /**
     * <h2>  getClientById : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients/id). On exécute donc
     * une requête GET sur l’URL /clients/id. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitGetClientById() throws Exception {
        mockMvc.perform(get("/clients/120"))
                .andExpect(status().isOk());
    }

    /**
     * <h2>  getClientContratsById : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients/contrats/id). On exécute donc
     * une requête GET sur l’URL /clients/contrats/id. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitGetContratById() throws Exception {
        mockMvc.perform(get("/clients/contrats/120"))
                .andExpect(status().isOk());
    }

    /**
     * <h2>  Create client : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients/contrats/id). On exécute donc
     * une requête GET sur l’URL /clients/contrats/id. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitCreateClient() throws Exception {
        Morale morale = new Morale();
        mockMvc.perform(post("/clients/ajouter_morale")
                .contentType(MediaType.APPLICATION_JSON)
                .content(" {\n" +
                        "        \"clientActuel\": {\n" +
                        "            \"nom\": \"TEST Test\"\n" +
                        "        },\n" +
                        "        \"factures\": [\n" +
                        "            {\n" +
                        "                \"id\": 1,\n" +
                        "                \"numeroFacture\": \"123456789\",\n" +
                        "                \"dateEmission\": \"2021-04-13\",\n" +
                        "                \"dateRegelement\": \"2021-04-29\",\n" +
                        "                \"totalHT\": 200.0,\n" +
                        "                \"totalTTC\": 1000.0,\n" +
                        "                \"facturePayee\": true,\n" +
                        "                \"factureBrouillon\": false,\n" +
                        "                \"factureEtat\": \"PAYEE\",\n" +
                        "                \"avoir\": 0.0,\n" +
                        "                \"tva\": 20.0\n" +
                        "            }\n" +
                        "        ],\n" +
                        "        \"adresse\": \"France, Paris, 7500, Paris\",\n" +
                        "        \"adresseFacturation\": null,\n" +
                        "        \"premierAchat\": \"2021-04-12T12:11:00.261+00:00\",\n" +
                        "        \"numeroTva\": \"10\",\n" +
                        "        \"tvaIntracom\": null,\n" +
                        "        \"solde\": 0.0,\n" +
                        "        \"total\": 0.0,\n" +
                        "        \"email\": \"levi.ackerman@gmail.com\",\n" +
                        "        \"description\": \"client important\"\n" +
                        "    }"))
                .andExpect(status().isOk());
    }


    /**
     * <h2>  Update : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients/contrats/id). On exécute donc
     * une requête GET sur l’URL /clients/contrats/id. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitUpdateClient() throws Exception {

        mockMvc.perform(put("/clients/update_physique/120")
                .contentType(MediaType.APPLICATION_JSON)
                .content(" {\n" +
                        "        \"clientActuel\": {\n" +
                        "            \"nom\": \"LEVI Akerman\"\n" +
                        "        },\n" +
                        "        \"factures\": [\n" +
                        "            {\n" +
                        "                \"id\": 1,\n" +
                        "                \"numeroFacture\": \"123456789\",\n" +
                        "                \"dateEmission\": \"2021-04-13\",\n" +
                        "                \"dateRegelement\": \"2021-04-29\",\n" +
                        "                \"totalHT\": 200.0,\n" +
                        "                \"totalTTC\": 1000.0,\n" +
                        "                \"facturePayee\": true,\n" +
                        "                \"factureBrouillon\": false,\n" +
                        "                \"factureEtat\": \"PAYEE\",\n" +
                        "                \"avoir\": 0.0,\n" +
                        "                \"tva\": 20.0\n" +
                        "            }\n" +
                        "        ],\n" +
                        "        \"adresse\": \"France, Paris, 7500, Paris\",\n" +
                        "        \"adresseFacturation\": null,\n" +
                        "        \"premierAchat\": \"2021-04-12T12:11:00.261+00:00\",\n" +
                        "        \"numeroTva\": \"10\",\n" +
                        "        \"tvaIntracom\": null,\n" +
                        "        \"solde\": 0.0,\n" +
                        "        \"total\": 0.0,\n" +
                        "        \"email\": \"levi.ackerman@gmail.com\",\n" +
                        "        \"description\": \"client important\"\n" +
                        "    }"))
                .andExpect(status().isOk());
    }
}