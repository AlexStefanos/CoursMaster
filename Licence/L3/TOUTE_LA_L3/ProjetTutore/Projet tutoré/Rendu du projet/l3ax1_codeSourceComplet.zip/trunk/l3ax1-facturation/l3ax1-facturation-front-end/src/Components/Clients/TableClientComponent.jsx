import React from "react";
import {useHistory} from "react-router-dom";


/**
 * Creer une composante table
 * @param data   map : pour remplir la table
 * @param statut
 * @return {JSX.Element} table remplit par data
 */
export function TableClientComponent({data, statut, filter}) {
    let history = useHistory();
    return (
        <table id="table_clients">
            <thead>
            <tr>
                <th>{(statut) ? "NOM" : "RAISON SOCIAL"}</th>
                <th>{(statut) ? "EMAIL" : "SIRET"}</th>
                <th>{(statut) ? "DESCRIPTION" : "FORM JURIDIQUE"}</th>
                <th>ADRESSE</th>
            </tr>
            </thead>
            <tbody>
            {/*Remplir la table en utilsant map*/
                data.map(
                    (client) => {
                        if ((statut && client.email == null) || (!statut && client.formeJuridique == null))
                            return null;
                        if (("" + client.clientActuel.nom.toUpperCase()).indexOf(filter.toUpperCase()) === -1)
                            return null
                        return (
                            /* clé unique => email ou id-client */
                            /* afficher les details des client */
                            <tr key={client.id} onClick={() => {
                                history.push("/DetailsClient/" + client.id)
                            }}>
                                <td data-label={(statut) ? "NOM" : "RAISON SOCIAL"}>{client.clientActuel.nom}</td>
                                <td data-label={(statut) ? "E-mail" : "SIRET"}>{(statut) ? client.email : client.siret}</td>
                                <td data-label={(statut) ? "DESCRIPTION" : "FORME JURIDQUE"}>{(statut) ? client.description : client.formeJuridique}</td>
                                <td data-label={"ADRESSE"}>{client.adresse}</td>
                            </tr>
                        )
                    }
                )
            }
            </tbody>
        </table>
    )
}