package up5.mi.pary.jc.javafx.click;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import up5.mi.pary.jc.util.Compteur;

public class AppliClickAvecCaseFermeture extends Application {

	@Override
	public void start(Stage stage) {

		stage.setTitle("Cliquer !");
		//stage.initStyle(StageStyle.UTILITY);
		Compteur compteur = new Compteur();

		Scene scene = new Scene(new PanelClickCB(compteur), 200, 50);
		//scene.getStylesheets().add("file:mll5u2o.css");
		//scene.getStylesheets().add("file:light.css");
		stage.setScene(scene);
		
		stage.setOnCloseRequest((e)->{
			ConfirmStage confirm = new ConfirmStage(stage,"Confirmation","Voulez-vous quitter ?");
			if (!confirm.isReponsePositive())
				e.consume();
			});
		stage.show();
		System.out.println(scene.getStylesheets());


	}
	public static void main(String[] args) {
		launch(args);
	}
}