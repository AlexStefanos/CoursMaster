# Projet Maven pour les TD de Traitement d'Images Numériques

Ce projet contient tous les codes utilisés pendant les TDs de la matière et chaque sous-projet contient un fichier _README.MD_ qui décrit le contenu et la façon d'utiliser les plugins disponibles dans chaque projet.