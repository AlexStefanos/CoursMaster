/*
 * ApiResponse.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
package com.l3ax1.factoration.app.payload;

/**
 * ApiResponse : Répondre à une demande (demande d'ajout d'un nouvel utilisateur par exemple)
 * (Nous devons définir la demande et la réponse que les API utiliseront).
 * 
 * Exemple de réponse:
 *	{
 *   	"success": true,
 *   	"message": "User registered successfully"
 *	}
 * 
 * @author Leonard NAMOLARU
 */
public class ApiResponse {
	/**
	 * Indique si la demande a été reçue et exécutée avec succès
	 */
    private Boolean success;
    
    /**
     * Contenu du message envoyé en réponse
     */
    private String message;
    
    /**
     * Constructeur - Créer une nouvelle instance de l'objet ApiResponse.
     * @param success Indique si la demande a été reçue et exécutée avec succès.
     * @param message Contenu du message envoyé en réponse.
     */
    public ApiResponse(Boolean success, String message) {
        this.success = success;
        this.message = message;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du champ success.
     * @return la valeur actuelle du champ success.
     */
    public Boolean getSuccess() {
        return success;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur du champ success.
     * @param success Indique si la demande a été reçue et exécutée avec succès.
     */
    public void setSuccess(Boolean success) {
        this.success = success;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du champ message.
     * @return La valeur actuelle du champ message.
     */
    public String getMessage() {
        return message;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur du champ message.
     * @param message Contenu du message envoyé en réponse.
     */
    public void setMessage(String message) {
        this.message = message;
    }
}