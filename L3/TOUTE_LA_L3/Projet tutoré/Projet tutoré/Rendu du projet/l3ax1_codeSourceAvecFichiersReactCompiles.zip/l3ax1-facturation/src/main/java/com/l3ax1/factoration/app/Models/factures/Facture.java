package com.l3ax1.factoration.app.Models.factures;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.l3ax1.factoration.app.Models.clients.Client;
import com.l3ax1.factoration.app.Models.produits.Produit;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * <h1>Facture : class</h1>
 *
 * <hr/>
 * Entity (JPA) qui représente les factures dans la base de données.
 * <br/><br/>
 * see : {@link Client} Pour la documentation des autres annotations (@Entity, @Data, @Table)
 * <hr/>
 *
 * @see  Client
 *
 * @version 1.0
 * @author Salah Eddine Atia
 *
 */

@Data
@Entity
@Table(name = "factures")
public class Facture {

    /**
     * L’attribut id correspond à la clé primaire de la table, et est donc annoté @Id.
     * D’autre part, comme l’id est auto-incrémenté, j’ai ajouté l’annotation
     * <strong>@GeneratedValue(strategy = GenerationType.IDENTITY).<strong/> pour qui soit incrémenté directement de la base de donneés
     * @see Id
     * @see GeneratedValue
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    /**
     * Clé étrangère - client
     *
     * @see Client
     */
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "facture_client")

    private Client client;

    @Column(name = "facture_numero")
    private String numeroFacture;

    @Column(name = "facture_date_emission")
    private Date dateEmission = new Date();

    @Column(name = "facture_date_reglement")
    private Date dateRegelement = new Date();

    @Column(name = "facture_totalTTC")
    private double totalTTC;

    @Column(name = "facture_payee")
    private boolean facturePayee;

    @Column(name = "facture_avoir")
    private float avoir;

    @Column(name = "facture_info")
    private String informations;


}