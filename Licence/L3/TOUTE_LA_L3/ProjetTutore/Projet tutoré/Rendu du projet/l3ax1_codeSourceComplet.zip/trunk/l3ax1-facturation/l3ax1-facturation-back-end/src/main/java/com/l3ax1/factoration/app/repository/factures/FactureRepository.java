package com.l3ax1.factoration.app.repository.factures;

import com.l3ax1.factoration.app.Models.factures.Facture;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * <h1>FactureRepository: interface</h1>
 * <hr/>
 * <p>
 * L’interface {@link FactureRepository} permet d’implémenter le code qui
 * déclenche les actions pour communiquer avec  la base de données. Bien évidemment,
 * ce code se servira de notre classe {@link Facture}.
 * Et faire des  requêtes à la base de données, et le résultat nous est retourné
 * sous forme d’instances de l’objet facture.
 * <br/>
 * Spring Data JPA ! Il nous permet d’exécuter des requêtes SQL.
 * <br/><br/>
 *
 * {@link CrudRepository} est une interface fournie par Spring. Elle fournit des
 * méthodes pour manipuler votre entité. Elle utilise la généricité pour que son
 * code soit applicable à n’importe quelle entité.
 * <br/><br/>
 *
 * {@link Repository} est une annotation Spring pour indiquer que la  classe est
 * un bean, et que son rôle est de communiquer avec une source de données
 * (en l'occurrence la base de données).
 * </p>
 * <hr/>
 *
 * @see Facture
 * @see CrudRepository
 * @see Repository
 *
 * @author Salah Eddine Atia
 * @version 1.0
 */
@Repository
public interface FactureRepository extends CrudRepository<Facture, Long> {
}
