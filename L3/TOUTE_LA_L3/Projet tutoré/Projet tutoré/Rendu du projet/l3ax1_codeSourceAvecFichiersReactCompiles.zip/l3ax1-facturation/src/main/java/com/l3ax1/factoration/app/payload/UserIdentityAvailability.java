/*
 * UserIdentityAvailability.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
package com.l3ax1.factoration.app.payload;

/**
 * Un objet dont chaque instance représente une réponse à une question
 * si un nom d'utilisateur est disponible pour l'enregistrement 
 * ou si un e-mail est disponible pour l'enregistrement.
 * 
 * (Cette classe est utilisée dans la classe UserController).
 * 
 * @author Leonard NAMOLARU
 */
public class UserIdentityAvailability {
	/**
	 * Variable booléenne. vrai ou faux.
	 */
    private Boolean available;
    
    /**
     * Constructeur - Créer une nouvelle instance de l'objet UserIdentityAvailability
     * @param available Paramètre booléen. vrai ou faux.
     */
    public UserIdentityAvailability(Boolean available) {
        this.available = available;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du champ available.
     * @return La valeur actuelle du champ available
     */
    public Boolean getAvailable() {
        return available;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du champ available.
     * @param available Paramètre booléen. vrai ou faux.
     */
    public void setAvailable(Boolean available) {
        this.available = available;
    }
}