import {Component} from "react";
import ClientService from "../../Services/ClientService";
import ContratService from "../../Services/ContratService";
import ProduitService from "../../Services/ProduitService";

function ClientList({key, client, addClient}) {

    /**
     * Ajouter un client a la liste.
     */
    function getClientHandler() {
        addClient(client)
    }
    return <li key={key} onClick={getClientHandler}>{client.clientActuel.nom}</li>
}

function ContratList({key, contrat, addContrat}) {
    function getContratHandler() {
        addContrat(contrat)
    }
    return (contrat.client == null) && <li key={key} onClick={getContratHandler}>{contrat.nom}</li>
}
function ProduitListFacture({key, produit, addProduit}) {
    function getProduitHandler() {
        addProduit(produit)
    }
    return  <li key={key} onClick={getProduitHandler}>{produit.nom}</li>
}
/**
 *
 */
class Associate extends Component {

    constructor(props) {
        super(props);
        this.state = {
            type: this.props.type,
            data: [],
            filter: '',
            resultat: null
        }
        this.chageFilter = this.chageFilter.bind(this)
    }

    componentDidMount() {
        if (this.state.type === "client") {
            ClientService.getCleints().then((res) => {
                this.setState({
                    data: res.data,
                })
            })
        } else if(this.state.type === "contrat"){
            ContratService.getContrat().then((res) => {
                this.setState({
                    data: res.data
                })
            })
        } else {
            ProduitService.getProduit().then((res) => {
                this.setState({
                    data: res.data,
                })
            })
        }

    }

    chageFilter(e) {
        this.setState({
            filter: e.target.value
        })
    }

    render() {

        return (
            <div className="rechercher associate-container">
                <input placeholder="Rechrcher ..." value={this.state.filter} onChange={this.chageFilter}/>
                <ul className="list-item">
                    {
                        this.state.data.map(
                            (d) => {
                                return (this.state.type === "client")
                                    ? (d.clientActuel.nom.indexOf(this.state.filter) !== -1)
                                    && <ClientList key={d.id} client={d} addClient={this.props.addClient}/>
                                    : (this.state.type === "contrat")
                                        ? (d.nom.toUpperCase().indexOf(this.state.filter.toUpperCase()) !== -1)
                                        && <ContratList key={d.id} contrat={d} addContrat={this.props.addContrat}/>
                                        : (d.nom.toUpperCase().indexOf(this.state.filter.toUpperCase()) !== -1)
                                        && <ProduitListFacture key={d.id} produit={d} addProduit={this.props.addProduit}/>
                            }
                        )
                    }
                </ul>
            </div>
        )

    }

}

export default Associate;