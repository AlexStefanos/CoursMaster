/*
 * LoginRequest.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1 et 2.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 */
package com.l3ax1.factoration.app.payload;

import javax.validation.constraints.NotBlank;  // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.

/**
 * LoginRequest : Demande de connexion.
 * (Nous devons définir la demande et la réponse que les API utiliseront).
 * 
 * Exemple d'une demande de connexion :
 * 
 * {
 *   "usernameOrEmail": "Leonard",
 *   "password": "Secret"
 * }
 * 
 * @author Leonard NAMOLARU
 */
public class LoginRequest {
    @NotBlank  // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    private String usernameOrEmail;

    @NotBlank  // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    private String password;
    
    /**
     * La fonction renvoie la valeur actuelle du champ usernameOrEmail.
     * @return la valeur actuelle du champ usernameOrEmail
     */
    public String getUsernameOrEmail() {
        return usernameOrEmail;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur du champ usernameOrEmail.
     * @param usernameOrEmail Une chaîne de caractères qui représente un nom d'utilisateur ou une adresse e-mail.
     */
    public void setUsernameOrEmail(String usernameOrEmail) {
        this.usernameOrEmail = usernameOrEmail;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du champ password.
     * @return La valeur actuelle du champ password.
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur du champ password.
     * @param password Un mot de passe.
     */
    public void setPassword(String password) {
        this.password = password;
    }
}