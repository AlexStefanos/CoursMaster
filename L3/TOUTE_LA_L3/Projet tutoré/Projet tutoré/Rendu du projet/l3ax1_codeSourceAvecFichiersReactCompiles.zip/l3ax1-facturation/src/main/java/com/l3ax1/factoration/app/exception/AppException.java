/*
 * AppException.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1, 2 et 3.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 * Source 3 : HTTP/1.1: Semantics and Content, section 6.5.1
 */
package com.l3ax1.factoration.app.exception;

import org.springframework.http.HttpStatus; // Énumération des codes d'état HTTP.
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *  Exceptions personnalisées : Les API lèveront des exceptions si la demande n'est pas valide ou si une situation inattendue se produit.
 *  Nous voulons répondre avec différents codes d'état HTTP pour différents types d'exceptions.
 *  chaque exception est définie avec son {@link ResponseStatus} correspondant.
 *  
 *  AppException : 500 Internal Server Error (Erreur interne du serveur)
 *  Le code 500 indique que le serveur a rencontré une condition inattendue 
 *  qui l'a empêché de remplir la demande.
 *  
 * @version 1.0
 * @author Leonard NAMOLARU
 */
@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // 500 Internal Server Error.
public class AppException extends RuntimeException {
    public AppException(String message) {
        super(message);
    }

    public AppException(String message, Throwable cause) {
        super(message, cause);
    }
}