package up5.mi.pary.jc.xml.sax.val;

import java.io.File;
import java.io.OutputStreamWriter;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import up5.mi.pary.jc.xml.sax.Repertoire;
import up5.mi.pary.jc.xml.sax.basic.MainBasique;
import up5.mi.pary.jc.xml.sax.basic.RepHandler;

public class MainVAL {
	static final String JAXP_SCHEMA_LANGUAGE =
			"http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	static final String W3C_XML_SCHEMA =
			"http://www.w3.org/2001/XMLSchema";
	static final String JAXP_SCHEMA_SOURCE =
			"http://java.sun.com/xml/jaxp/properties/schemaSource";
	
	public static void main(String[] args)throws Exception {


		String xmlFile="repertoire.xml";
		String xsdFile="src/up5/mi/pary/jc/xml/sax/val/repertoire.xsd";
		System.out.println(new File(xsdFile).getAbsolutePath());

		SAXParserFactory spfactory = SAXParserFactory.newInstance();


		// le document va être validé
		spfactory.setValidating(true);


		SAXParser pf = spfactory.newSAXParser();

		RepHandler handler = new RepHandler();

		// schéma xml w3c
		pf.setProperty(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
		// indication du source
		pf.setProperty(JAXP_SCHEMA_SOURCE, xsdFile);

		pf.parse(MainBasique.class.getResourceAsStream(xmlFile),handler);

		Repertoire repertoire = handler.getRepertoire();

		repertoire.toXml(new OutputStreamWriter(System.out));
	}

}
