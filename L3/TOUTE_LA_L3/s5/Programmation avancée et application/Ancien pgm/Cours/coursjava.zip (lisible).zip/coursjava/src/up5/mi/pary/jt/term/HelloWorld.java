package up5.mi.pary.jt.term;
import up5.mi.pary.term.Terminal;

public class HelloWorld { 

	public static void main(String [] tArg) { 

		Terminal term = new Terminal("Hello",300,200); 
		term.println("Hello World !"); 
		term.end( ); 
	}
}