package up5.mi.pary.jc.jdbc.compte;

public class CompteInconnuException extends Exception {

	public CompteInconnuException(String message){
		super(message);
	}
}
