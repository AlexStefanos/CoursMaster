package up5.mi.pary.jc.swing.applet;// une classe fournie dans coursjava.jar
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class HelloApplet  extends javax.swing.JApplet {
   public void init( ){
      final JButton button = new JButton("Cliquer pour afficher l'heure");
      this.getContentPane( ).add(button);
      button.addActionListener(new ActionListener( ) {
          @Override
		   public void actionPerformed(ActionEvent e){
               button.setText(new java.util.Date( ).toString( ) );
          }
   });
  }
}
