package up5.mi.pary.jc.javafx.compte;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GestionnaireExit implements EventHandler<ActionEvent> {

	@Override
	public void handle(ActionEvent event) {
		System.exit(0);
	}

}
