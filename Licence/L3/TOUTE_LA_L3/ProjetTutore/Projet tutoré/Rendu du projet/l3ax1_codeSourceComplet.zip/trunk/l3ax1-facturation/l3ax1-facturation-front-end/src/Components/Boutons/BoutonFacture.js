import React from 'react'
import './BoutonNavbarQE.css'

/**
 * Fonction qui nous retourne un bouton correspondant à une création de facture
 * @param handleShowPopupFacture le paramètre à passer pour gèrer onClick
 * @returns {JSX.Element} bouton
 */
const boutonFacture = ({handleShowPopupFacture}) => {
    return (
            <button className='enteteBouton' onClick={handleShowPopupFacture}><i className="far fa-edit"></i> Créer la facture</button>
    )
}
export default boutonFacture