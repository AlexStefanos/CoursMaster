import './ContratStyle.css'
import TableContratComponent from "./TableContratComponent";
import React, {Component} from 'react';
import {Link, Route, Router, Switch} from "react-router-dom";
import AddContratComponent from "./AddContratComponent";
import ContratService from "../../Services/ContratService";
import DeleteContratConponent from "./DeleteContratComponent";
import BarreRecherche from "../BarreRecherche/BarreRecherche";

/**
 * Page contrat.
 *  - Afficher la liste des contrat.
 *  - Ajouter un Contrat.
 *  - supprimer un contrat.
 *
 * @version 1.0
 * @author Lounis BOULDJA
 */
class ContratComponent extends Component {


    /**
     * contrtucteur
     * @param props attributs
     */
    constructor(props) {
        super(props);
        this.state = {
            contrats: [],
            filter : ''
        }
        // bind
        this.deleteContrat = this.deleteContrat.bind(this)
        this.addContrat = this.addContrat.bind(this)
        this.changeFilter = this.changeFilter.bind(this)
    }

    /**
     * chager le text de la barre de recherche.
     *
     * @param event event
     */
    changeFilter(event) {
        this.setState({filter : event.target.value})
    }

    /**
     * charger les contrat de la base de données.
     */
    componentDidMount() {
        ContratService.getContrat().then((res) => {
            this.setState({contrats: res.data})
        })
    }

    /**
     * ajouter un contrat a la base de données.
     *
     * @param data contrat a ajouté.
     * @param id
     */
    addContrat (data, id) {
        ContratService.createContrat(data, id).then(() => {
            this.componentDidMount()
            this.props.history.push("/mes-contrats")
        })
    }

    /**
     * suprimer un contrat de la base de données.
     * @param id id de contrat.
     */
    deleteContrat (id) {
        ContratService.deleteContrat(id).then( () => {
            this.setState({contrats : this.state.contrats.filter(contrat => contrat.id !== id)})
            this.props.history.push("/mes-contrats")
            this.componentDidMount();
        })
    }

    /**
     * le rendu
     * @return {JSX.Element} page contrats.
     */
    render() {
        return (
            <div className="contrat-container">
                <BarreRecherche value={this.state.filter} onChangeValue={this.changeFilter}/>
                <h1>Contrats</h1>

                <Link to="/mes-contrats/add">
                    <button className="btn-add">Ajouter</button>
                </Link>

                <TableContratComponent data={this.state.contrats} filter={this.state.filter}/>

                <Router history={this.props.history}>
                    <Switch>
                        {/* PopUp pour ajouter un Contrat*/}
                        <Route path="/mes-contrats/add">
                            <AddContratComponent addContrat={this.addContrat}/>
                        </Route>
                        {/*Suprimer un contrat.*/}
                        <Route path="/mes-contrats/delete/:id">
                            <DeleteContratConponent deleteContrat={this.deleteContrat}/>
                        </Route>

                    </Switch>
                </Router>
            </div>
        );
    }
}

export default ContratComponent