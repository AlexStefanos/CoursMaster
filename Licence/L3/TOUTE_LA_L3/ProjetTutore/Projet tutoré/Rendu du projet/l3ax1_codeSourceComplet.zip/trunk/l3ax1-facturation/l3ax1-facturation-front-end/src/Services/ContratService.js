import axios from "axios";

const URL_API_CONTRAT="http://localhost:8080/contrats"

class ContratService {
    /**
     * Recuprer la liste des contrats de l'API.
     *
     * @return les contrats
     */
    getContrat () {
        return axios.get(URL_API_CONTRAT);
    }

    /**
     * ajouter un contrat dans la base de données.
     * @param contrat  contrat.
     * @param idClient id de client
     */
    createContrat(contrat, idClient) {
        return axios.post(URL_API_CONTRAT+"/add/"+idClient, contrat);
    }

    /**
     * supprimer un contrat.
     * @param contratID id
     * @return Promise <AxiosResponse>
     */
    deleteContrat (contratID) {
        console.log(contratID)
        return axios.delete(URL_API_CONTRAT+"/delete/" + contratID);
    }
}

export default new ContratService();