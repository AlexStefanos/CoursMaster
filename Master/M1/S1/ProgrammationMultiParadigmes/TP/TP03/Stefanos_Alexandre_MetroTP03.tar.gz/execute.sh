#!/bin/sh

java -jar MetroTP03.jar
