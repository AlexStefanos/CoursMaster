package up5.mi.pary.jc.javafx.click;

import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import up5.mi.pary.jc.util.Compteur;

public class PanelClickTF extends BorderPane{


	public PanelClickTF(Compteur compteur){
		
		Label label=new Label("--> 0");;
		TextField textField=new TextField();
		textField.setPrefColumnCount(15);
		Button button = new Button("OK");
		
		button.setOnAction(
			(event) -> {
				compteur.incrementer(Integer.parseInt(textField.getText()));
				label.setText("--> "+compteur.getValue());
			}
		);

		this.setBottom(button);
		this.setCenter(label);
		this.setRight(textField);

	}
}
