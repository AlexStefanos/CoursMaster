package up5.mi.pary.term.convertor;

public class LongConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Long.parseLong(ch);
	}

	@Override
	public String getMessage() {
		return "entier compris entre -2^63 et 2^63-1 attendu";
	}

}
