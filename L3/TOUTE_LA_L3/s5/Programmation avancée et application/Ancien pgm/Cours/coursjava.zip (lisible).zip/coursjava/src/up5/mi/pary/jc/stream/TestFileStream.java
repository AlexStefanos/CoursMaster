package up5.mi.pary.jc.stream;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestFileStream {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException{
		// création du File puis du FileOutputStream
		File file = new File("monFichier");
		{FileOutputStream fos = new FileOutputStream(file);

		// ecriture d'un byte dans le fichier
		fos.write(156); // attention : un byte doit être un entier compris en 0 et 255
		// ecriture d'un autre byte dans le fichier
		fos.write(125);

		// on crée un tableau de byte et on le rempli 
		byte [ ] tb = new byte[1000];
		for (int i=0;i<tb.length;i++) tb[i] = (byte) (i%100);

		// on écrit les 1000 bytes dans le fichier
		fos.write(tb);

		// et on ferme le flux de sortie
		fos.close( );
		}


		{
		// on lit le contenu du fichier de l'exemple précédent : il contient 1002 bytes
		// création du File puis du FileInputStream
		FileInputStream fis = new FileInputStream(file);

		// lecture du premier byte contenu dans le fichier
		//int n1 = fis.read( );
		// lecture du second byte 
		//int n2 = fis.read( );

		// on crée un tableau de 1000 bytes 
		byte [ ] tb = new byte[1000];

		// on lit les 1000 bytes suivant du fichier
		fis.read(tb);

		// et on ferme le flux
		fis.close( );
		
		//System.out.println("n1="+n1+ "  n2="+n2);
		System.out.println(" tb[0]="+tb[0]);
	
		}
	}

}
