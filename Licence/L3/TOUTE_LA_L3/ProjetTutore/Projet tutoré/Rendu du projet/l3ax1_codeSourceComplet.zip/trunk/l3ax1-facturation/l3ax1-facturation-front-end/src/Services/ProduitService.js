import axios from "axios";

const API_URL_PRODUIT = "http://localhost:8080/produits" //lien de connexion à l'API pour charger les produits

class ProduitService {


/**
	Récuperer les produits de l'API
 */
    getProduit() {
        return axios.get(API_URL_PRODUIT)
    }
    /*
    Créer Produit via API
    */
    createProduit(produit) {
        return axios.post(API_URL_PRODUIT+"/ajouter", produit)
    }
}


export default  new ProduitService()
