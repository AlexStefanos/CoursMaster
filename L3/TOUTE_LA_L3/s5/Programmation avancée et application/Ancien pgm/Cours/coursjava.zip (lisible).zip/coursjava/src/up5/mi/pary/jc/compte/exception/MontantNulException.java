package up5.mi.pary.jc.compte.exception;

public class MontantNulException extends CompteException {
	public MontantNulException(String s){super(s);}
}


