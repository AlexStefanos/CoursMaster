package up5.mi.pary.term;

public interface TerminalListener {

	public void terminalClosing();
	}


