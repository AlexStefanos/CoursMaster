import {Link, Route, Router, Switch, useHistory} from "react-router-dom";
import PopUpEditInfo from "./PopUpEditInfo";

/**
 * Table pour afficher les info d'un client.
 *
 * @param data les données.
 * @param setData pour modifier le client.
 *
 * @return {JSX.Element} la table ou y a des info.
 *
 */
export default function InfoTableComponent({data, setData, clientID}) {
    /*pour recuprer le path & la navigation*/
    const history = useHistory()

    return (
        <div className="details-info-container">
            <Link to={{
                pathname: "/DetailsClient/"+clientID+"/edit-client",
                data: data,
                setData: setData
            }}>
                <button className="btn-edit-details">modifier</button>
            </Link>

            <ul>
                {
                    data.map((info) => (
                        <li className="details-info-item" key={info.toString()}>{info[2]}</li>
                    ))
                }
            </ul>
            <Router history={history}>
                <Switch>
                    <Route path="/DetailsClient/:id/edit-client" component={PopUpEditInfo}/>
                </Switch>
            </Router>

        </div>
    )
}