package exo2;

public enum Hebergement {
	HOTEL, AUBERGE;
}
