import axios from "axios";
//lien vers l'API (facture)
const URL_API_FACTURE="http://localhost:8080/factures"

class FactureService {
    /**
     * Recuprer la liste des factures de l'API.
     *
     * @return les factures
     */
    getFactures () {
        return axios.get(URL_API_FACTURE);
    }

    /**
     * ajouter une facture via l'API dans la base de données.
     * @param facture facture a ajouter.
     * @param idClient id de client de la facture.
     */
    createFacture(facture, idClient) {
        return axios.post(URL_API_FACTURE+"/ajouterFacture/"+idClient, facture);
    }

    /**
     * Récupérer le détails d'une facture
     * @param idFacture l'identifiant de facture a récupérer
     * @returns une facture
     */
    getFactureById(idFacture){
        return axios.get(URL_API_FACTURE+idFacture);
    }

}

export default new FactureService();