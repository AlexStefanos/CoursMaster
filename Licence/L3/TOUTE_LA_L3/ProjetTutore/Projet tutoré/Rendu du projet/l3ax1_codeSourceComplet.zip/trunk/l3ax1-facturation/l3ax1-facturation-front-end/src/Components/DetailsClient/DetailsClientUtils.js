/**
 * Etat initial d'un client
 * @type {{clientActuel: {nom: string}}} returner un client avec un nom vide.
 */
export const CLT_INIT = {
    clientActuel: {
        nom: ''
    }
}
/**
 * Recuprer les inforamation de compte d'un client.
 *
 * @param client le client
 * @return tableau des infos de compte
 */
export const getInfoCompte = (client) => {
    if (client.email == null) {
        return [
            ['solde', 'solde', client.solde],
            ['Raison Sociale', 'nom', client.clientActuel.nom],
            ['Forme juridique', 'formeJuridique', client.formeJuridique],
            ['Siret', 'siret', client.siret]
        ]
    }
    else {
        return [
            ['solde', 'solde', client.solde],
            ['nom', 'nom', client.clientActuel.nom],
            ['email', 'email', client.email],
            ['description', 'description', client.description]
        ]
    }
}

/**
 * Recuprer les inforamation de la facturation
 *
 * @param client le client
 * @return inofos de la facturation
 */
export const getInfoFacturation = (client) => {
    return [
        ['pays', 'pays', client.pays],
        ['adresse', 'adresse', client.adresse],
        ['code postal', 'codePostal', client.codePostal],
        ['ville', 'ville', client.ville]
    ]
}

/**
 * Recuprer les inforamation de livraison
 *
 * @param client le client
 * @return infos de livraison
 */
export const getInfoLivraison = (client) => {
    return [
        ['adresse', 'adresse', client.adresse],
        ['prefixe', 'prefixe', client.prefixe]
    ]
}

/**
 * Recuprer les inforamation de TVA
 *
 * @param client le client
 * @return infos de TVA
 */
export const getInfoTva = (client) => {
    return [
        ['Localisation', 'localisation', client.pays],
        ['N° TVA', 'numeroTva', client.numeroTva]
    ]
}

export const client2DetailsClient = (client) => {
    let tabAdresse = client.adresse.split(", ")

    let detailsClient = {
        clientActuel: client.clientActuel,
        pays: tabAdresse[0],
        adresse: tabAdresse[1],
        codePostal: tabAdresse[2],
        ville: tabAdresse[3],
        numeroTva : client.numeroTva,
        solde : client.solde,
        prefixe : 'L3AX_'
    }
    if (client.description == null) {
        detailsClient.siret = client.siret
        detailsClient.formeJuridique = client.formeJuridique
    } else {
        detailsClient.description = client.description
        detailsClient.email = client.email
    }

    return detailsClient;
}

export const detailsClient2Client = (detailsClient) => {
    let isPhysique = detailsClient.email != null;
    console.log("BOOL : " + isPhysique);
    let client = {
        clientActuel: {
            nom : detailsClient.nom
        },
        adresse: ""+detailsClient.pays+", "+detailsClient.adresse+", "+detailsClient.codePostal+", "+detailsClient.ville,
        numeroTva:  detailsClient.numeroTva,
        solde: detailsClient.solde,
        prefixe : 'PXAC12',
    }
    client.clientActuel.nom = detailsClient.clientActuel.nom
    if (!isPhysique) {
        client.siret = detailsClient.siret
        client.formeJuridique = detailsClient.formeJuridique
        console.log(client)
    }else {
        client.description = detailsClient.description
        client.email = detailsClient.email
    }

    return client
}