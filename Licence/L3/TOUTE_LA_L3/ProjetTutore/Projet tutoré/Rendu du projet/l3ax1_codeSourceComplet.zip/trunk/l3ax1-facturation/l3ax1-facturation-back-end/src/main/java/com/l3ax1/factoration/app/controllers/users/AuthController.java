/*
 * AuthController.java - une API pour la connexion et l'ajout d'un nouvel utilisateur.
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1,2, 3 et 4.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 * Source 3 : springboottutorial.com - Integrating Spring Boot and React with Spring Security - Basic and JWT Authentication - License MIT
 * Source 4 : https://grobmeier.solutions/ - How to use Spring Security to build a simple login page / Christian Grobmeier - © 1999-2018 Grobmeier Solutions GmbH
 */
package com.l3ax1.factoration.app.controllers.users;

import com.l3ax1.factoration.app.exception.AppException;
import com.l3ax1.factoration.app.Models.users.Role;
import com.l3ax1.factoration.app.Models.users.RoleName;
import com.l3ax1.factoration.app.Models.users.User;
import com.l3ax1.factoration.app.payload.ApiResponse;
import com.l3ax1.factoration.app.payload.JwtAuthenticationResponse;
import com.l3ax1.factoration.app.payload.LoginRequest;
import com.l3ax1.factoration.app.payload.SignUpRequest;
import com.l3ax1.factoration.app.repository.users.RoleRepository;
import com.l3ax1.factoration.app.repository.users.UserRepository;
import com.l3ax1.factoration.app.security.JwtTokenProvider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.Collections;

//Nous avons besoin d'une classe Controller à laquelle nous pouvons accéder en utilisant le navigateur.
//Nous mettons toutes les configurations pour écrire les API Rest dans les contrôleurs.

/**
 *  Dans AuthController, nous écrivons des API pour la connexion et l'ajout d'un nouvel utilisateur.
 *  
 * @version 1.0
 * @author Leonard NAMOLARU
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository; // Repository pour conserver le modèle User dans la base de données et le récupérer.

    @Autowired
    RoleRepository roleRepository; // Repository pour conserver le modèle User dans la base de données et le récupérer.

    @Autowired
    PasswordEncoder passwordEncoder; // Interface de service pour l'encodage des mots de passe

    @Autowired
    JwtTokenProvider tokenProvider;
    
    /**
     * API pour la connexion.
     * @param loginRequest
     * @return
     */
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
    	User user = userRepository.findByUsernameOrEmail(loginRequest.getUsernameOrEmail(), loginRequest.getUsernameOrEmail())
                .orElseThrow(() -> 
                        new UsernameNotFoundException("User not found with username or email : " + loginRequest.getUsernameOrEmail())
        );
    	
    	if(user.getUserApproved() == 0) {
            throw new UsernameNotFoundException("User not found with username or email : " + loginRequest.getUsernameOrEmail());
    	}

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsernameOrEmail(),
                        loginRequest.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = tokenProvider.generateToken(authentication);
        return ResponseEntity.ok(new JwtAuthenticationResponse(jwt)); // Réponse à la demande d'authentification.
    }
    
    /**
     * API pour l'ajout d'un nouvel utilisateur.
     * @param signUpRequest
     * @return
     */
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
        if(userRepository.existsByUsername(signUpRequest.getUsername())) {
            return new ResponseEntity(new ApiResponse(false, "Username is already taken!"),
                    HttpStatus.BAD_REQUEST);
        }

        if(userRepository.existsByEmail(signUpRequest.getEmail())) {
            return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"),
                    HttpStatus.BAD_REQUEST);
        }

        // Creating user's account
        User user = new User(signUpRequest.getName(), signUpRequest.getUsername(),
                signUpRequest.getEmail(), signUpRequest.getPassword());

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
                .orElseThrow(() -> new AppException("User Role not set."));

        user.setRoles(Collections.singleton(userRole));

        User result = userRepository.save(user);

        URI location = ServletUriComponentsBuilder
                .fromCurrentContextPath().path("/api/users/{username}")
                .buildAndExpand(result.getUsername()).toUri();

        return ResponseEntity.created(location).body(new ApiResponse(true, "User registered successfully"));
    }
}