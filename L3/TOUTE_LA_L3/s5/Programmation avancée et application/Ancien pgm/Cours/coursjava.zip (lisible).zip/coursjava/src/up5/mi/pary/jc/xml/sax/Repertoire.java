package up5.mi.pary.jc.xml.sax;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

public class Repertoire {
	private String proprietaire,creationDate;
	private Map<String,String> tels = new HashMap<String, String>( );

	public Repertoire(String creationDate) {this.creationDate = creationDate;}

	public void ajouterEntree(String nom,String tel){this.tels.put(nom,tel);}

	public String getTel(String nom){return this.tels.get(nom);}

	public void setProprietaire(String name){this.proprietaire=name;}
	public String getProprietaire ( ) {return this.proprietaire;}
	public String getCreationDate( ) {return this.creationDate;}
	
	//une méthode d'instance dans la classe Repertoire
	public void toXml(Writer writer)throws IOException{
		BufferedWriter bw = new BufferedWriter(writer);
		bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		bw.write("<repertoire creation=\""+this.getCreationDate( )+"\">\n");
		bw.write("     <proprietaire>"+this.getProprietaire( )+"</proprietaire>\n");
		for (String name:tels.keySet( )){
			bw.write("      <entree>\n");
			bw.write("           <nom>"+name+"</nom>\n");
			bw.write("           <telephone>"+tels.get(name)+"</telephone>\n");
			bw.write("      </entree>\n");
		}
		bw.write("</repertoire>\n");
		bw.flush( );
	}

}