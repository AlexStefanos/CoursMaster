/*
 * SignUpRequest.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1 et 2.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 */
package com.l3ax1.factoration.app.payload;

import javax.validation.constraints.*; // Jakarta Bean Validation : Exprimer des contraintes sur des modèles d'objets via des annotations

/**
 * SignUpRequest : Demande d'ajout d'un nouvel utilisateur.
 * (Nous devons définir la demande et la réponse que les API utiliseront).
 * 
 * 
 * Exemple d'une demande :
 * 
 *	{
 *   	"name": "Leonard NAMOLARU",
 *   	"username":"Leonard",
 *   	"email":"leonard.namolaru@etu.u-paris.fr",
 *   	"password":"Secret"
 *	}
 * 
 * @author Leonard NAMOLARU
 */
public class SignUpRequest {
    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(min = 4, max = 40) // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    private String name;

    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(min = 3, max = 15)
    private String username;

    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(max = 40) // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    @Email // La chaîne doit être une adresse e-mail bien formée.
    private String email;

    @NotBlank // L'élément annoté ne doit pas être nul et doit contenir au moins un caractère sans espace.
    @Size(min = 6, max = 20) // La taille de l'élément annoté doit être comprise entre les limites spécifiées (incluses).
    private String password;
    
    /**
     * La fonction renvoie la valeur actuelle du nom et prénom de l'utilisateur.
     * @return Nom et prénom de l'utilisateur.
     */
    public String getName() {
        return name;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du nom et prénom de l'utilisateur.
     * @param name Nom et prénom de l'utilisateur.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du nom d'utilisateur
     * @return Nom d'utilisateur (pour une future connexion au site)
     */
    public String getUsername() {
        return username;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du nom d'utilisateur (pour une future connexion au site).
     * @param username Nom d'utilisateur (pour une future connexion au site)
     */
    public void setUsername(String username) {
        this.username = username;
    }
    
    /**
     * La fonction renvoie la valeur actuelle de l'adresse électronique de l'utilisateur.
     * @return Adresse électronique
     */
    public String getEmail() {
        return email;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle de l'adresse électronique de l'utilisateur.
     * @param email Adresse électronique
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * La fonction renvoie la valeur actuelle du mot de passe de l'utilisateur.
     * @return Mot de passe pour une future connexion au site
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle du mot de passe de l'utilisateur.
     * @param password Mot de passe pour une future connexion au site
     */
    public void setPassword(String password) {
        this.password = password;
    }
}