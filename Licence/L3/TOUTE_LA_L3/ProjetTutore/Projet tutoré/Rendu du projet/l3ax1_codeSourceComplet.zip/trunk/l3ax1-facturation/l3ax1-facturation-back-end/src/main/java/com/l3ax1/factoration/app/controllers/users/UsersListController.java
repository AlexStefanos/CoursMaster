package com.l3ax1.factoration.app.controllers.users;

import com.l3ax1.factoration.app.Models.users.User;
import com.l3ax1.factoration.app.payload.*;
import com.l3ax1.factoration.app.repository.users.UserRepository;
import com.l3ax1.factoration.app.services.users.PageConstants;
import com.l3ax1.factoration.app.services.users.UserService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UsersListController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    private static final Logger logger = LoggerFactory.getLogger(UsersListController.class);

    @GetMapping
    public PagedResponse<User> getUsers(@RequestParam(value = "page", defaultValue = PageConstants.DEFAULT_PAGE_NUMBER) int page,
                                        @RequestParam(value = "size", defaultValue = PageConstants.DEFAULT_PAGE_SIZE) int size) {
        return userService.getAllUsers(page, size);
    }
    
    /**
     * API pour 
     * @param 
     * @return 
     * @return 
     */
    @GetMapping("/activateUser") 
    public UserIdentityAvailability activateUser(@RequestParam(value = "id") int userId) {
        User user = userRepository.getOne((long) userId);
        user.setUserApproved(1);
        user = userRepository.saveAndFlush(user);
        return new UserIdentityAvailability(user.getUserApproved() == 1 ? true : false);
}

}
