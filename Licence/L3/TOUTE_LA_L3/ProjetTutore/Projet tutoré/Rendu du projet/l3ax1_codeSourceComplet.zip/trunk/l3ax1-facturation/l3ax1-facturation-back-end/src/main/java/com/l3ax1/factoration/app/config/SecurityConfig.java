/*
 * SecurityConfig.java - Classe pour les configurations de sécurité.
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1, 2, 3, 4 et 5.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 * Source 3 : https://grobmeier.solutions/ - How to use Spring Security to build a simple login page / Christian Grobmeier - © 1999-2018 Grobmeier Solutions GmbH
 * Source 4 : https://www.javacodegeeks.com/ - Secure Spring Boot REST API using Basic Authentication / Chandana Napagoda - © 2010-2021, Exelixis Media P.C.
 * Source 5 : developer.okta.com - Add User Authentication to Your Spring Boot App in 15 Minutes - Auteur : Andrew Hughes - Copyright © 2021 Okta.
 */
package com.l3ax1.factoration.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity; // Annotation pour indiquer à Spring que l'application doit être sécurisée (Activer la sécurité).
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.l3ax1.factoration.app.security.CustomUserDetailsService;
import com.l3ax1.factoration.app.security.JwtAuthenticationEntryPoint;
import com.l3ax1.factoration.app.security.JwtAuthenticationFilter;


/**
 * Notre classe SecurityConfig implémente WebSecurityConfigurerAdapter
 * et remplace certaines de ses méthodes pour fournir des configurations
 * de sécurité personnalisées.
 * <p>
 * Un adaptateur (Adapter) est une classe qui implémente une interface spécifique.
 * L'adaptateur fournit généralement des implémentations par défaut utiles (donc pas
 * besoin d'implémenter toutes les méthodes). WebSecurityConfigurerAdapter implémente
 * WebSecurityConfigurer.
 * <p>
 * WebSecurityConfigurer fournit des configurations de sécurité par défaut et permet
 * à d'autres classes de l'implémenter et de personnaliser les configurations de sécurité en
 * remplaçant ses méthodes.
 *
 * @author Leonard NAMOLARU
 * @version 1.0
 */
@Configuration
@EnableWebSecurity // Annotation pour indiquer à Spring que l'application doit être sécurisée (Activer la sécurité).
@EnableGlobalMethodSecurity( // Ceci est utilisé pour activer "method level security" basée sur les annotations
        securedEnabled = true, // Active l'annotation @Secured à l'aide de laquelle nous pouvons protéger nos méthodes de contrôleur / service comme ceci : @Secured("ROLE_ADMIN").
        jsr250Enabled = true,  // Active l'annotation @RolesAllowed qui peut être utilisée comme ceci : @RolesAllowed("ROLE_ADMIN")
        prePostEnabled = true // Permet une syntaxe de contrôle d'accès basée sur des expressions plus complexes avec les annotations @PreAuthorize et @PostAuthorize : @PreAuthorize("isAnonymous()")
)
public class SecurityConfig extends WebSecurityConfigurerAdapter { // Notre classe SecurityConfig implémente WebSecurityConfigurerAdapter 

    /**
     * Pour authentifier un utilisateur ou effectuer diverses vérifications
     * basées sur les rôles, Spring security doit charger les détails des utilisateurs.
     */
    @Autowired
    CustomUserDetailsService customUserDetailsService;

    /**
     * JwtAuthenticationEntryPoint : Cette classe est utilisée pour renvoyer
     * une erreur "401 non autorisée" aux clients qui tentent d'accéder à une
     * ressource protégée sans authentification appropriée.
     */
    @Autowired
    private JwtAuthenticationEntryPoint unauthorizedHandler;

    /**
     * Nous utilisons JWTAuthenticationFilter pour implémenter un filtre qui :
     * (1) Lit le jeton d'authentification JWT à partir de l'en-tête
     * (2) Valide le jeton.
     * (3) Charge les détails de l'utilisateur associés à ce jeton.
     */
    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        return new JwtAuthenticationFilter();
    }

    /**
     * AuthenticationManagerBuilder est utilisé pour créer une instance de AuthenticationManager
     * qui est l'interface principale de Spring Security pour authentifier un utilisateur.
     * <p>
     * Dans notre projet, nous avons fourni notre customUserDetailsService et un passwordEncoder
     * pour créer AuthenticationManager.
     */
    @Override
    public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
        authenticationManagerBuilder
                .userDetailsService(customUserDetailsService)
                .passwordEncoder(passwordEncoder());
    }

    @Bean(BeanIds.AUTHENTICATION_MANAGER)
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * La méthode configure() est utilisée pour définir et mettre en place
     * des règles de sécurité globales : quels chemins d'URL doivent être sécurisés
     * et lesquels ne doivent pas l'être. Dans notre fonction, nous autorisons l'accès
     * aux ressources statiques et à quelques autres API publiques à tout le monde et
     * nous limitons l'accès aux autres API aux utilisateurs authentifiés uniquement.
     *
     * @param http le HttpSecurity à modifier
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .cors()
                .and() //Nous pouvons combiner des contraintes de sécurité en utilisant la méthod and()
                .csrf()
                .disable()
                .exceptionHandling()
                .authenticationEntryPoint(unauthorizedHandler)
                .and() //Nous pouvons combiner des contraintes de sécurité en utilisant la méthod and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and() //Nous pouvons combiner des contraintes de sécurité en utilisant la méthod and()
                .authorizeRequests()
                .antMatchers("/",
                        "/favicon.ico",
                        "/**/*.png",
                        "/**/*.gif",
                        "/**/*.svg",
                        "/**/*.jpg",
                        "/**/*.html",
                        "/**/*.css",
                        "/**/*.js")
                .permitAll() // Nous autorisons l'accès aux ressources statiques
                .antMatchers("/api/auth/**")
                .permitAll() // Nous autorisons l'accès à quelques API publiques
                .antMatchers("/**")
                .permitAll()
                .antMatchers("/api/user/checkUsernameAvailability", "/api/user/checkEmailAvailability")
                .permitAll() // Nous autorisons l'accès à quelques API publiques
                .antMatchers(HttpMethod.GET, "/api/polls/**", "/api/users/**")
                .permitAll() // Nous autorisons l'accès à quelques API publiques
                .anyRequest() // Toute autre demande
                .authenticated(); // Forcer toute autre demande à être authentifiée.

        // Ajout de notre filtre de sécurité JWT personnalisé
        http.addFilterBefore(jwtAuthenticationFilter(), UsernamePasswordAuthenticationFilter.class);

    }
}