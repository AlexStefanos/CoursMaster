import React from "react";
import './Facture.css'
import {ListeFacturePayee} from "./ListeFacture";

/**
 * Fonction flechi qui nous retourne la mis en page des facture payee sous forme d'un tableau
 * @param stateFacture les factures sous forme d'un tableau
 * @returns {JSX.Element} un tableau qui contient les facture payées
 */
const Facture = ({stateFacture}) => {
    return (
        <table className='tableau-style'>
            <thead className='tableau-tete'>
            <tr>
                <th>NOM</th>
                <th>Montant</th>
                <th>ETAT</th>
                <th>N° DE FACTURE</th>
                <th>DATE D'EMISSION</th>
                <th></th>
            </tr>
            </thead>
            <tbody className='corps-tableau'>
            {stateFacture.map(facture => (
                //Component qui rempli le corp de tableau avec les facture payee depuis la base de donnée
                <ListeFacturePayee facture={facture} />
            ))}
            </tbody>
        </table>
    )
}
export default Facture