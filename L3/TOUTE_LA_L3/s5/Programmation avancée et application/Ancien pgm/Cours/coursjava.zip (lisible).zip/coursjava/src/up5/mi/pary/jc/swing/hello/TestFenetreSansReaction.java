package up5.mi.pary.jc.swing.hello;
import java.awt.*;import javax.swing.*;

public class TestFenetreSansReaction {

	public static void main(String [ ] args) {

		// cr�er une fen�tre de titre "Ma deuxi�me fen�tre"
		JFrame frame = new JFrame(" Ma deuxi�me fen�tre ");
		// r�cup�rer le panel contenant les composants de la JFrame
		Container pane = frame.getContentPane( );
		// cr�er une �tiquette et l'ajouter "au nord" de la fen�tre
		JLabel label = new JLabel("Une fen�tre qui ne r�agit pas");
		pane.add(label , BorderLayout.NORTH);
		// cr�er un bouton et l'ajouter "au sud" de la fen�tre
		JButton bOk = new JButton("OK");
		pane.add(bOk , BorderLayout.SOUTH); 
		// lui donner une taille "optimale" , un setSize "automatique"
		frame.pack( );
		// afficher la fen�tre
		frame.setVisible(true);
	}
}
