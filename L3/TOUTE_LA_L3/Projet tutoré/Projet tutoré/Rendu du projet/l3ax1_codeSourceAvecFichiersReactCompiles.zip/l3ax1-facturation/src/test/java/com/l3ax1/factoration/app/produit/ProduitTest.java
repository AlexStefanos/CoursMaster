package com.l3ax1.factoration.app.produit;


import com.l3ax1.factoration.app.controllers.contrat.ContratController;
import com.l3ax1.factoration.app.controllers.produits.ProduitController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * <h1>ProduitTest: class Test API </h1>
 * <hr/>
 * Objectif de cette class est de tester {@link ProduitC}; or, ce derniers serai appelé à
 * travers des URL par les programmes qui communiqueront avec (API).
 * <br/><br/>
 * {@link SpringBootTest} @SpringBootTest est une annotation fournie par Spring Boot. Elle permet
 * lors de l’exécution des tests d’initialiser le contexte Spring. Les beans de notre application
 * peuvent alors être utilisés.
 * <br/>
 * {@link AutoConfigureMockMvc } Annotation qui peut être appliquée  à  une  classe  de test pour
 * activer et configurer la configuration automatique de MockMvc.
 * <p>
 * <hr/>
 * @see ContratController
 * @see Test
 *
 * @author lounis BOULDJA
 * @version 1.0
 */
@SpringBootTest
@AutoConfigureMockMvc
public class ProduitTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ProduitController produitController;


    /**
     * <h2>Tester si le controler n'est pas null</h2>
     */
    @Test
    public void contextLoads() {
        assertThat(produitController).isNotNull();
    }


    /**
     * <h2>  getProduits : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients). On exécute donc
     * une requête GET sur l’URL /clients. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitGetProduits() throws Exception {
        mockMvc.perform(get("/produits"))
                .andExpect(status().isOk());
    }


    /**
     * <h2>  CreateProduit : Test unitaire</h2>
     * La méthode  perform  prend en paramètre l’instruction get(/clients). On exécute donc
     * une requête GET sur l’URL /clients. Ensuite, l’instruction .andExpect(status().isOk())
     * indique que nous attendons une réponse HTTP 200.
     *
     * @throws Exception
     */
    @Test
    public void testUnitPostCreateProduit() throws Exception {

        mockMvc.perform(post("/produits/ajouter")
                .contentType(MediaType.APPLICATION_JSON)
                .content("    {\n" +
                        "        \"nom\": \"Test\",\n" +
                        "        \"typeProduit\": true,\n" +
                        "        \"prixHt\": 1000,\n" +
                        "        \"prixTtc\": 1000,\n" +
                        "        \"tauxTva\": 20\n" +
                        "    }"))
                .andExpect(status().isOk());
    }


    /**
     * <h2>Tester la methode getProduits : Test D'integration</h2>
     * <p>
     * vérifier si le statut vaut 200 (Le code de statut de réponse HTTP 200 OK indique
     * la réussite d'une requête.) <br/>
     * <p>
     * vérifie le contenu retourné grâce à jsonPath("$[indice].attribut", is("value")).
     * <ul>
     *     <li>$ pointe : sur la racine de la structure JSON.</li>
     *     <li>[indice] : indique qu’on veut vérifier le premier élément de la liste.</li>
     *     <li>attribut : désigne l’attribut qu’on veut consulter.</li>
     * </ul>
     *
     * @throws Exception preform exception
     */
    @Test
    public void testGetProduits() throws Exception {
        mockMvc.perform(get("/produits"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nom", is("COCA")));
    }

}
