package com.l3ax1.factoration.app.controllers.contrat;
import com.l3ax1.factoration.app.Models.contrat.Contrat;
import com.l3ax1.factoration.app.services.contrat.ContratService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * <h1>ContrController : class</h1>
 * <hr/>
 * Contrat Controller permet de communiquer avec front end react. Pour accéder
 * à notre API on utilise des endpoints associé à une URL,  Lorsqu'on appelle
 * cette URL, on reçoit une réponse, et cet échange se fait en HTTP. et grâce
 * à Spring-Boot-starter-web nous  fournit  tout  le nécessaire pour créer un
 * endpoint.
 * <br/><br/>
 *
 * {@link RestController} : Comme @Component, elle permet d’indiquer à Spring
 * que cette classe est un bean, et aussi   indiqué  à  Spring  d’insérer  le
 * retour  de  la méthode  au  format  JSON  dans le corps de la réponse HTTP.
 * Grâce à  ça , les applications qui  vont communiquer avec l’API accéderont
 * au résultat de leur requête en parsant la réponse HTTP. <br/>
 *
 * {@link CrossOrigin} : Annotation  pour  autoriser  les  requêtes d'origine
 * croisée  sur  des  classes  de  gestionnaire  et  /  ou  des  méthodes  de
 * gestionnaire spécifiques. Traité si un HandlerMapping approprié est configuré.
 *
 * <hr/>
 *
 * @see ContratService
 * @see RestController
 * @see CrossOrigin
 *
 * @version 1.0
 * @author Lounis BOULDJA
 */

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class ContratController {

    /**
     * Cela permettra d’appeler les méthodes pour communiquer avec la base de données.
     *
     * @see ContratService
     **/
    @Autowired
    ContratService contratService;


    /**
     *<h2>Recuperer la list de Contrat de la base de données.</h2>
     *
     * {@link GetMapping} Cela signifie que les requêtes  HTTP de  type  GET à l’URL /contrats
     * exécuteront le code de cette méthode. Et ce code est tout simple : il s’agit d’appeler
     * la méthode  getContrats()  du  {@link ContratService},  ce  dernier appellera la méthode
     * findAll()  du  {@link testbackend.demo.repository.contrat.ContratRepository}
     * et nous obtiendrons ainsi tous les clients enregistrés  en  base de données.
     *
     * @return <strong>la liste des Contrats enregistrés  en  base de données.<strong/>
     * @see GetMapping
     */
    @GetMapping("/contrats")
    public Iterable<Contrat> getContrats () {
        return this.contratService.getContrats();
    }

    /**
     * <h2>Creer un Contrat et l'ajouter dans la base de données</h2>
     *
     * {@link PostMapping } Pour l’envoi de données. Cela sera utilisé crée un contrat
     * et le stocker dans la base de données. <br/>
     * <p>
     * {@link RequestBody} L'annotation indiquant qu'un paramètre de méthode doit être
     * lié au corps de la requête Web
     *
     * @param contrat le contrat a ajouté
     * @return contrat stocké dans la base de données.
     */
    @PostMapping ("/contrats/add/{id}")
    public Contrat createContrat(@PathVariable Long id, @RequestBody Contrat contrat) {
        return this.contratService.createContrat(contrat, id);
    }


    /**
     * <h2>Suprimer un client de la base de données</h2>
     * @param id id de client
     * @return true : si le client est bien suprimé
     *         false : sinon
     */
    @DeleteMapping("/contrats/delete/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id) {
        Contrat employee = this.contratService.findContratById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Contrat n'existe pas avec id :" + id));

        this.contratService.deleteContrat(employee);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }

}
