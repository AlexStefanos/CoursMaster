package up5.mi.pary.jc.abstrait;

public class Rectangle extends Figure{
	
	private double largeur,longueur;
	
	public Rectangle(double longueur,double largeur){
		this.longueur=longueur;this.largeur=largeur;
		}
	
	public double getPerimetre( ){
		return(2*(this.largeur+ this.longueur));
		}
	
	public double getAire( ){
		return(this.largeur* this.longueur);
		}
	
}
