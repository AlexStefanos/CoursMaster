package up5.mi.pary.jc.tri;

import up5.mi.pary.jc.util.UtilTab;

public class TriSelectionEchange {

	/* les 'n' premiers éléments de 'tab' sont triés par ordre croissant */
	public static void trier(int [] tab,int n){
		for (int etape=1;etape<=n-1;etape++){
			// dep est l'indice à partir duquel le plus petit élément est cherché
			int dep = etape-1;
			// j est l'indice du plus petit
			int j = UtilTab.indiceDuPlusPetit(tab,dep,n-1);
			// permuter les éléments d'indice dep et j
			UtilTab.echanger(tab,dep,j);
		}
	}



}
