import React, {Component} from 'react';
import ClientsService from "../../Services/ClientService";
import {useHistory} from "react-router-dom";

/**
 * afficher les details d'un contrat.
 * @param contrat contrat
 * @return {JSX.Element} details d'un contrat
 */
function ContratDetatils({contrat}) {
    return (
        <tr className="contrat-row">
            <td>{contrat.nom}</td>
            <td>{contrat.typeFacturation}</td>
            <td>{contrat.dateDebut}</td>
            <td>{contrat.duree} mois</td>
        </tr>
    )
}

/**
 * client sans contrats.
 * @return {JSX.Element} contrat vide.
 * @constructor
 */
function EmptyContat() {

    const history = useHistory()
    return (
        <div className="empty-contrat-container">
            PAS DE CONTRATS
            <button onClick={()=> history.push("/Contrats/add")}>
                +
            </button>
        </div>
    )
}

/**
 * La liste des contrats.
 */
class ContratList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            contrats: null
        }
    }


    /**
     * charger les contrats d'un client.
     */
    componentWillMount() {
        ClientsService.getClientContrats(this.props.id).then((res) => {
            this.setState({
                contrats: res.data
            })
        })
    }

    render() {
        if (this.state.contrats == null)
            return null
        return (this.state.contrats.length === 0)
            ? <EmptyContat/>
            : (
                <table className="contrats-list-container">
                    <tbody>
                    {
                        this.state.contrats.map((contrat) => (<ContratDetatils contrat={contrat}/>))
                    }
                    </tbody>
                </table>
            );
    }
}

export default ContratList;