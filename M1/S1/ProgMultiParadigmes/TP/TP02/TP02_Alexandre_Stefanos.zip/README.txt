TP02 Programmation Multi-Paradigmes
La classe Metro contient le Main.