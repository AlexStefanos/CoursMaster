import React, {Fragment} from "react";
import './BoutonNavbarQE.css'

/**
 * Fonction qui retourne une div qui correspond à l'état choisi dans le paramètre de la fonction
 * @param etat de div à choisir
 * @returns {JSX.Element} une div
 */
const EtatPayement = ({etat}) => {
    return (
        <Fragment>
            {etat ?
                <div className='payee'>
                    <p>payée</p>
                </div>
                :
                <div className='echec'>
                    <p>echec</p>
                </div>
            }
        </Fragment>
    )
}
export default EtatPayement