package up5.mi.pary.jc.mvc.chat.client.test;

import up5.mi.pary.jc.mvc.chat.client.controleur.ControleurCS;
import javafx.application.Application;
import javafx.stage.Stage;

public class TestControleurCS extends Application{
	
	@Override
	public void start(Stage stage) {
			String userName="toto"+System.currentTimeMillis();
			String url="http://localhost:8080/moncontexte/chat";		
			new ControleurCS(stage,userName,url);
		}
	
	public static void main(String[] args) {
		launch(args);
	}

}
