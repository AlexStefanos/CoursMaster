/*
 * App.js
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch, withRouter } from 'react-router-dom'
import { getCurrentUser } from './Services/APIUtils';
import { ACCESS_TOKEN } from './Services/constants';

import LoginComponent from './Components/Utilisateurs/LoginComponent';
import InscriptionComponent from './Components/Utilisateurs/InscriptionComponent';
import UtilisateursListeComponent from './Components/Utilisateurs/UtilisateursListeComponent';
import PageIntrouvable from './Components/Erreurs/PageIntrouvable';
import Navbar from './Components/Navbar/Navbar'
import FactureComponent from "./Components/Factures/FactureComponent";
import ClientComponent from "./Components/Clients/ClientComponent";
import ArticleComponent from "./Components/Articles/ArticleComponent";
import ContratComponent from "./Components/Contrats/ContratComponent";
import DetailsClientComponent from "./Components/DetailsClient/DetailsClientComponent";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentUser: null,
      isAuthenticated: false,
      isLoading: false
    }
    this.handleLogout = this.handleLogout.bind(this);
    this.loadCurrentUser = this.loadCurrentUser.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
  }

  loadCurrentUser() {
    this.setState({
      isLoading: true
    });
    getCurrentUser()
    .then(response => {
      this.setState({
        currentUser: response,
        isAuthenticated: true,
        isLoading: false
      });
    }).catch(error => {
      this.setState({
        isLoading: false
      });  
    });
  }

  componentDidMount() {
    this.loadCurrentUser();
  }

  handleLogout(redirectTo="/", notificationType="success", description="Vous êtes déconnecté avec succès.") {
    localStorage.removeItem(ACCESS_TOKEN);

    this.setState({
      currentUser: null,
      isAuthenticated: false
    });

    this.props.history.push(redirectTo);
    alert(description);
  }

  handleLogin() {
	alert("Vous êtes connecté avec succès.");
    this.loadCurrentUser();
    this.props.history.push("/mes-factures");
  }

  render() {
    if(this.state.isLoading) {
      return "Chargement en cours..";
    }
    
    if(!this.state.isAuthenticated) {
    	return(
    		<Switch>
    			<Route path="/inscription" component={InscriptionComponent}></Route>
    			<Route render={(props) => <LoginComponent onLogin={this.handleLogin} {...props} />}></Route>
    		</Switch>
    	); 
    }
    return (
    	<div className="App">
        <header>
          <Navbar isAuthenticated={this.state.isAuthenticated} currentUser={this.state.currentUser} onLogout={this.handleLogout} />
		</header>
        <div className="container">
        	<Router>
              <Switch>
              	 <Route exact path='/' component={FactureComponent}/>
              	 <Route path='/login' component={FactureComponent}/>
              	 <Route path='/mes-factures' component={FactureComponent}/>
                 <Route path='/mes-clients' component={ClientComponent}/>
                 <Route path="/DetailsClient/:id" component={DetailsClientComponent}/>
                 <Route path='/mes-produits' component={ArticleComponent}/>
                 <Route path='/mes-contrats' component={ContratComponent}/>
                 <Route path='/mes-utilisateurs' component={UtilisateursListeComponent}/>
                 <Route path="/inscription" component={FactureComponent}/>
                 <Route component={PageIntrouvable}/>
              </Switch>
             </Router>
            </div>
        </div>
    );
  }
}

export default withRouter(App);