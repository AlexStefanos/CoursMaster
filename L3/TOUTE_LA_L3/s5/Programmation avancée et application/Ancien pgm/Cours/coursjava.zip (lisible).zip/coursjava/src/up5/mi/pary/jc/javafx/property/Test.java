package up5.mi.pary.jc.javafx.property;

import javafx.beans.binding.StringExpression;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		{
		StringProperty sp1 = new SimpleStringProperty() ;
		StringExpression se3=sp1.concat("ERT");
		se3.addListener((e)-> System.out.println("SE3Value invalidated"));;
		se3.addListener((ObservableValue<? extends String> arg0,
				String arg1, String arg2) ->System.out.println("SE3Value changed:"+arg2));
		sp1.setValue("34");

	} 
	if (false){
	StringProperty sp1 = new SimpleStringProperty() ;
		StringProperty sp2 = new SimpleStringProperty() ;
		 StringExpression se3=sp1.concat("ERT");
		 se3.addListener((ObservableValue<? extends String> arg0,
					String arg1, String arg2) ->System.out.println("SE3Value changed:"+arg2));
    	 StringProperty sp4 = new SimpleStringProperty() ;
			// sp4.bind(se3);

		se3.addListener((e)-> System.out.println("SE3Value invalidated"));;
		sp1.bindBidirectional(sp2);
		sp1.setValue("ok");

		sp1.addListener((e)-> System.out.println("SP1 Value invalidated"));
		sp2.addListener((e)-> System.out.println("SP2 Value invalidated"));
		sp4.addListener((e)-> System.out.println("SP4 Value invalidated"));
		sp1.setValue("ok1");
		sp1.setValue("ok2");
		System.out.println(sp2.getValue());
		System.out.println(se3.getValue());
		sp1.setValue("htllo");
	 


}

}
}
