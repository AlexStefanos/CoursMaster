package up5.mi.pary.jc.swing.example;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import up5.mi.pary.jc.util.Compteur;

public class TestPanelCompteur {

	public static void main(String [ ] args){

		Compteur compteur = new Compteur( );
		JFrame frame = new JFrame("Cliquez !");

		JPanel panel = new PanelCompteur(compteur);

		frame.setContentPane(panel);
		frame.pack( );
		frame.setVisible(true);
	}
}
