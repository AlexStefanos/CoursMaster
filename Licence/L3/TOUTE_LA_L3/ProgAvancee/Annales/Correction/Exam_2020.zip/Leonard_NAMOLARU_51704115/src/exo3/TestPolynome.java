package exo3;

import java.util.HashMap;
import java.util.Map;

public class TestPolynome {

	public static void main(String[] args) {
		Map<Integer, Integer> polynome = new HashMap<Integer, Integer>();
		polynome.put(0, 2);
		polynome.put(1, 3);
		polynome.put(2, 0);
		polynome.put(3, -4);
		
		Polynome poly = new Polynome(polynome);

		System.out.println("Le polynome est : " + poly.toString() + ".");
		for (int i = 0; i < 10; i++) {
			System.out.println("Le coefficient de degre " + i + " est " + poly.coefficient(i) + ".");
		}
		
		Map<Integer, Integer> polynome2 = new HashMap<Integer, Integer>();
		polynome2.put(0, 3);
		polynome2.put(1, -1);
		polynome2.put(2, 4);
		Polynome poly2 = new Polynome(polynome2);

		System.out.println(
				"La somme de " + poly.toString() + " et " + poly2.toString() + " est " + poly.addition(poly2) + ".");

		for (int x = 0; x < 10; x++) {
			System.out.println("La valeur de " + poly.toString() + " pour x = " + x + " est " + poly.evaluer(x));
			System.out.println(
					"La valeur de " + poly.toString() + " pour x = " + (x + 0.5) + " est " + poly.evaluer(x + 0.5));
		}
	}

}
