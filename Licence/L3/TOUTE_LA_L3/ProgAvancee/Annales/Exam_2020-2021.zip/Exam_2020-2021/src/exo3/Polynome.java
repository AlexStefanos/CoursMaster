package exo3;

public class Polynome implements IPolynome {

	@Override
	public int coefficient(int degre) {
		throw new UnsupportedOperationException();
	}

	@Override
	public IPolynome addition(IPolynome p) {
		throw new UnsupportedOperationException();
	}

	@Override
	public double evaluer(double x) {
		throw new UnsupportedOperationException();
	}
	
	@Override
	public String toString() {
		throw new UnsupportedOperationException();
	}

}
