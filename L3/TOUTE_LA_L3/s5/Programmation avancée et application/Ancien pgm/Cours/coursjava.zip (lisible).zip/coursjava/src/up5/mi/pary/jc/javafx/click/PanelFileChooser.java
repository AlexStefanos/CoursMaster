package up5.mi.pary.jc.javafx.click;

import java.io.File;

import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import up5.mi.pary.jc.util.Compteur;

public class PanelFileChooser extends BorderPane{


	public PanelFileChooser(Stage stage){
		

		Button button = new Button("OK");
		
		button.setOnAction(
			(event) -> {
				// création d'une instance de JFileChooser
				FileChooser hf = new FileChooser( );
				// on indique ici le répertoire devant être proposé au départ
				
				hf.setInitialDirectory(new File("/Library/Java"));
				// On demande l'affichage de la fenêtre de dialogue
				File file = hf.showOpenDialog(stage);// window = stage par exemple
				// l'appel précédent est bloquant : 
				System.out.println(file);

			}
		);

		this.setCenter(button);

	}
}
