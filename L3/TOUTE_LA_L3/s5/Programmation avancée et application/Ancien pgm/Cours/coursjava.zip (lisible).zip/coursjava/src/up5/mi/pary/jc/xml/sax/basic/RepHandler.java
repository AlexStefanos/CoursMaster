package up5.mi.pary.jc.xml.sax.basic;

import org.xml.sax.Attributes;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import up5.mi.pary.jc.xml.sax.Repertoire;


public class RepHandler extends DefaultHandler {
	private Repertoire rep;
	boolean inProprio,inNom,inTelephone;
	private String nom,tel;

	public void startElement(String uri, String localName, String rawName, Attributes atts) {
		if (rawName.equals("repertoire")){
			String creationDate = atts.getValue("creation");
			rep=new Repertoire(creationDate);
		}
		else if (rawName.equals("proprietaire"))    inProprio=true;
		else if (rawName.equals("telephone"))       inTelephone=true;
		else if (rawName.equals("nom"))                inNom=true;
	}

	public void characters(char[ ] ch, int start, int length){

		String value=String.copyValueOf(ch, start, length).trim();
		if (inProprio)       rep.setProprietaire(value);
		else if (inNom)      nom=value;
		else if (inTelephone)tel=value;

	}
	public void endElement(String uri, String localName, String rawName) {
		if (rawName.equals("proprietaire"))        inProprio=false;
		else if (rawName.equals("telephone"))     inTelephone=false;
		else if (rawName.equals("nom"))              inNom=false;
		else if (rawName.equals("entree"))     
			rep.ajouterEntree(nom, tel);
	}


	public Repertoire getRepertoire() {
		return this.rep;
	}
	
	public void error(SAXParseException e) throws SAXParseException {
		throw e;}
	public void warning(SAXParseException e)throws SAXParseException{
		throw e;}

}

