package up5.mi.pary.jc.abstrait;

public class Carre extends Rectangle{

	public Carre(double longCote){
		super(longCote,longCote);
	}

}
