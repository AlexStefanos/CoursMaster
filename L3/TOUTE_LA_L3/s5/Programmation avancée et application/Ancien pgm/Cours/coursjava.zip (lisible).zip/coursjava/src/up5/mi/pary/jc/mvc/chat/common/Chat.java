package up5.mi.pary.jc.mvc.chat.common;

import java.util.ArrayList;
import java.util.List;


public class Chat {

	private List<Message> listMessages= new ArrayList<Message>( ) ;

	public Chat(  ){ }

	public synchronized void addMessage(String user,String text){
	    this.addMessage(new Message(user,text));
	}

	public synchronized void addMessage(Message message){
	     listMessages.add(message);
	     fireMessageAdded(message);
	}

	@Override
	public synchronized String toString( ) {
		StringBuffer sb = new StringBuffer( );
		for (Message message : listMessages)
			sb.append(message+"\n");
		return sb.toString( );
	}


	/** la liste des �couteurs */
	private List<ChatListener> listeners=new ArrayList<ChatListener>();

	/** ajout d'un �couteur */
	public void addChatListener(ChatListener listener){
		this.listeners.add(listener);
	}

	/** avertie tous les �couteurs  qu'un nouveau message a �t� ajout� au chat*/
	private void fireMessageAdded(Message message) {
		for (ChatListener listener:this.listeners)
			listener.messageAjoute(this, message);
	}
	/**
	 * 
	 * @param indexFrom l'indice du premier message souhait�
	 * @return les messages � partir de cet indice
	 */
	public synchronized List<Message> getMessages(int indexFrom){
		return new ArrayList<Message>(this.listMessages.subList(indexFrom, this.listMessages.size()));
	}

	/**
	 * le nombre de messages du chat
	 * @return
	 */
	public synchronized int getMessagesCount() {
		return this.listMessages.size();
	}
}
