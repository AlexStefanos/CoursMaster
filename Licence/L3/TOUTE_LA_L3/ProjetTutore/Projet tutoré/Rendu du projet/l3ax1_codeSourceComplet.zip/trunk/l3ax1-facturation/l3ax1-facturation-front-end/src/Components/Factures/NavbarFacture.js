import React,  {Component } from 'react'
import MenuItemsFacture from "./MenuItemsFacture";
import './NavbarFacture.css'

/**
 * class qui retourne navbar pour les navbar pour les factures payées impayées et toutes les factures
 */
class NavbarFacture extends Component {
    state ={
        cliquer : false
    }
    /**
     * fonction qui gère le clique pour chaue items de la navbar
     */
    handleClick = () => {
        this.setState({
            cliquer : !this.state.cliquer
        })
    }
    render() {
        return (
            <nav className='NavbarItemsFacture'>
                <div className='menu-icon-fact' onClick={this.handleClick}>
                    <i className={this.state.cliquer ? 'fas fa-times' : 'fas fa-bars'}/>
                </div>
                <ul className={this.state.cliquer ? 'nav-menu-fact active' : 'nav-menu-fact'}>
                    {MenuItemsFacture.map((item, index) => {
                        return(
                            <li key={index}>
                                <a className={item.cName} href={item.url}>{item.title}</a>
                            </li>
                        )
                        })}

                </ul>
            </nav>
        );
    }
}
export default NavbarFacture;