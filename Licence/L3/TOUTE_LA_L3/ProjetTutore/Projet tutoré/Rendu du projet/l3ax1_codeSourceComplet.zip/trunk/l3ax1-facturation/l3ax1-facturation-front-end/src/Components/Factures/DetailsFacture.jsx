import React, {Component} from 'react';
import EtatPayement from "../Boutons/EtatPayement";
import './DetailsFacture.css'

/**
 * Class qui nous retourne le tableau des produits
 */
class DetailsProduit extends Component {
    state = {
        //state pour charger la liste des produits
        produitsList: []
    }

    /**
     * Fonction qui charge le state produitsList par les produits déjà saisi
     */
    componentDidMount() {
        let produitsTmp = []
        let tabProduits = this.props.produits.split("\n")
        tabProduits.map((produit) => {
            let tabPrd = produit.split("\t")
            produitsTmp.push({
                nom: tabPrd[0],
                prix: tabPrd[1]
            })
        })
        this.setState({
            produitsList: produitsTmp
        })
    }

    render() {
        return (
            <table className='tableau-style-afficher-facture'>
                <thead className='tableau-tete-afficher-facture'>
                <tr>
                    <th>Article</th>
                    <th>PRIX</th>
                </tr>
                </thead>
                <tbody className='corps-tableau-afficher-facture'>
                {
                    this.state.produitsList.map((produit) => (
                        <tr>
                            <td>{produit.nom}</td>
                            <td>{produit.prix}</td>
                        </tr>
                    ))
                }
                </tbody>
            </table>
        );
    }
}

/**
 * Fonction qui affiche le popup avec les informations d'une facture
 * @param facture la facture a afficher
 * @param showPopUp pour gèrer l'affichage de popup
 * @returns {JSX.Element} un popup avec les informations de la facture choisi
 */
const DetailsFacture = ({facture, showPopUp}) => {
    return (
        <div className='popup'>
            <div className='popup-inner'>
                <div>
                    <h2 className='titre-afficher-facture'>
                        <i className="fas fa-file-invoice"></i>
                        FACTURE N°
                    </h2>
                    <p className='infos'>
                        <span className='infos-num'>{facture.numeroFacture}</span>
                        pour
                        <span className='infos-prix'>{facture.totalTTC}</span>
                        €
                    </p>
                    {facture.facturePayee ?
                        <p className='etat-fact'>
                            <EtatPayement etat={true}/>
                        </p>
                        :
                        <p className='etat-fact'>
                            <EtatPayement etat={false}/>
                        </p>
                    }
                    <h3 className='titre-client-afficher-facture'>Résumé</h3>
                    <div className='separer'>
                        <p>
                            <span className='info-details'>Facturé à</span>
                            <span className='info-donnee'>{facture.client.clientActuel.nom}</span>
                        </p>
                        <p>
                            <span className='info-details'>Adresse</span>
                            <span className='info-donnee'>{facture.client.adresse}</span>
                        </p>
                        <p>
                            <span className='info-details'>Numéro de facture</span>
                            <span className='info-donnee'>{facture.numeroFacture}</span>
                        </p>
                        <p>
                            <span className='info-details'>Date d'émission</span>
                            <span className='info-donnee'>{facture.dateEmission}</span>
                        </p>
                    </div>
                </div>
                <DetailsProduit produits={facture.informations}/>
                <div>
                    <p>
                        <span className='info-details'>Avoir</span>
                        <span className='info-donnee'>{facture.avoir}</span>
                    </p>
                    <p>
                        <span className='info-details'>Total</span>
                        <span className='info-donnee'>{facture.totalTTC}</span>
                    </p>
                    {facture.facturePayee ?
                        <p>
                            <span className='info-details'>Montant payé</span>
                            <span className='info-donnee'>{facture.totalTTC} €</span>
                        </p>
                        :
                        <p>
                            <span className='info-details'>Montant payé</span>
                            <span className='info-donnee'>0 €</span>
                        </p>
                    }
                    {facture.facturePayee ?
                        <p>
                            <span className='info-details'>Montant dû</span>
                            <span className='info-donnee'>0 €</span>
                        </p>
                        :
                        <p>
                            <span className='info-details'>Montant dû</span>
                            <span className='info-donnee'>{facture.totalTTC} €</span>
                        </p>
                    }
                </div>
                <button className='close-btn-details' onClick={showPopUp}>Retour</button>
            </div>

        </div>
    )
}
export default DetailsFacture