/*
 * Role.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1 et 2.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 */
package com.l3ax1.factoration.app.Models.users;

import org.hibernate.annotations.NaturalId; // Cela spécifie qu'une propriété fait partie de l'identifiant naturel de l'entité.
import javax.persistence.*;

/**
 *  Une Entité (JPA) qui représente les roles dans la base de données.
 *  Chaque utilisateur aura un ou plusieurs rôles (ROLE_ADMIN, ROLE_USER..) 
 *  La classe Role contient un identifiant et un champ de nom.Le champ de nom est une énumération. 
 *  Nous aurons un ensemble fixe de rôles prédéfinis. Il est donc logique que le nom du rôle soit enum.
 *  
 * {@link Entity} : la classe correspond à une table de la BDD.
 * {@link Table} : le nom de la table.
 * 
 * @version 1.0
 * @author Leonard NAMOLARU
 */
@Entity
@Table(name = "roles")
public class Role {
    @Id // Spécifie la clé primaire d'une entité.
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Fournit la spécification de stratégies de génération pour les valeurs des clés primaires.
    private Long id;

    @Enumerated(EnumType.STRING) // Spécifie qu'une propriété ou un champ persistant doit être conservé en tant qu'énumération
    @NaturalId // Cela spécifie qu'une propriété fait partie de l'identifiant naturel de l'entité.
    @Column(length = 60)
    private RoleName name;

    /**
     * Constructeur vide (Constructeur par défaut).
     */
    public Role() {

    }
    
    /**
     * Constructeur - Créer une nouvelle instance de l'objet Role
     * @param name Le nom du role est une énumération de type RoleName
     */
    public Role(RoleName name) {
        this.name = name;
    }

    /**
     * La fonction renvoie la valeur actuelle de l'identifiant unique du role.
     * @return L'identifiant unique du role.
     */
    public Long getId() {
        return id;
    }

    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle de l'identifiant unique du role.
     * @param id L'identifiant unique du role.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * La fonction renvoie la valeur actuelle du nom du role.
     * @return Le nom du role. 
     */
    public RoleName getName() {
        return name;
    }
    
    /**
     * La fonction permet de déterminer ou de mettre à jour la valeur actuelle le nom du role.
     * @param name Le nom du role.
     */
    public void setName(RoleName name) {
        this.name = name;
    }
}