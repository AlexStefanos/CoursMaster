package up5.mi.pary.term.convertor;

public class IntConvertor extends Convertor {

	@Override
	public Object valider(String ch) {
		return Integer.parseInt(ch);
	}

	@Override
	public String getMessage() {
		return "entier compris entre -2^31 et 2^31-1 attendu";
	}

}
