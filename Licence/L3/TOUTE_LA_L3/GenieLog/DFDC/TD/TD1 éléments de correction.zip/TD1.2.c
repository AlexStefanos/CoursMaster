#include <stdio.h>

// CONSTANTE
#define	TM	100
#define	END	'\0'

// TYPE FONCTION
int compare(char a[TM], char b[TM]) {
        int i = 0; // initialisation i
        while ((a[i] == b[i]) && ((a[i] != END) && (b[i] != END))) {
                i++; //I Maj
        }
        if (a[i] == b[i]) return (0);
        if (a[i] == END || b[i] == END) return (-2);
        if (a[i] < b[i]) return (1);
        return (-1);
}

int main(void) {
        char a[TM], b[TM]; //CHAR
        int comp;

	printf("************************************\n");
	printf("****  COMPARAISON DE DEUX MOTS  ****\n");
	printf("************************************\n\n");
        printf("Saisissez le premier mot : ");
        scanf("%s", a); //Pas besoin de mettre & pour passer une adresse de tableau
        printf("Saisissez le second mot : ");
        scanf(" %s", b);

        comp = compare(a, b);

        printf("\nRésultat : ");

        switch (comp) { //LES BREAKS
		case 0:
		        printf("%s et %s sont égaux! \n", a, b);
			break;
		case 1:
		        printf("%s est lexico-graphiquement inferieure a %s\n", a, b);
			break;
		case (-1):
		        printf("%s est lexico-graphiquement supérieure a %s\n", a, b);
			break;
		default:
		        printf("Il y a inclusion!\n");
        }
}
