package up5.mi.pary.jc.exenum;

public class Test {

	public static void main(String[] args) {
		Reponse rep=getReponse();
		if (rep==Reponse.OUI)
			System.out.println("la réponse est positive");
		else if (rep==Reponse.NON)
			System.out.println("la réponse est négative");
		switch (rep){
		case OUI : System.out.println("la réponse est positive");
		case NON : System.out.println("la réponse est négative");
		default:
		}
	}
	
	public static Reponse getReponse(){
		return Reponse.OUI;
		
	}
	
	public ReponseOld getReponseOldFromString(String reponse){
		if (reponse.equals("o"))
			return ReponseOld.OUI;
		else if (reponse.equals("n"))
			return ReponseOld.NON;
		else return ReponseOld.ANNULER;
	}

}
