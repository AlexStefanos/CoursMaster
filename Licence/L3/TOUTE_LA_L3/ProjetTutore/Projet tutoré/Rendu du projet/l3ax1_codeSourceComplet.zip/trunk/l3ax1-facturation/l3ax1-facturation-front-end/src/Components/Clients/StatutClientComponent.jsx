
/**
 * Fonction qui retourne un Client Morale.
 *
 * @param register  reference
 * @param errors erreurs
 * @return {JSX.Element} client Morale
 *
 * @version 1.0
 */
export function Morale({register, errors}) {
    return (
        <div className="info">
            <label>Forme juridique</label>
            <input type="text" name="formeJuridique" ref={register({required: true})}/>
            <label>Raison sociale</label>
            <input type="text" name="raisonSociale" ref={register({required: true})}/>
            <label>Siret</label>
            <input type="text" name="siret" ref={register({required: true})}/>
        </div>
    )
}

/**
 * Fonction qui retourne un Client Physique
 *
 * @param register reference
 * @param errors les erreurs
 * @return {JSX.Element} client physique
 */
export function Physique({register, errors}) {
    return (
        <div className="info">
            <label>Nom</label>
            <input type="text" name="nom" ref={register({required: true})}/>
            <label>Adresse e-mail du compte</label>
            <input type="email" name="email" ref={register({required: true})}/>
            <label>Description</label>
            <input type="text" name="description" ref={register({required: true})}/>
        </div>
    )
}