 /* InscriptionComponent.js
 * La page d'inscription de l'application Web.
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.
 *
 * Travail_effectué : Implémentation du code (source 1) dans le projet en l'adaptant aux besoins de notre projet + ajout d'explications, certaines des explications proviennent du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
import React, { Component, Fragment } from 'react';
import { signup, checkUsernameAvailability, checkEmailAvailability } from '../../Services/APIUtils';
import './InscriptionLoginStyle.css';
import logo from '../../Images/logo.png'
import { NAME_MIN_LENGTH, NAME_MAX_LENGTH, USERNAME_MIN_LENGTH, USERNAME_MAX_LENGTH, EMAIL_MAX_LENGTH, PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH } from '../../Services/constants';

class InscriptionComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: {
                value: ''
            },
            username: {
                value: ''
            },
            email: {
                value: ''
            },
            password: {
                value: ''
            }
        }
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.validateUsernameAvailability = this.validateUsernameAvailability.bind(this);
        this.validateEmailAvailability = this.validateEmailAvailability.bind(this);
        this.isFormInvalid = this.isFormInvalid.bind(this);
    }

    handleInputChange(event, validationFun) {
        const target = event.target;
        const inputName = target.name;        
        const inputValue = target.value;

        this.setState({
            [inputName] : {
                value: inputValue,
                ...validationFun(inputValue)
            }
        });
    }

    handleSubmit(event) {
        event.preventDefault();
    
        const signupRequest = {
            name: this.state.name.value,
            email: this.state.email.value,
            username: this.state.username.value,
            password: this.state.password.value
        };
        signup(signupRequest)
        .then(response => {
			alert("Merci! Vous etes enregistre avec succes. Cependant, vous ne pouvez vous connecter a votre compte qu'apres l'approbation de l'administrateur.");
            this.props.history.push("/login");
        }).catch(error => {
			alert('Pardon! Un probleme est survenu. Veuillez reessayer!');
        });
    }

    isFormInvalid() {
        return !(this.state.name.validateStatus === 'success' &&
            this.state.username.validateStatus === 'success' &&
            this.state.email.validateStatus === 'success' &&
            this.state.password.validateStatus === 'success'
        );
    }

    render() {
        return (
        	<Fragment>
        		 <img className="icon" src={logo} alt="Projet L3AX1" title="Projet L3AX1"/>
            	 <div className="back-container">
            	 	<h3>Inscription</h3>
                <div className="login-form">
                    <form onSubmit={this.handleSubmit} class="signup-form">
                            <input  name="name" id="name" placeholder="Nom et prénom" value={this.state.name.value} onChange={(event) => this.handleInputChange(event, this.validateName)} />    
                            <span id="name-error"> </span>
                            <input name="username" id="username" placeholder="Nom d'utilisateur" value={this.state.username.value} onBlur={this.validateUsernameAvailability} onChange={(event) => this.handleInputChange(event, this.validateUsername)} />    
                            <span id="username-error"> </span>
                            <input name="email" id="email" type="email" placeholder="Email" value={this.state.email.value} onBlur={this.validateEmailAvailability} onChange={(event) => this.handleInputChange(event, this.validateEmail)} />    
                             <span id="email-error"> </span>
                            <input name="password" id="password" type="password" placeholder="Mot de passe entre 6 et 20 caractères" value={this.state.password.value} onChange={(event) => this.handleInputChange(event, this.validatePassword)} />    
                            <span id="password-error"> </span>

							<br /><br />
                            <button type="submit" class="btn-cont" disabled={this.isFormInvalid()}>Inscription</button>
                            <br />
							<a href="/login" id="login-link">Connexion</a>
                    </form>
                </div>
            </div>
            </Fragment>
        );
    }

	
	/* Fonctions pour afficher un message d'erreur concernant un champ particulier 
	 *  ou pour marquer qu'un champ particulier est correctement rempli.
	*/
	
	// Afficher un message d'erreur concernant un champ particulier
	afficherMessageErreurSousLeChamp = (champ, message) => {
		    document.getElementById(champ).style.borderColor = "red"; // Changer la ligne sous le champ en rouge.
        	document.getElementById(champ + "-error").innerHTML = message; // Affiche un message d'erreur concernant le champ.
	}
	
	// Marquer qu'un champ particulier est correctement rempli
	champOK = (champ) => {
		    document.getElementById(champ).style.borderColor = "green"; // Changer la ligne sous le champ en vert
        	document.getElementById(champ + "-error").innerHTML = ""; // S'il y a un message d'erreur concernant ce champ, nous le supprimons.
	}

    /* Fonctions de validation
     */

    validateName = (name) => {
        if(name.length < NAME_MIN_LENGTH) {
			this.afficherMessageErreurSousLeChamp("name", "Le nom est trop court (Au moins " + NAME_MIN_LENGTH + " caractères.)")
            return {validateStatus: 'error'}
        } else if (name.length > NAME_MAX_LENGTH) {
			this.afficherMessageErreurSousLeChamp("name", "Le nom est trop long (Jusqu'à " + NAME_MAX_LENGTH + " caractères.)")
            return {validationStatus: 'error'}
        } else {
			this.champOK("name");
            return {validateStatus: 'success'};            
        }
    }
	
	/* Une fonction qui vérifie si cette chaîne représente une adresse e-mail valide.
	 */
    validateEmail = (email) => {
        if(!email) { // Un cas où le champ email est vide
			this.afficherMessageErreurSousLeChamp("email", "Le champ e-mail est vide");
            return { validateStatus: 'error'}
        }

        const EMAIL_REGEX = RegExp('[^@ ]+@[^@ ]+\\.[^@ ]+');
        if(!EMAIL_REGEX.test(email)) { // Nous vérifions si le format de la chaîne de caractères correspond au format d'une adresse e-mail.
			this.afficherMessageErreurSousLeChamp("email", "Email non valide");
            return {validateStatus: 'error'}
        }

        if(email.length > EMAIL_MAX_LENGTH) { // Si la chaîne de caractères contient trop de caractères.
			this.afficherMessageErreurSousLeChamp("email", "L'e-mail est trop long. Doit comporter au plus " + EMAIL_MAX_LENGTH + " caractères");
            return { validateStatus: 'error'}
        }
		
		this.champOK("email");
        return { validateStatus: null }
    } // validateEmail()

    validateUsername = (username) => {
        if(username.length < USERNAME_MIN_LENGTH) {
			this.afficherMessageErreurSousLeChamp("username", "Le nom d'utilisateur est trop court (MIN " + USERNAME_MIN_LENGTH + " caractères.)");
            return {validateStatus: 'error'}
        } else if (username.length > USERNAME_MAX_LENGTH) {
			this.afficherMessageErreurSousLeChamp("username", "Le nom d'utilisateur est trop long (MAX " + USERNAME_MAX_LENGTH + " caractères.)");
            return {validationStatus: 'error'}
        } else {
            return {validateStatus: null}
        }
    }

    validateUsernameAvailability() {
        // vérifier les erreurs côté client dans le nom d'utilisateur
        const usernameValue = this.state.username.value;
        const usernameValidation = this.validateUsername(usernameValue);

        if(usernameValidation.validateStatus === 'error') {
            this.setState({
                username: {
                    value: usernameValue,
                    ...usernameValidation
                }
            });
            return;
        }

        this.setState({
            username: {value: usernameValue, validateStatus: 'validating'}
        });

        checkUsernameAvailability(usernameValue)
        .then(response => {
            if(response.available) {
				this.champOK("username");
                this.setState({
                    username: {value: usernameValue, validateStatus: 'success'}
                });
            } else {
				this.afficherMessageErreurSousLeChamp("username", "Ce nom d'utilisateur est déjà pris");
                this.setState({
                    username: {value: usernameValue, validateStatus: 'error'}
                });
            }
        }).catch(error => {
            // le formulaire sera revérifié côté serveur
			this.champOK("username");
            this.setState({
                username: {value: usernameValue, validateStatus: 'success'}
            });
        });
    }

    validateEmailAvailability() {
        // Vérifiez d'abord les erreurs côté client
        const emailValue = this.state.email.value;
        const emailValidation = this.validateEmail(emailValue);

        if(emailValidation.validateStatus === 'error') {
            this.setState({
                email: {
                    value: emailValue,
                    ...emailValidation
                }
            });    
            return;
        }

        this.setState({
            email: {value: emailValue, validateStatus: 'validating'}
        });

        checkEmailAvailability(emailValue)
        .then(response => {
            if(response.available) {
				this.champOK("email");
                this.setState({email: {value: emailValue, validateStatus: 'success'}});
            } else {
				this.afficherMessageErreurSousLeChamp("email", "Cet e-mail est déjà enregistré");
                this.setState({email: {value: emailValue, validateStatus: 'error'}});
            }
        }).catch(error => {
            // le formulaire sera revérifié côté serveur
			this.champOK("email");
            this.setState({email: {value: emailValue, validateStatus: 'success'}});
        });
    }

    validatePassword = (password) => {
        if(password.length < PASSWORD_MIN_LENGTH) {
			this.afficherMessageErreurSousLeChamp("password", "Le mot de passe est trop court (MIN " + PASSWORD_MIN_LENGTH + " caractères.)");
            return {validateStatus: 'error'}
        } else if (password.length > PASSWORD_MAX_LENGTH) {
			this.afficherMessageErreurSousLeChamp("password", "Le mot de passe est trop long (MAX " + PASSWORD_MAX_LENGTH + " caractères.)");
            return {validationStatus: 'error'}
        } else {
			this.champOK("password");
            return {validateStatus: 'success'};            
        }
    }

}

export default InscriptionComponent;