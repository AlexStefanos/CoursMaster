/**
 *  TEMP LIST
 */
const FACTURE_LIST = [
    {id:1, montrant : 99.99, etat: "payee",  numFacure:  "L3AX_12345", dateEcheance: "04/04/2021"},
    {id:2, montrant : 100.00, etat: "payee", numFacure: "L3AX_12346",  dateEcheance: "04/02/2021"},
    {id:3, montrant : 99.99, etat: "echoué",  numFacure:  "L3AX_12347", dateEcheance: "04/01/2021"},
]

/**
 * Fonction qui affiche la liste des factures.
 *
 * @param farctures       la liste des factures
 * @return {JSX.Element}  table
 */
export default function FactureList ({farctures}) {
    farctures = FACTURE_LIST
    return (
        <table className="clients-list-container">
            <thead>
                <tr>
                    <th>MONTANT</th>
                    <th>ETAT</th>
                    <th>NUM FACTURE</th>
                    <th>DATE D'ECHEANCE</th>
                </tr>
            </thead>
            <tbody>
            {
                farctures.map((facture) => (
                    <tr key={facture.id}>
                        <td>{facture.montrant}</td>
                        <td> <span className={facture.etat==="payee" ?"td-etat-ok" :"td-etat-echec"}>{facture.etat}</span></td>
                        <td>{facture.numFacure}</td>
                        <td>{facture.dateEcheance}</td>
                    </tr>
                ))
            }
            </tbody>
        </table>
    )
}