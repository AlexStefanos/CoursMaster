# TD 4 : Convolution

Pendant ce TD les étudiants doivent analyser les différents filtres de convolution en comprenant le fonctionnementdu code donné avec le projet.

Les étudiants seront demandés de créer lesfiltres suivants:

* Moyenne
* Gaussien (Avec des noyaux de différentes tailles et différentes valeurs de sigma).
  * Pour calculer les valeurs des noyaux les éléves pourront utiliser des outils tels que http://dev.theomader.com/gaussian-kernel-calculator/
* Prewitt, Sobel et Laplacien: Détection de contours dans les images