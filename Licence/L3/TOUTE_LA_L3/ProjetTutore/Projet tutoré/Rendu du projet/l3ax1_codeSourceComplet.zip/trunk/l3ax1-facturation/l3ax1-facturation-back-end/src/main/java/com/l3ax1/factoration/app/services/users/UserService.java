package com.l3ax1.factoration.app.services.users;

import com.l3ax1.factoration.app.exception.BadRequestException;
import com.l3ax1.factoration.app.Models.users.User;
import com.l3ax1.factoration.app.payload.PagedResponse;
import com.l3ax1.factoration.app.repository.users.UserRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private static final Logger logger = LoggerFactory.getLogger(UserRepository.class);

    public PagedResponse<User> getAllUsers(int page, int size) {
        validatePageNumberAndSize(page, size);

        // Récupérer les utilisateurs
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "id");
        Page<User> users = userRepository.findAll(pageable);

        if(users.getNumberOfElements() == 0) {
            return new PagedResponse<User>(Collections.emptyList(), users.getNumber(),
            		users.getSize(), users.getTotalElements(), users.getTotalPages(), users.isLast());
        }

        List<User> usersList = users.getContent();

        return new PagedResponse<>(usersList, users.getNumber(),
        		users.getSize(), users.getTotalElements(), users.getTotalPages(), users.isLast());
    }

    private void validatePageNumberAndSize(int page, int size) {
        if(page < 0) {
            throw new BadRequestException("Page number cannot be less than zero.");
        }

        if(size > PageConstants.MAX_PAGE_SIZE) {
            throw new BadRequestException("Page size must not be greater than " + PageConstants.MAX_PAGE_SIZE);
        }
    }
}