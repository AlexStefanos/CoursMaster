/*
 * UserRepository.java
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1 et 2.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 */
package com.l3ax1.factoration.app.repository.users;

import com.l3ax1.factoration.app.Models.users.User; // Une Entité (JPA) qui représente les utilisateurs dans la base de données.
import org.springframework.data.jpa.repository.JpaRepository; // Interface
import org.springframework.stereotype.Repository; // Indique que la classe annotée est un Repository
import java.util.List; // Une collection ordonnée
import java.util.Optional; // Un objet conteneur qui peut ou non contenir une valeur non nulle

/**
 *  Repository pour conserver le modèle User dans la base de données et le récupérer.
 *  Repository : défini comme « un mécanisme d'encapsulation du comportement de stockage, d'extraction et de recherche qui émule une collection d'objets ».
 *  
 * {@link Repository} : Indique que la classe annotée est un Repository.
  
 * @version 1.0
 * @author Leonard NAMOLARU
 */
@Repository // Indique que la classe annotée est un Repository.
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    Optional<User> findByUsernameOrEmail(String username, String email);

    List<User> findByIdIn(List<Long> userIds);

    Optional<User> findByUsername(String username);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);
}