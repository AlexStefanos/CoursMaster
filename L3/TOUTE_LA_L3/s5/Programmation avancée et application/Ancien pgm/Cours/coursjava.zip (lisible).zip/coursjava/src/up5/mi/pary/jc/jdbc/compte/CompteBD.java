package up5.mi.pary.jc.jdbc.compte;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CompteBD {

	/** le titulaire de ce compte*/
	private String nomTitulaire;

	/** précise les informations de connexion à la base et crée si besoin les tables */
	public  static void creerLesTables( )throws SQLException{

		try (Connection connection = BD.getConnection();){

			Statement statement = connection.createStatement( );
			//création des 3 tables,si elles existaient déjà, une SQLException sera alors lancée
			// par jdbc. On attrape l'erreur dans le bloc catch.
			statement.executeUpdate("CREATE TABLE decouvert " +
					"(nom VARCHAR(25) PRIMARY KEY,montant INTEGER not NULL)");

			statement.executeUpdate("CREATE TABLE solde " +
					"(nom VARCHAR(25) PRIMARY KEY,montant INTEGER not NULL)");

			statement.executeUpdate("CREATE TABLE operation " +
					"(nom VARCHAR(25),montant INTEGER not NULL)");
			
		}
	}

	public static boolean isTablesACreer(){
		try (Connection connection = BD.getConnection();){

			Statement statement = connection.createStatement( );
			statement.executeQuery("SELECT * from solde");
		}
		catch (SQLException exp) {return true;}
		return false;
	}
	/** rend le compte dont le titulaire est nommé 'nomTitulaire
      Si create == true, crée le compte en base s'il n'existe pas 
	 * @throws CompteInconnuException */
	public static CompteBD getCompte(String titulaire,boolean create) throws SQLException, CompteInconnuException{
		if (isCompteExisteDansLaBase(titulaire) || create) 
			// creation de l'instance correspondante
			return  new CompteBD(titulaire);
		else throw new CompteInconnuException("Compte inexistant: "+titulaire);
	}

	/** creation d'un Compte avec initialisation éventuelle de la BD */
	private  CompteBD(String nomTitulaire)throws  SQLException{
		this.nomTitulaire=nomTitulaire;

		if (! isCompteExisteDansLaBase(nomTitulaire)){
			try (Connection connection = BD.getConnection()){
				Statement statement = connection.createStatement( );
				// L'initialisation consiste à mettre le solde et le découvert à zéro.
				statement.executeUpdate("INSERT INTO solde (nom,montant) VALUES ('" +
						nomTitulaire + "',0)");
				statement.executeUpdate("INSERT INTO decouvert (nom,montant) VALUES ('" +
						nomTitulaire + "',0)");
			}
		}
	}
	/** teste si le compte correspond à 'nomTitulaire' existe en base */
	private static boolean isCompteExisteDansLaBase(String nomTitulaire)throws  SQLException{
		boolean existe=false;
		try (Connection connection = BD.getConnection();){
			PreparedStatement statement = connection.prepareStatement(
					"SELECT montant FROM solde WHERE nom=?");
			statement.setString(1,nomTitulaire);
			// le critère d'existence est : y a-t-il un solde pour ce compte ?
			ResultSet rs= statement.executeQuery( );
			existe= rs.next( );
		}
		return existe;
	}

	/** enregistre une opération de 'montant' Euros sur ce compte
	 * @param montant le montant en euros de l'opération */
	public void addOperation(double montant)throws SQLException{
		try (Connection connection = BD.getConnection();){
			PreparedStatement statement = connection.prepareStatement(
					"INSERT INTO  operation(nom,montant) VALUES (?,?)"); 	statement.setString(1, this.nomTitulaire);
					statement.setInt(2,(int)montant*100);
					statement.executeUpdate();
		}
		this.setSolde(this.getSolde( )+montant);
	}


	/** modifie le découvert autorisé sur ce compte   */
	public void setDecouvertAutorise(double decouvertAutorise)throws SQLException{
		try (Connection connection = BD.getConnection();){
			PreparedStatement statement = connection.prepareStatement(
					"UPDATE decouvert SET montant=?  WHERE nom=?");
			statement.setInt(1,(int)decouvertAutorise*100);
			statement.setString(2, this.nomTitulaire);
			statement.executeUpdate();
		}
	}

	/** modifie le solde de ce compte   */
	private void setSolde(double montant)throws SQLException{
		try (Connection connection = BD.getConnection();){
			PreparedStatement statement = connection.prepareStatement(
					"UPDATE solde SET montant=?  WHERE nom=?");
			statement.setInt(1,(int)montant*100);
			statement.setString(2, this.nomTitulaire);
			statement.executeUpdate();
		}
	}

	/** retourne le solde de ce compte
	 *  @return le solde de ce compte */
	public double getSolde( ) throws  SQLException{
		try (Connection connection = BD.getConnection();){

			PreparedStatement statement = connection.prepareStatement(
					"SELECT montant FROM solde WHERE nom=?");
			statement.setString(1, this.nomTitulaire);
			ResultSet rs = statement.executeQuery( );
			if (rs.next( ))
				return  rs.getInt(1)/100.0;
			else throw new RuntimeException("Compte inexistant: "+this.nomTitulaire);
		}
	}

	/** retourne le decouvert autorisé sur ce compte
	 *  @return le decouvert autorisé sur ce compte */
	public double getDecouvertAutorise( ) throws  SQLException{
		try (Connection connection = BD.getConnection();){

			PreparedStatement statement = connection.prepareStatement(
					"SELECT montant FROM decouvert WHERE nom=?");
			statement.setString(1, this.nomTitulaire);
			ResultSet rs = statement.executeQuery( );
			if (rs.next( ))
				return  rs.getInt(1)/100.0;
			else throw new RuntimeException("Compte inexistant: "+this.nomTitulaire);
		}
	}

	/** retourne l'historique des opérations effectuées sur ce compte
	 *  @return l'historique des opérations effectuées sur ce compte
	 */
	public String getHistorique( ) throws  SQLException{
		List<Double> histo = new ArrayList<Double>( );
		try (Connection connection = BD.getConnection();){
			PreparedStatement statement = connection.prepareStatement(
					"SELECT montant FROM operation WHERE nom =?" );
			statement.setString(1, this.nomTitulaire);
			ResultSet rs = statement.executeQuery( );
			while (rs.next( )) {
				double montant=rs.getInt(1)/100.0;
				histo.add(new Double(montant));
			} }
		return(histo.toString( ));
	}

	/** teste si le solde de ce compte est insuffisant */
	public boolean isSoldeInsuffisant( ) throws SQLException {
		return this.getSolde( ) <   - this.getDecouvertAutorise();
	}

	public String getNomTitulaire( ) {return this.nomTitulaire;}

	public String toString( ){
		return("Compte de "+this.nomTitulaire);
	}

}
