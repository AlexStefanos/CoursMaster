package com.l3ax1.factoration.app.services.factures;

import com.l3ax1.factoration.app.Models.clients.Client;
import com.l3ax1.factoration.app.Models.factures.Facture;
import com.l3ax1.factoration.app.controllers.factures.FactureController;
import com.l3ax1.factoration.app.excptions.ResourceNotFoundException;
import com.l3ax1.factoration.app.repository.factures.FactureRepository;
import com.l3ax1.factoration.app.services.clients.ClientService;
import com.l3ax1.factoration.app.utils.EnvoiMailPdf;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 * <h1>FactureServices: class</h1>
 * <hr/>
 * <p>
 * cette classe applique des traitements
 * dictés par les règles fonctionnelles de l’application. Et également un pont entre
 * {@link FactureController}  et {@link FactureRepository}.
 * Intérêt que chaque méthode a pour unique objectif d’appeler une méthode de
 * {@link FactureRepository}
 * <br/>
 * <p>
 * {@link Service}  tout comme l’annotation @Repository, c’est une spécialisation
 * de @Component. Son rôle est donc le même, mais son nom a une valeur sémantique
 * pour ceux qui lisent le code.
 * <p>
 * <hr/>
 *
 * @see FactureRepository
 * @see Service
 * <p>
 * * @author Salah Eddine Atia
 * * @version 1.0
 */

@Data
@Service
public class FactureService {

    private long NUMERO_FACTURE = 0L;
    public final static String PREFIXE = "L3AX1_";
    @Autowired
    private FactureRepository factureRepository;
    @Autowired
    private ClientService clientService;


    /**
     * <h2>Ajouter une facture à la base de données</h2>
     *<hr/>
     * <p>Cette méthode génére une facture et lui attribu un numéro de facture unique ainsi de l'envoyer par mail en utilisant javaMail</p>
     * @param facture la facture.
     * @param idClient le client a qui appartient la facture
     * @return facture apres la sauvgarde.
     */
    public Facture creerFacture(Facture facture, Long idClient) {
        System.out.println(idClient);
        Facture facturetmp = factureRepository.save(facture);
        if(idClient != -1){
            Client client = this.clientService.getClientById(idClient).orElseThrow(() -> new ResourceNotFoundException("Le client n'existe pas"));
            facturetmp.setClient(client);
            facturetmp.setNumeroFacture(String.valueOf(PREFIXE + facturetmp.getClient().getClientActuel().getNom()+"_2021_000" + facturetmp.getId()));
        }
        Facture fact = factureRepository.save(facturetmp);

        EnvoiMailPdf envoiMailPdf =new EnvoiMailPdf();
        envoiMailPdf.envoyer(facture);

        return fact;
    }
    /**
     * <h2>Récupérer la liste des factures de la base de données.</h2>
     *<hr/>
     * @return la liste des factures.
     */
    public Iterable<Facture> getFactures () {
        return this.factureRepository.findAll();
    }
    /**
     * <h2>Récupérer une facture de la base de données avec son Id</h2>
     * <hr/>
     * <p>
     * see : table factures
     *
     * @param id id de facture.
     * @return facture.
     */
    public Facture getFactureByNumeroFacture(Long id) {
        return factureRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("La facture n'existe pas"));
    }
}
