package up5.mi.pary.jt.term;

import up5.mi.pary.term.Terminal;

public class TestPersonnalisationTerminal {
	
	public static void main(String [] args) { 

	Terminal term = new Terminal("calcul du carré de la somme",300,300);

	term.setBackground(java.awt.Color.BLUE);
	term.setTextAreaColor(new java.awt.Color(200,200,255));
	term.setButtonTextColor(new java.awt.Color(255,100,100));
	term.setButtonLabel("Valider votre saisie ici");
	term.setTextAreaFontSize(20);

	int a = term.readInt("donner un entier:") ;

	int b= term.readInt("donner un autre entier:") ;

	term.println("le carré de la somme de "+a+
	                               " et de "+b+" vaut "+(a+b)*(a+b));
	term.end();
	}

}
