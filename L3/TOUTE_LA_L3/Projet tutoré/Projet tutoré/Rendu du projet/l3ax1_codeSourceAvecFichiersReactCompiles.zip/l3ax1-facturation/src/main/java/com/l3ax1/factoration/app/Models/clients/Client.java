package com.l3ax1.factoration.app.Models.clients;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.l3ax1.factoration.app.Models.contrat.Contrat;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * <h1>Client : abstract class</h1>
 * <hr/>
 * Entity (JPA)  qui  représente  les  clients  dans la  base  de  données.
 * la classe est abstraite a deux classes filles {@link Morale} & {@link Physique}.
 * <br/><br/>
 * <p>
 * {@link Data} est une annotation  Lombok. Nul  besoin d’ajouter les  getters  et
 * les setters.  La  librairie  Lombok  s’en  charge pour  nous. Très  utile  pour
 * alléger le code.
 * <br/>
 * {@link Entity} est une annotation qui indique que  la  classe correspond  à  une
 * table de la base de données.
 * <br/>
 * {@link Inheritance} pour utiliser des requêtes polymorphes pour récupérer toutes
 * les entités de sous-classe lors d'une requête pour une super-classe.
 * <br/>
 * {@link DiscriminatorColumn} Spécifie la colonne discriminante pour les stratégies
 * de mappage d'héritage SINGLE_TABLE et JOINED.
 * <br/>
 * {@link Table} indique le nom de la table associée,  attribut <strong>name</strong>
 * pour  indiquer le nom de la table dans la base de données.
 * <br/><br/>
 * <p>
 * Annotés avec {@link Column} pour faire le lien avec le nom du champ de la table.
 * <p>
 * <hr/><br/>
 *
 * @author lounis BOULDJA
 * @version 1.0
 * @see <a href="https://docs.oracle.com/javaee/7/api/index.html">
 * javax.persistence javadoc</a>
 * @see Morale
 * @see Physique
 */
@Data
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
@Table(name = "clients")
public abstract class Client {

    /**
     * L’attribut id correspond à la clé primaire de la table, et est donc annoté @Id.
     * D’autre part, comme l’id est auto-incrémenté, j’ai ajouté l’annotation
     * <strong>@GeneratedValue(strategy = GenerationType.IDENTITY).<strong/>
     *
     * @see Id
     * @see GeneratedValue
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Recuperer les client de la l'archive.
     *
     * @see ClientArchive
     * @see OneToOne OneToOne annotation
     */
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "client")
    private ClientArchive clientActuel;

    /**
     * La liste des contrats.
     *
     * @see Contrat
     */
    @OneToMany(mappedBy = "client")
    @JsonIgnore
    private List<Contrat> contrats;

    @Column(name = "client_adresse")
    private String adresse;

    @Column(name = "client_adresse_facturation")
    private String adresseFacturation;

    @Column(name = "client_premiere_achat")
    private Date premierAchat = new Date();

    @Column(name = "client_num_tva")
    private String numeroTva;

    @Column(name = "client_tva_intracom")
    private String tvaIntracom;

    @Column(name = "client_solde")
    private double solde;

    @Column(name = "client_total")
    private double total;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client client = (Client) o;
        return Double.compare(client.solde, solde) == 0 && Double.compare(client.total, total) == 0
                && Objects.equals(clientActuel, client.clientActuel)
                && Objects.equals(adresse, client.adresse)
                && Objects.equals(adresseFacturation, client.adresseFacturation)
                && Objects.equals(numeroTva, client.numeroTva)
                && Objects.equals(tvaIntracom, client.tvaIntracom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(clientActuel, adresse, adresseFacturation, numeroTva, tvaIntracom, solde, total);
    }

    /**
     * <h2>Copier les details d'un client à un autre</h2>
     *
     * @param client client
     */
    public void copy(Client client) {
        this.clientActuel.setNom(client.clientActuel.getNom());
        this.adresse = client.adresse;
        this.adresseFacturation = client.adresseFacturation;
        this.numeroTva = client.numeroTva;
    }
}
