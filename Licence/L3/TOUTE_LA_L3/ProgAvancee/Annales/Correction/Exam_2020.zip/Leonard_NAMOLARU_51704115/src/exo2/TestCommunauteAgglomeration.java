package exo2;

import java.io.IOException;

public class TestCommunauteAgglomeration {

	public static void main(String[] args) {
		CommunauteAgglomeration ca = new CommunauteAgglomeration();
		String[] nomsVilles = { "Paris", "Marseille", "Lille", "Rennes", "Strasbourg" };

		for (String nomVille : nomsVilles) {
			ca.ajouteVille(nomVille);
		}

		ca.ajouteRoute("Paris", "Marseille");
		ca.ajouteRoute("Paris", "Lille");
		ca.ajouteRoute("Paris", "Rennes");
		ca.ajouteRoute("Paris", "Strasbourg");

		ca.retireEcole("Paris");

		try {
			ca.sauvegarder("sauvegarde_ca.txt");
		} catch (IOException e) {
			System.err.println( e.getMessage() );
		}

		ca.retireEcole("Lille");
		if (ca.accessibilite("Lille")) {
			System.out.println("Lille a acces a une ecole.");
		} else {
			System.out.println("Lille n'a pas acces a une ecole.");
		}

		if (ca.accessibilite()) {
			System.out.println("La contrainte d'accessibilite est satisfaite.");
		} else {
			System.out.println("La contrainte d'accessibilite n'est pas satisfaite.");
		}

		ca.ajouteEcole("Lille");
		if (ca.accessibilite("Lille")) {
			System.out.println("Lille a acces a une ecole.");
		} else {
			System.out.println("Lille n'a pas acces a une ecole.");
		}

		if (ca.accessibilite()) {
			System.out.println("La contrainte d'accessibilite est satisfaite.");
		} else {
			System.out.println("La contrainte d'accessibilite n'est pas satisfaite.");
		}

	}
}
