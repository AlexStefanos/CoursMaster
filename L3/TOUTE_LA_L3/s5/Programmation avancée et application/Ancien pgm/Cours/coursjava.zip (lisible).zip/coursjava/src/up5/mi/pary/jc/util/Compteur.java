package up5.mi.pary.jc.util;

public class Compteur {

	private int value;

	public Compteur( ) {
		this.value=0;
	}

	public void incrementer(int incr){
		this.value+=incr;
	}

	public int getValue( ){
		return this.value;
	}

}
