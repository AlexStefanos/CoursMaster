package com.l3ax1.factoration.app.controllers.produits;

import com.l3ax1.factoration.app.Models.produits.*;
import com.l3ax1.factoration.app.services.produits.ProduitService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <h1>ClientController : class</h1>
 * <hr/>
 * Client Controller permet de communiquer avec front end react. Pour accéder
 * à notre API on utilise des endpoints associé à une URL,  Lorsqu'on appelle
 * cette URL, on reçoit une réponse, et cet échange se fait en HTTP. et grâce
 * à Spring-Boot-starter-web nous  fournit  tout  le nécessaire pour créer un
 * endpoint.
 * <br/><br/>
 * <p>
 * {@link RestController} : Comme @Component, elle permet d’indiquer à Spring
 * que cette classe est un bean, et aussi   indiqué  à  Spring  d’insérer  le
 * retour  de  la méthode  au  format  JSON  dans le corps de la réponse HTTP.
 * Grâce à  ça , les applications qui  vont communiquer avec l’API accéderont
 * au résultat de leur requête en parsant la réponse HTTP. <br/>
 * <p>
 * {@link CrossOrigin} : Annotation  pour  autoriser  les  requêtes d'origine
 * croisée  sur  des  classes  de  gestionnaire  et  /  ou  des  méthodes  de
 * gestionnaire spécifiques. Traité si un HandlerMapping approprié est configuré.
 * <p>
 * <hr/>
 *
 * @author SAGHROUN Amos
 * @version 1.0
 * @see ClientService
 * @see RestController
 * @see CrossOrigin
 */
@RestController
@CrossOrigin(origins = "*")     // localhost:3000
public class ProduitController {

    /**
     * Cela permettra d’appeler les méthodes pour communiquer avec la base de données.
     *
     * @see ClientService
     **/
    @Autowired
    ProduitService produitService;


    /**
     * {@link GetMapping} Cela signifie que les requêtes  HTTP de  type  GET à l’URL /clients
     * exécuteront le code de cette méthode. Et ce code est tout simple : il s’agit d’appeler
     * la méthode  getClients()  du  {@link ClientService},  ce  dernier appellera la méthode
     * findAll()  du  {@link com.l3ax1.factoration.app.repository.clients.ClientRepository}
     * et nous obtiendrons ainsi tous les clients enregistrés  en  base de données.
     * recuperer la liste de client de la base de données.
     *
     * @return <strong>la liste des clients enregistrés  en  base de données.<strong/>
     * @see GetMapping
     */
    @GetMapping("/produits")
    public Iterable<Produit> getProduit() {
        return produitService.getProduit();
    }

    @PostMapping("/produits/ajouter")
    public Produit createProduit (@RequestBody  Produit produit) {
        return this.produitService.createProduit(produit);
    }

    
}

