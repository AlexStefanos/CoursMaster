package up5.mi.pary.jc.mvc.chat.common;


public interface ChatListener {

    /** une nouveau message a été ajouté dans le chat */
    void messageAjoute(Chat chat,Message message);
    
}
