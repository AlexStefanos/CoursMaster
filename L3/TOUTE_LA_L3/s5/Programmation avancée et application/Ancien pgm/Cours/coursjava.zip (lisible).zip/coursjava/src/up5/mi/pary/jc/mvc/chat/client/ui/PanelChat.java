package up5.mi.pary.jc.mvc.chat.client.ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import up5.mi.pary.jc.mvc.chat.common.Chat;


public class PanelChat extends PanelVisuChat {

	private TextField messageAEnvoyer=new TextField();

	public PanelChat(Chat chat){
		super(chat);
		this.messageAEnvoyer.setPrefColumnCount(20);
		BorderPane panelEnvoi=new BorderPane();
		panelEnvoi.setCenter(this.messageAEnvoyer);
		Button buttonEnvoi=new Button("Envoi"); 

		panelEnvoi.setRight(buttonEnvoi);
		this.setBottom(panelEnvoi);

		EventHandler<ActionEvent> listener =e->fireMessageAEnvoyer( );
		buttonEnvoi.setOnAction(listener);
		this.messageAEnvoyer.setOnAction(listener);
		
	}

	private PanelChatHandler handler=null;

	public void setHandler(PanelChatHandler handler){
		this.handler=handler;
	}


	private void fireMessageAEnvoyer( ) {
		if (handler!=null)
			handler.messageAEnvoyer(this.messageAEnvoyer.getText( ));
		this.messageAEnvoyer.setText("");
	}

}