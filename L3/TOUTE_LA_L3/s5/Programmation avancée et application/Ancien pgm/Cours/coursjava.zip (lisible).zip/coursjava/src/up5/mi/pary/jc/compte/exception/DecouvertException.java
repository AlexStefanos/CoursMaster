package up5.mi.pary.jc.compte.exception;

public class DecouvertException extends CompteException {

		 public DecouvertException(double montant,CompteE c){
			super("Depassement du d�couvert autorise : operation impossible\n"+
				   "montant: "+montant+" solde:"+c.getSolde()+
				   " decouvert autorise :"+c.getDecouvertAutorise());
	}

}
