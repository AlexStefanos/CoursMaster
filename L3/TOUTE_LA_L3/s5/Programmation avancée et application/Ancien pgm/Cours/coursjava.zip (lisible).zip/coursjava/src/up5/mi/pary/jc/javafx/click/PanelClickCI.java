package up5.mi.pary.jc.javafx.click;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import up5.mi.pary.jc.util.Compteur;

public class PanelClickCI extends BorderPane{

	private Compteur compteur;
	private Label label;

	public PanelClickCI(Compteur compteur){
		this.compteur=compteur;
		Button button = new Button("OK");

		this.label =new Label("--> 0");
		
		
		button.setOnAction(new EcouteurClickI());

		this.setBottom(button);
		this.setCenter(label);

	}

	class EcouteurClickI implements EventHandler<ActionEvent> {
		@Override
		public void handle(ActionEvent event) {
			PanelClickCI.this.compteur.incrementer(1);
			PanelClickCI.this.label.setText("--> "+PanelClickCI.this.compteur.getValue());
		}
	}
}
