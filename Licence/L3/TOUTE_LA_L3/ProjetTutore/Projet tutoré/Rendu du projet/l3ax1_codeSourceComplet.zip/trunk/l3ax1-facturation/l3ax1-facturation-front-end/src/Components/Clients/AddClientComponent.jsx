import React, {useState} from 'react'
import {useForm} from "react-hook-form";
import ClientService from "../../Services/ClientService";
import {Morale, Physique} from "./StatutClientComponent";
import clientLogo from "../../Images/account.png"
import Associate from "../Contrats/Associate";
import img from "../../Images/contract.png";
import minusLogo from "../../Images/minus.png";
import plusLogo from "../../Images/plus.png";

/**
 * Fonction (hooks) qui'ajouter un Client
 *
 * @param exitToClient   fonction pour fermer le popup
 * @return {JSX.Element} popup pour ajouter le client
 */
export default function AddClientComponent({exitToClient}) {

    const [statut, setStatut] = useState('physique')
    const [contrat, setContrat] = useState(null)
    let [visible, setVisible] = useState(false);

    const {register, handleSubmit, errors} = useForm({
        defaultValues: {
            statut: 'physique'
        }
    });

    const addContratToClient = (data) => {
        setVisible(!visible)
        setContrat(data)
    }
    /**
     * ajouter le client dans la liste et fermé le popup
     * @param data les données saisies
     */
    const onSubmit = (data) => {
        data.contrats = [contrat]
        if (data.statut === 'physique') {
            const clt = ClientService.createClientFromData(data)
            if (contrat == null) {
                ClientService.createPhysiqueClient(clt).then(
                    exitToClient()
                )
            } else {
                ClientService.createPhysiqueClientWithContrat(clt, contrat.id).then(
                    exitToClient()
                )
            }
        } else {
            const clt = ClientService.createClientFromData(data)
            if (contrat == null) {
                ClientService.createMoraleClient(clt).then(
                    exitToClient()
                )
            } else {
                ClientService.createMoraleClientWithContrat(clt, contrat.id).then(
                    exitToClient()
                )
            }
        }
    }

    /**
     * recuperer la valuer de statut
     * @param e event
     */
    const changeStatut = (e) => setStatut(e.target.value)

    /**
     * composante
     * @return {JSX.Element} Client Morale si statut=morale.
     */
    const getStatut = () => (statut === 'morale')
        ? <Morale register={register} errors={errors}/>
        : <Physique register={register} errors={errors}/>

    function showAddContrat() {
        if (contrat != null)
            setContrat(null)
        setVisible(!visible)
    }

    return (
        <div className="popup-add">
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="popup-container">
                    <h1><img src={clientLogo} alt="client"/>Ajouter un client</h1>
                    <div className="popup-info">
                        <h3>Statut</h3>
                        <div className="statut">
                            <label>
                                <input type="radio" name="statut" value="physique" onClick={changeStatut}
                                       ref={register}/>
                                Physique
                            </label>
                            <label>
                                <input type="radio" name="statut" value="morale" onClick={changeStatut} ref={register}/>
                                Morale
                            </label>
                        </div>
                        {
                            getStatut()
                        }

                        <h3>information de facturation</h3>
                        <div className='info'>
                            <label>Adresse de facturation</label>
                            <input type='text' name="pays" placeholder="Pays" ref={register({required: true})}/>
                            <input type='text' name="adresse" placeholder="Adresse" ref={register({required: true})}/>
                            <input type='text' name="codePostal" placeholder="Code postal"
                                   ref={register({required: true})}/>
                            <input type='text' name="ville" placeholder="Ville" ref={register({required: true})}/>
                        </div>

                        <h3>information de livraison</h3>
                        <div className="info">
                            <label>préfixe de la facture</label>
                            <input type='text' name="prefixeFacture" ref={register({required: true})}/>
                        </div>

                        <h3>informations TVA</h3>
                        <div className="info info-tva">
                            <div>
                                <label>Localisation</label>
                                <input type='text' name="localisation" ref={register({required: true})}/>
                            </div>
                            <div>
                                <label>N° TVA intra</label>
                                <input type='text' name="numeroTva" ref={register({required: true})}/>
                            </div>
                        </div>

                        <div onClick={showAddContrat} style={{cursor: "pointer"}}>
                            <img className="plus-logo" src={(visible) ? minusLogo : plusLogo} alt="ajouter"/>
                            {(contrat == null) ? "Ajouter un Contrat" : "Supprimer le Contrat (" + contrat.nom + ")"}
                        </div>
                        {(visible) && <Associate type="contrat" addContrat={addContratToClient}/>}

                    </div>
                    <div className="popup-foot">
                        <button className="btn-cancel" type="button" onClick={exitToClient}>Annuler</button>
                        <button className="btn-add" type="submit">Ajouter le client</button>
                    </div>
                </div>
            </form>
        </div>

    )
}