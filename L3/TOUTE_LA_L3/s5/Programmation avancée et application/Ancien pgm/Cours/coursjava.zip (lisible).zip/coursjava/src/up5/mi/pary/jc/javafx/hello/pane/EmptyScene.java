package up5.mi.pary.jc.javafx.hello.pane;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class EmptyScene extends Application {

	@Override
	public void start(Stage stage) {

		stage.setTitle("Hello World");

		Pane root = new Pane();
		
		Button button1 = new Button("Un premier bouton");
		Button button2 = new Button("Un deuxième bouton");
		button1.relocate(150, 100);
		button2.setPrefSize(200, 100);
		root.getChildren().add(button1);
		root.getChildren().add(button2);
		
		
		Scene scene = new Scene(root,300, 200);

		stage.setScene(scene);
		stage.show();
	}


	public static void main(String[] args) {
		launch(args);
	}

}
