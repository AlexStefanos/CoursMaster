package com.l3ax1.factoration.app.clients;



import com.l3ax1.factoration.app.Models.clients.*;
import com.l3ax1.factoration.app.services.clients.ClientService;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import java.util.List;


/**
 * <h1>ClientServiceControllerTest : class TEST </h1>
 *
 * <hr/>
 *
 * Objectif de cette class est de tester le service {@link ClientService}
 *
 * {@link SpringBootTest} @SpringBootTest est une annotation fournie par Spring Boot. Elle permet
 * lors de l’exécution des tests d’initialiser le contexte Spring. Les beans de notre application
 * peuvent alors être utilisés.
 * <br/>
 * {@link AutoConfigureMockMvc } Annotation qui peut être appliquée  à  une  classe  de test pour
 * activer et configurer la configuration automatique de MockMvc.
 *
 *<hr/>
 *
 * @version 1.0
 * @author lounis BOULDJA
 */
@SpringBootTest
@AutoConfigureMockMvc
public class ClientServiceTest {

    /*servece à tester*/
    @Autowired
    ClientService clientService;


    /**
     * <h2>Tester la methode getClient de {@link ClientService}</h2>
     *
     * @see Test
     */
   @Test
    public void getClientsTest() {

        /*clent un client (voir la base de données)*/
        ClientArchive clientArchive = new ClientArchive();
        Physique client = new Physique();

        /*remlire les champs à aprtir de la base de données*/
        clientArchive.setNom("TEST");
        client.setClientActuel(clientArchive);
        clientArchive.setClient(client);
        client.setAdresse("TEST, TEST, TEST, TEST");
        client.setSolde(0);
        client.setTotal(0);
        client.setDescription("TEST");
        client.setEmail("TEST@test.com");

        /*recuprer la liste des clients*/
        List<Client> clients = (List<Client>) clientService.getClients();
        assertThat(clients.size()).isEqualTo(5);
        assertThat(clients.get(0)).isEqualTo(client);

    }
}
