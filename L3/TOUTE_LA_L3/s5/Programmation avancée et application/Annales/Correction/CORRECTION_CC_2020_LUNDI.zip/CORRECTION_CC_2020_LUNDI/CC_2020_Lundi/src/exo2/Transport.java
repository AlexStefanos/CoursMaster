package exo2;

public enum Transport {
	AVION, BUS;
}
