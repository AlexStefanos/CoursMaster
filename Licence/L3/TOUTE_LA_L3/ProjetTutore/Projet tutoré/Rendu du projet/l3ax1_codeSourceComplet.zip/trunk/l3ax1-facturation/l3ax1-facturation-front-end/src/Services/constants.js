 /* constants.js
 * Différents paramètres tels que le nombre de caractères autorisés pour un champ d'un formulaire, le nombre d'utilisateurs à afficher à la fois sur la page avec une liste de tous les utilisateurs, etc.
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.
 *
 * Travail_effectué : Implémentation du code (source 1) dans le projet en l'adaptant aux besoins de notre projet + ajout d'explications, certaines des explications proviennent du tutoriel (source 1).
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 */
 
export const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080/api';
export const ACCESS_TOKEN = 'accessToken';

// le nombre d'utilisateurs à afficher à la fois sur la page avec une liste de tous les utilisateurs
export const USERS_LIST_SIZE = 5;

// Longueur autorisée pour le champ Nom et prenom dans le formulaire d'inscription
export const NAME_MIN_LENGTH = 4;
export const NAME_MAX_LENGTH = 40;

// Longueur autorisée pour le champ Nom d'utilisateur dans le formulaire d'inscription
export const USERNAME_MIN_LENGTH = 3;
export const USERNAME_MAX_LENGTH = 15;

// Longueur autorisée pour le champ E-mail dans le formulaire d'inscription
export const EMAIL_MAX_LENGTH = 40; 

// Longueur autorisée pour le champ Mot de passe dans le formulaire d'inscription
export const PASSWORD_MIN_LENGTH = 6;
export const PASSWORD_MAX_LENGTH = 20;
