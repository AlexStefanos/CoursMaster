package up5.mi.pary.jc.javafx.click;

import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import up5.mi.pary.jc.util.Compteur;

public class PanelClickBR extends BorderPane{


	public PanelClickBR(Compteur compteur){
		
		Label label=new Label("--> 0");;
		
		RadioButton rb1=new RadioButton("1");
		RadioButton rb10=new RadioButton("10");
		RadioButton rb100=new RadioButton("100");
		
		ToggleGroup toggleGroup = new ToggleGroup();
		rb1.setToggleGroup(toggleGroup);
		rb1.setSelected(true);
		rb10.setToggleGroup(toggleGroup);
		rb100.setToggleGroup(toggleGroup);
		
		FlowPane pane = new FlowPane();
		pane.getChildren().addAll(rb1,rb10,rb100);
		
		Button button = new Button("OK");
		
		button.setOnAction(
			(event) -> {
				RadioButton radio= (RadioButton)toggleGroup.getSelectedToggle();
				compteur.incrementer(Integer.parseInt(radio.getText()));
				label.setText("--> "+compteur.getValue());
			}
		);

		this.setTop(button);
		this.setCenter(label);
		this.setBottom(pane);

	}
}
