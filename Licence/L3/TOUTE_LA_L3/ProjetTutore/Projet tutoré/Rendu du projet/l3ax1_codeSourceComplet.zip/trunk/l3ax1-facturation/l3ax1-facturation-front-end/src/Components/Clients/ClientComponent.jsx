import React, {Component} from 'react';
import './ClientStyle.css'
import ClientService from "../../Services/ClientService";
import AddClientComponent from "./AddClientComponent";
import {TableClientComponent} from "./TableClientComponent";
import {Router, Switch, Route} from "react-router-dom";
import BarreRecherche from "../BarreRecherche/BarreRecherche";
import etrepriseLogo from "../../Images/enterprise.png"
import clientLogo from "../../Images/customer.png"


/**
 * Composante Client : représente la liste des clients
 *
 * @version 1.2
 */
class ClientComponent extends Component {

    /**
     * Constructeur
     * @param props les attributs
     */
    constructor(props) {
        super(props);
        /* etats */
        this.state = {
            /*Liste des clients.*/
            clientList: [],

            /* Afficher les clinet physiques/morales*/
            physique: true,

            /* Pour la Rechrche d'un Client*/
            filter: '',

            /*Afficher popup pour ajouter un client */
            showAddPopUp: false,
        }
        /*Bind*/
        this.showAddClient = this.showAddClient.bind(this)
        this.changeStatut = this.changeStatut.bind(this)
        this.loadClients = this.loadClients.bind(this)
        this.goToAddClient = this.goToAddClient.bind(this)
        this.chageFilter = this.chageFilter.bind(this)
    }

    /**
     * charger les client  de la base de données.
     **/
    loadClients() {
        ClientService.getCleints().then((res) => {
            this.setState({clientList: res.data})
        })
    }

    /**
     * Charger la liste des client. de l'api
     **/
    componentDidMount() {
        this.loadClients()
    }

    /**
     * Afficher les 100 meilleurs clients.
     * @param e event
     */
    changeStatut(e) {
        console.log(e.target)
        this.setState({
            /*deplacer la ligne*/
            lineLeft: "".concat(e.target.offsetLeft, "px"),
            lineWidth: "".concat(e.target.offsetWidth, "px"),
            physique: (e.target.value === "physique" || e.target.alt === "physique" || e.target.ariaLabel === "physique")
        })
    }

    chageFilter(e) {
        this.setState({
            filter: e.target.value
        })
    }

    /**
     * afficher la popup pour ajouter un client.
     */
    showAddClient() {
        this.setState((state) => (
            {
                display: state.showAddPopUp ? "block" : "none" // afficher la ligne
            }))
        setTimeout(() => {
            this.loadClients()
            this.props.history.push("/mes-clients")
        }, 500)
    }

    goToAddClient() {
        this.props.history.push("/mes-clients/add-client/")
    }

    /**
     * @return {JSX.Element}
     */
    render() {
        return (
            <div className='client-container'>
                {/* Barre de recherche */}
                <BarreRecherche value={this.state.filter} onChangeValue={this.chageFilter}/>

                {/* Titre de la page*/}
                <h1>Clients</h1>

                {/* btn ajouter un client */}

                <button className="btn-add" onClick={this.goToAddClient}>Ajouter le client</button>
                <nav className="btn-clt-container">
                    <button className="btn-statut" value="physique" onClick={this.changeStatut}>
                        <img src={etrepriseLogo} alt="physique"/>
                        <span className="span-statut" aria-label="physique">Physique</span>
                    </button>
                    <button className="btn-statut" value="morale" onClick={this.changeStatut}>
                        <img src={clientLogo} alt="morale"/>
                        <span className="span-statut" aria-label="morale">Morales</span>
                    </button>
                    {/* la ligne pour indiquer l'option selectioner */}
                </nav>

                {/*La Table des clients*/}
                <TableClientComponent data={this.state.clientList} statut={this.state.physique}
                                      filter={this.state.filter}/>

                <Router history={this.props.history}>
                    <Switch>
                        <Route path="/mes-clients/add-client/">
                            <AddClientComponent exitToClient={this.showAddClient}/>
                        </Route>
                    </Switch>
                </Router>

            </div>
        );
    }
}

export default ClientComponent;