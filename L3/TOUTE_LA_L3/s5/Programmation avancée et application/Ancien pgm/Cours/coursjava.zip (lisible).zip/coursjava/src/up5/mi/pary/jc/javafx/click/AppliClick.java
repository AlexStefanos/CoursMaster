package up5.mi.pary.jc.javafx.click;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import up5.mi.pary.jc.util.Compteur;

public class AppliClick extends Application {

	@Override
	public void start(Stage stage) {
		
		stage.setTitle("Cliquer !");
		Compteur compteur = new Compteur();
		

		Scene scene = new Scene(new PanelFileChooser(stage),100,100);
		
		stage.setScene(scene);
		stage.show();
		
	}
	public static void main(String[] args) {
		launch(args);
	}
}