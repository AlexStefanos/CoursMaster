package up5.mi.pary.jc.xml.dom;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Repertoire {
	private String proprietaire,creationDate;
	private Map<String,String> tels = new HashMap<String, String>( );

	public Repertoire(String creationDate) {this.creationDate = creationDate;}

	public void ajouterEntree(String nom,String tel){this.tels.put(nom,tel);}

	public String getTel(String nom){return this.tels.get(nom);}

	public void setProprietaire(String name){this.proprietaire=name;}
	public String getProprietaire ( ) {return this.proprietaire;}
	public String getCreationDate( ) {return this.creationDate;}
	public Collection<String> getNoms( ) {return this.tels.keySet();}

	//une méthode d'instance dans la classe Repertoire
	public void toXml(Writer writer)throws IOException{
		BufferedWriter bw = new BufferedWriter(writer);
		bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		bw.write("<repertoire creation=\""+this.getCreationDate( )+"\">\n");
		bw.write("     <proprietaire>"+this.getProprietaire( )+"</proprietaire>\n");
		for (String name:tels.keySet( )){
			bw.write("      <entree>\n");
			bw.write("           <nom>"+name+"</nom>\n");
			bw.write("           <telephone>"+tels.get(name)+"</telephone>\n");
			bw.write("      </entree>\n");
		}
		bw.write("</repertoire>\n");
		bw.flush( );
	}
	public static Document getDocument(Repertoire repertoire) throws ParserConfigurationException{
		DocumentBuilderFactory fabrique = DocumentBuilderFactory.newInstance();
		DocumentBuilder analyseur = fabrique.newDocumentBuilder();
		Document document = analyseur.newDocument();
		Element nodeRep = document.createElement("repertoire");
		nodeRep.setAttribute("creation", repertoire.getCreationDate());
		document.appendChild(nodeRep);

		Element nodeProp = document.createElement("proprietaire");
		nodeProp.appendChild(document.createTextNode(repertoire.getProprietaire()));
		nodeRep.appendChild(nodeProp);
		for (String name : repertoire.getNoms()){
			Element nodeEntree = document.createElement("entree");
			nodeRep.appendChild(nodeEntree);
			Element nodeNom = document.createElement("nom");
			nodeNom.appendChild(document.createTextNode(name));
			nodeEntree.appendChild(nodeNom);
			Element nodeTelephone = document.createElement("telephone");
			nodeTelephone.appendChild(document.createTextNode(repertoire.getTel(name)));
			nodeEntree.appendChild(nodeTelephone);
		}
		return document;
	}

	public static Repertoire getRepertoire(Document document){
		Element racine =document.getDocumentElement( );
		Repertoire rep = new Repertoire(racine.getAttribute("creation"));
		NodeList listProp = racine.getElementsByTagName("proprietaire") ;
		rep.setProprietaire(listProp.item(0).getTextContent( ));
		NodeList listEntree =racine.getElementsByTagName("entree");
		for (int i=0;i<listEntree.getLength();i++){
			NodeList listNom = ((Element)listEntree.item(i)).getElementsByTagName("nom");
			String nom= listNom.item(0).getTextContent( );
			NodeList listTel = ((Element)listEntree.item(i)).getElementsByTagName("telephone");
			String tel=listTel.item(0).getTextContent( );
			rep.ajouterEntree(nom, tel);
		}
		return rep;
	}


}