import React, {Component} from 'react';
import './DetailsClientStyle.css'
import InfoTableComponent from "./InfoTableComponent";
import DetailsClientService from "../../Services/DetailsClientService";
import compteLogo from "../../Images/account.png"
import factureLogo from "../../Images/facture.png"
import livrLogo from "../../Images/delivery.png"
import tvaLogo from "../../Images/tva.png"
import addLogo from "../../Images/plus.png"
import minusLogo from "../../Images/minus.png"

import {
    getInfoCompte,
    getInfoFacturation,
    getInfoLivraison,
    getInfoTva,
    CLT_INIT,
    client2DetailsClient,
    detailsClient2Client
} from "./DetailsClientUtils";
import ContratList from "./ContratList";
import FactureList from "./FactureList";

/**
 * afficher les details d'un client.
 *
 * @version 1.1
 */
class DetailsClientComponent extends Component {

    /**
     * constrocteur
     * @param props props
     */
    constructor(props) {
        super(props);
        this.state = {
            // recuprer l'id de client
            id: this.props.match.params.id,
            client: CLT_INIT,
            showContrat: false,
            showFacture: false,
            factures: []
        }
        this.setData = this.setData.bind(this)
        this.showContrats = this.showContrats.bind(this)
        this.showFactures = this.showFactures.bind(this)
    }

    /**
     * Recuprer le client de l'api
     */
    componentDidMount() {
        DetailsClientService.getClientByID(this.state.id).then((res) => {
            this.setState({
                client: client2DetailsClient(res.data)
            })
        })

    }

    showContrats() {
        this.setState({
            showContrat: !this.state.showContrat
        })
    }

    showFactures() {
        this.setState({
            showFacture: !this.state.showFacture
        })
    }

    /**
     * modifier les inforamtion de client.
     * @param data
     */
    setData(data) {
        console.log(data)
        let clientEdit = this.state.client
        for (let name in data) {
            if (name === 'nom')
                clientEdit.clientActuel.nom = data.nom
            else
                clientEdit[name] = data[name]
        }
        this.setState({client: clientEdit})
        if (this.state.client.email == null) {
            DetailsClientService.updateMoraleClient(detailsClient2Client(this.state.client), this.state.id).then(
                () => this.props.history.push("/DetailsClient/" + this.state.id)
            )
        } else {
            DetailsClientService.updatePhysiqueClient(detailsClient2Client(this.state.client), this.state.id).then(
                () => this.props.history.push("/DetailsClient/" + this.state.id)
            )
        }

    }

    /**
     * le render pour afficher les details d'un client.
     * @return {JSX.Element}
     */
    render() {
        return (
            <div className="detail-container">

                <h1 className="title">{this.state.client.clientActuel.nom}</h1>
                <h2>Details</h2>

                <h4><img src={compteLogo} alt="compte"/>Information sur le compte</h4>
                <InfoTableComponent data={getInfoCompte(this.state.client)} setData={this.setData}
                                    clientID={this.state.id}/>

                <h4><img src={factureLogo} alt="compte"/>Information de facturation</h4>
                <InfoTableComponent data={getInfoFacturation(this.state.client)} setData={this.setData}
                                    clientID={this.state.id}/>

                <h4><img src={livrLogo} alt="compte"/>Information de livraison</h4>
                <InfoTableComponent data={getInfoLivraison(this.state.client)} setData={this.setData}
                                    clientID={this.state.id}/>

                <h4><img src={tvaLogo} alt="compte"/>Information TVA</h4>
                <InfoTableComponent data={getInfoTva(this.state.client)} setData={this.setData}
                                    clientID={this.state.id}/>
                <h4 onClick={this.showContrats} style={{cursor: "pointer"}}>
                    <img className={"add-logo"} src={(this.state.showContrat) ? addLogo : minusLogo}
                         alt="afficher contrat liste"/>
                    Afficher Les Contrats
                </h4>
                {this.state.showContrat && <ContratList id={this.state.id}/>}

                <h4 onClick={this.showFactures} style={{cursor: "pointer"}}>
                    <img className={"add-logo"} src={this.state.showFacture ? addLogo : minusLogo}
                         alt="afficher contrat liste"/>
                    Factures
                </h4>
                {this.state.showFacture && <FactureList/>}
            </div>
        );
    }

}


export default DetailsClientComponent;
