package up5.mi.pary.jc.mvc.chat.client.ui;

import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import up5.mi.pary.jc.mvc.chat.common.Chat;
import up5.mi.pary.jc.mvc.chat.common.Message;

public class PanelVisuChat extends BorderPane {

	private TextArea zoneDesMessagesRecus=new TextArea();
	
	private Chat chat;

	public PanelVisuChat(Chat chat){
		this.chat=chat;
		this.zoneDesMessagesRecus.setPrefColumnCount(30);
		this.zoneDesMessagesRecus.setPrefRowCount(30);
		this.zoneDesMessagesRecus.setEditable(false);

		this.setCenter(new ScrollPane(this.zoneDesMessagesRecus));

		chatModifie();

	}

	public void messageAjoute(Message message){
		chatModifie();
	}

	private void chatModifie(){
		this.zoneDesMessagesRecus.setText(chat.toString());
	}



}
