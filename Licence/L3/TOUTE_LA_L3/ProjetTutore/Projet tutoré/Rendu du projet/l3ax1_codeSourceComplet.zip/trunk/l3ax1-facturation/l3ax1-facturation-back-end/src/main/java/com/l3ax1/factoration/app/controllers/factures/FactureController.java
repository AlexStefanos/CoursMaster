package com.l3ax1.factoration.app.controllers.factures;

import com.l3ax1.factoration.app.Models.factures.Facture;
import com.l3ax1.factoration.app.services.factures.FactureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <h1>FactureController : class</h1>
 * <hr/>
 * Facture Controller permet de communiquer avec front-end react. Pour accéder
 * à notre API on utilise des endpoints associé à une URL,  Lorsqu'on appelle
 * cette URL, on reçoit une réponse, et cet échange se fait en HTTP. et grâce
 * à Spring-Boot-starter-web nous  fournit  tout  le nécessaire pour créer un
 * endpoint.
 * <br/><br/>
 *
 * {@link RestController} : Comme @Component, elle permet d’indiquer à Spring
 * que cette classe est un bean, et aussi   indiqué  à  Spring  d’insérer  le
 * retour  de  la méthode  au  format  JSON  dans le corps de la réponse HTTP.
 * Grâce à  ça , les applications qui  vont communiquer avec l’API accéderont
 * au résultat de leur requête en parsant la réponse HTTP. <br/>
 *
 * {@link CrossOrigin} : Annotation  pour  autoriser  les  requêtes d'origine
 * croisée  sur  des  classes  de  gestionnaire  et  /  ou  des  méthodes  de
 * gestionnaire spécifiques. Traité si un HandlerMapping approprié est configuré.
 *
 * <hr/>
 *
 * @see FactureService
 * @see RestController
 * @see CrossOrigin
 *
 * @version 1.0
 * @author Salah Eddine Atia
 */

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class FactureController {

    /**
     * Cela permettra d’appeler les méthodes pour communiquer avec la base de données.
     *
     * @see FactureService
     **/
    @Autowired
    private FactureService factureService;

    /**
     * <h2>Creer une facture et l'ajouter dans la base de données</h2>
     *<hr>
     * {@link PostMapping } Pour l’envoi de données. Cela sera utilisé pour crée une facture
     * et le stocker dans la base de données. <br/>
     * <p>
     * {@link RequestBody} L'annotation indiquant qu'un paramètre de méthode doit être
     * lié au corps de la requête Web
     *
     * @param facture la facture a ajouté
     * @param clientId le client qui correspond à la facture
     * @return contrat stocké dans la base de données.
     */
    @PostMapping("/factures/ajouterFacture/{clientId}")
    public Facture creer(@RequestBody Facture facture, @PathVariable Long clientId){
        return factureService.creerFacture(facture, clientId);
    }
    /**
     *<h2>Recuperer la list des factures de la base de données.</h2>
     *
     * {@link GetMapping} Cela signifie que les requêtes  HTTP de  type  GET à l’URL /factures
     * exécuteront le code de cette méthode. Et ce code est tout simple : il s’agit d’appeler
     * la méthode  getFactures()  du  {@link FactureService},  ce  dernier appellera la méthode
     * findAll()  du  {@link testbackend.demo.repository.facture.ContratRepository}
     * et nous obtiendrons ainsi tous les clients enregistrés  en  base de données.
     *
     * @return <strong>la liste des factures enregistrés  en  base de données.<strong/>
     * @see GetMapping
     */
    @GetMapping("/factures")
    public Iterable<Facture> getFactures () {
        return this.factureService.getFactures();
    }

    /**
     * <h2>Recuperer une facture particulier de la base de données.</h2>
     *
     * {@link GetMapping} Cela signifie que les requêtes  HTTP de  type  GET à l’URL /factures/{id}
     *      * exécuteront le code de cette méthode. Et ce code est tout simple : il s’agit d’appeler
     *      * la méthode  getFactureByNumeroFacture(id)  du  {@link FactureService},  ce  dernier appellera la méthode
     *      * findById(id)  du  {@link testbackend.demo.repository.facture.ContratRepository}
     *      * et nous obtiendrons la facture de l'id donnée en paramètre.
     * @param id de la facture
     * @return <strong>la facture demander<strong/>
     * @see GetMapping
     *
     */
    @GetMapping("/factures/{id}")
    public Facture get(@PathVariable Long id){
        System.out.println("La méthode dispaly Facture à été invoqué");
        return factureService.getFactureByNumeroFacture(id);
    }
}