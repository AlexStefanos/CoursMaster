
/**
 * Fonction pour créer une table des contrats.
 *  - afficher les information d'un contrat.
 *
 * @param  data la liste des contrats.
 *
 * @return {JSX.Element} table des contrat
 */
export default function TableContratComponent({data, filter}) {

    return (
        <table id="table_contrats">
            <thead>
            <tr>
                <th>Nom</th>
                <th>Tarif</th>
                <th>Type de de facturation</th>
                <th>Debut</th>
                <th>Durée</th>
                <th>Client</th>
            </tr>
            </thead>
            <tbody>
            {
                data.map(
                    (contrat) => {
                        if ((""+contrat.nom+contrat.typeFacturation).toUpperCase().indexOf(filter.toUpperCase()) === -1)
                            return null
                        return (
                            <tr key={contrat.toString() + contrat.id}>
                                <td>{contrat.nom}</td>
                                <td>{contrat.tarif}</td>
                                <td>{contrat.typeFacturation}</td>
                                <td>{contrat.dateDebut}</td>
                                <td>{contrat.duree}</td>
                                <td>{(contrat.client == null) ? 'Pas de client' : contrat.client.clientActuel.nom}</td>
                            </tr>
                        )
                    }
                )
            }
            </tbody>
        </table>
    )
}