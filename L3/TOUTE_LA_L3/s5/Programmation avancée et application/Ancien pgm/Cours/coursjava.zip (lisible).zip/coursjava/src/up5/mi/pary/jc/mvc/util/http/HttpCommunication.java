package up5.mi.pary.jc.mvc.util.http;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.URL;
import java.net.URLConnection;

public class HttpCommunication {
	private String urlServlet;

	protected HttpCommunication(String urlServlet){
		this.urlServlet=urlServlet;
	}
	
	private InputStream connect(String args) throws IOException{
		URL url = new URL(this.urlServlet+args);
		URLConnection urlc = url.openConnection( ); 
		urlc.connect( );
		InputStream is = urlc.getInputStream( );
		return is;
	}

	protected Object getObjectFromServlet(String args) throws CommunicationException{
		
		try (InputStream is = connect(args);ObjectInputStream ois = new ObjectInputStream(is))
		{
			return ois.readObject();
		}
		catch (Exception exp){exp.printStackTrace();throw new CommunicationException(exp);}
	}

}
