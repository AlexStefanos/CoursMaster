 /* RouterConfig.java
 *
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.
 * Travail_effectué : Implémentation du code (source 1) dans le projet en l'adaptant aux besoins de notre projet + ajout d'explications, certaines des explications proviennent de source 1.
 * Source 1 : https://stackoverflow.com/questions/47689971/how-to-work-with-react-routers-and-spring-boot-controller
 */
package com.l3ax1.factoration.app.config;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Cette classe a été créée pour la version Jar de l'application Web et est une implémentation 
 * d'une approche simple qui enverra tout ce qui n'est pas une API à l'application react.
 * Consiste à créer un contrôleur d'API qui utilise RegEx: 
 * ce contrôleur redirige simplement tout vers index.html, permettant à react et react-router de faire sa magie.
 * 
 * (Cette classe n'a d'effet que lorsque nous avons une version JAR qui inclut les fichiers React compilés)
 * 
 * @author Leonard NAMOLARU
 */
@Controller
public class RouterConfig {
	/* 
	 * '/' - correspond à la racine
     * '/ {x: [\\ w \\ -] +}' - correspond par exemple à \ foo
	 *  La partie3 - correspond à tout ce qui ne commence pas par api. Par exemple. \foo\bar?page=1
	 *  La partie4 - correspond à tout ce qui ne commence pas par l'api des clients.
	 *  La partie5 - correspond à tout ce qui ne commence pas par l'api des contrats.
	 *  La partie5 - correspond à tout ce qui ne commence pas par l'api des produits.
     *  La partie6 - correspond à tout ce qui ne commence pas par l'api des factures.
	 */
	
    @RequestMapping(value = { "/", "/{x:[\\w\\-]+}", "/{x:^(?!api$).*$}/**/{y:[\\w\\-]+}", "/{x:^(?!clients$).*$}/**/{y:[\\w\\-]+}" , "/{x:^(?!contrats$).*$}/**/{y:[\\w\\-]+}", "/{x:^(?!produits$).*$}/**/{y:[\\w\\-]+}", "/{x:^(?!factures$).*$}/**/{y:[\\w\\-]+}" })
    public String getIndex(HttpServletRequest request) {
        return "/index.html";
    }

}