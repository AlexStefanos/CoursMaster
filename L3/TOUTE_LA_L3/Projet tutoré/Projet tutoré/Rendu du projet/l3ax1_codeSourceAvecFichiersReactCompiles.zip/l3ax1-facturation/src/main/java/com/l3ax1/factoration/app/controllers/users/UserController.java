/*
 * UserController.java - API.
 * Projet : Groupe L3AX1 - Projets Tutorés 2020 - 2021, Licence informatique - Université de Paris.

 * Travail_effectué : Implémentation du code (source 1) dans le projet et ajout d'explications à partir des source 1,2, 3 et 4.
 * Source 1 : callicoder.com - Spring Boot + Spring Security + JWT + MySQL + React Full Stack Polling App - Auteur : Rajeev Singh - CalliCoder : Copyright © 2017-2019
 * Source 2 : JavaDoc - https://docs.oracle.com/ - Copyright © 1996-2015, Oracle and/or its affiliates
 * Source 3 : springboottutorial.com - Integrating Spring Boot and React with Spring Security - Basic and JWT Authentication - License MIT
 * Source 4 : https://grobmeier.solutions/ - How to use Spring Security to build a simple login page / Christian Grobmeier - © 1999-2018 Grobmeier Solutions GmbH
 */
package com.l3ax1.factoration.app.controllers.users;

import com.l3ax1.factoration.app.exception.ResourceNotFoundException; // 404 Not Found 
import com.l3ax1.factoration.app.Models.users.User; // Une Entité (JPA) qui représente les utilisateurs dans la base de données
import com.l3ax1.factoration.app.payload.*;
import com.l3ax1.factoration.app.repository.users.UserRepository; // Une Entité (JPA) qui représente les utilisateurs dans la base de données.
import com.l3ax1.factoration.app.security.UserPrincipal;
import com.l3ax1.factoration.app.security.CurrentUser;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

// Nous avons besoin d'une classe Controller à laquelle nous pouvons accéder en utilisant le navigateur.
// Nous mettons toutes les configurations pour écrire les API Rest dans les contrôleurs.

/**
 *  Dans UserController, nous écrivons des API pour -
 *  (1) Pour obtenir l'utilisateur actuellement connecté.
 *  (2) Pour vérifier si un nom d'utilisateur est disponible pour l'enregistrement.
 *  (3) Pour vérifier si un e-mail est disponible pour l'enregistrement.
 *  (4) Pour obtenir le profil public d'un utilisateur.
  
 * @version 1.0
 * @author Leonard NAMOLARU
 */
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserRepository userRepository; // Repository pour conserver le modèle User dans la base de données et le récupérer.

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    
    /**
     * API pour obtenir l'utilisateur actuellement connecté.
     * @param currentUser
     * @return UserSummary
     */
    @GetMapping("/user/me") // Nous créons une simple url « /user/me » renvoyant un userSummary.
    @PreAuthorize("hasRole('USER')")
    public UserSummary getCurrentUser(@CurrentUser UserPrincipal currentUser) {
        UserSummary userSummary = new UserSummary(currentUser.getId(), currentUser.getUsername(), currentUser.getName());
        return userSummary;
    }
    
    /**
     * API pour vérifier si un nom d'utilisateur est disponible pour l'enregistrement
     * @param username
     * @return UserIdentityAvailability
     */
    @GetMapping("/user/checkUsernameAvailability") // Nous créons une simple url « /user/checkUsernameAvailability » renvoyant un UserIdentityAvailability.
    public UserIdentityAvailability checkUsernameAvailability(@RequestParam(value = "username") String username) {
        Boolean isAvailable = !userRepository.existsByUsername(username);
        return new UserIdentityAvailability(isAvailable);
    }
    
    /**
     * API pour vérifier si un e-mail est disponible pour l'enregistrement.
     * @param email
     * @return UserIdentityAvailability
     */
    @GetMapping("/user/checkEmailAvailability") // Nous créons une simple url « /user/checkEmailAvailability » renvoyant un UserIdentityAvailability.
    public UserIdentityAvailability checkEmailAvailability(@RequestParam(value = "email") String email) {
        Boolean isAvailable = !userRepository.existsByEmail(email);
        return new UserIdentityAvailability(isAvailable);
    }
    
    /**
     * API pour obtenir le profil public d'un utilisateur.
     * @param username
     * @return UserProfile
     */
    @GetMapping("/users/{username}") // Nous créons une simple url « /users/{username} » renvoyant un userProfile.
    public UserProfile getUserProfile(@PathVariable(value = "username") String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", username)); // 404 Not Found 

        UserProfile userProfile = new UserProfile(user.getId(), user.getUsername(), user.getName());

        return userProfile;
    }
    
}