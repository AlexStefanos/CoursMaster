package up5.mi.pary.jc.javafx.hello.sansreaction;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {

	@Override
	public void start(Stage stage) {
		
		stage.setTitle("Sans réaction");
		
		Button btn = new Button();
		btn.setText("OK");
		 
		Text text =new Text("--> 0");

		BorderPane root = new BorderPane();
		root.setBottom(btn);
		root.setCenter(text);

		Scene scene = new Scene(root, 200, 50);
		stage.setScene(scene);
		stage.show();


	}
	public static void main(String[] args) {
		launch(args);
	}
}